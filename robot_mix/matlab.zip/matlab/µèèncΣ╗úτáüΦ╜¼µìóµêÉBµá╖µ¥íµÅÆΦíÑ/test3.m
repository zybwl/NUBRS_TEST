clc;clear;
%file_name = 'NEW_FILE.NC.nc';
file_name = 'T1.NC.nc';
start_line_no = 56;
end_line_no = 66;
point_struct_array = get_nc_data(file_name,start_line_no,end_line_no);
n = size(point_struct_array,2);
filter_factor = 16;

index = 1;
for k = 1:n
    B = point_struct_array(k).B;
    C = point_struct_array(k).C;
    X = point_struct_array(k).X;
    Y = point_struct_array(k).Y;
    Z = point_struct_array(k).Z;
    new_para(:,index) = [X;Y;Z];
    index = index + 1;
    plot3(new_para(1,:),new_para(2,:),new_para(3,:),'-o');
end



     
     











