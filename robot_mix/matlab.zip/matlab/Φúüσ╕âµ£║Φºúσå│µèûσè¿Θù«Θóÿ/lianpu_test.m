%%
clc;clear;
file_name = '3.NC';
num_cpts = 10;
% start_line_no = 17;
% end_line_no = 500;
start_line_no = 500;
end_line_no = 1800;
% start_line_no = 430;
% end_line_no = 710;

% end_line_no = 5814;
p = 3;
%ploy_n = end_line_no - start_line_no;

%��һ����NC�ļ���ȡ����Ӧ��X��Y����
[line_before, point_struct_array ,line_end] = get_nc_data1(file_name,start_line_no,end_line_no);
n = size(point_struct_array,2);
X = zeros(1,n);
Y = zeros(1,n);
for k = 1:n
    X(k) = point_struct_array(k).X;
    Y(k) = point_struct_array(k).Y;
end

% �ڶ�������Ժ�ϸ��
% ��һ��������һ�������С��0.5���׺��� 
% С��0.5���׵��߶����������������Ӱ��ܴ�
% �ض϶���Ϊ3���׵ı���
index = 1;
for k = 1:n
    if k == 1
            point(:,index) = [X(k);Y(k)];
            index = index + 1;
    else
        vect = [X(k);Y(k)] - point(:,index-1);
        vect_l = sqrt(vect'* vect);
        l_n = ceil(vect_l/20);
        if vect_l > 0.1
            for i = 1: l_n
                point(:,index) = point(:,index-1) + 1/l_n * vect;
                index = index + 1;
            end
        else
            continue;
        end
    end  
end
points = point';
%points(:,3) = 0;
plot(points(:,1), points(:,2),'b');
hold on

%%%%%%%%%%%%%%%
num_dpts = size(points,1);
dim = size(points,2);

%�ο����е�9.5-9.6ʽ��use_centripetal���������ҳ����������������Ĳ���������ڵ�ʸ��
use_centripetal = false;
uk = compute_params_curve(points, use_centripetal);

%������51�����ݣ�������30��������Ͽ��Ƶ�
degree = 2;
num_cpts = 10;
kv = compute_knot_vector2(degree, num_dpts, num_cpts, uk);

%Compute matrix N
n0p = zeros(1,num_dpts - 2);
nnp = zeros(1,num_dpts - 2);
matrix_n = [];
for i = 2 : num_dpts - 1   
    m_temp = zeros(1, num_cpts - 2);
    span = findspan(num_cpts -1 , degree , uk(i) ,kv ); 
    N  = basisfun( span , uk(i) ,degree ,kv );
    for j = span - degree: span
        if j == 0
            n0p(i - 1) = N(1);
        elseif j == num_cpts - 1
            nnp(i - 1) = N(end);
        else
            m_temp(j) = N(j - span + degree + 1);       
        end                 
    end
    matrix_n = [matrix_n ; m_temp];   
end

% Compute NT
matrix_nt = matrix_n';
% Compute NTN matrix
matrix_ntn = matrix_nt * matrix_n;
% LU-factorization
[matrix_l, matrix_u ] = lu_decomposition(matrix_ntn);

pt0 = points(1,:);
ptm = points(end,:);
[m,n] = size(points);
rk = zeros(m - 2 ,n);
for i = 2: (num_dpts - 1)
    ptk = points(i,:);   
    ptk = ptk - n0p(i - 1) * pt0 - nnp(i -1) * ptm;
    rk(i - 1,:) = ptk;
end

vector_r = matrix_nt * rk;

controls_points = zeros(num_cpts , n);
controls_points(1,:) = pt0 ;
controls_points(end,:) = ptm ;
for i = 1:n
    b = vector_r(:,i);
    y = forward_substitution(matrix_l, b);
    x = backward_substitution(matrix_u, y);
    controls_points(2:(num_cpts-1) ,i) = x;
end
plot(controls_points(:,1), controls_points(:,2),'.r');
% hold on

%�ҳ���������λ�ã�����ǳ���
error = matrix_n * controls_points(2:end - 1,:) - rk ;
if dim ==3
    error_l = sqrt(error(:,1).^2 + error(:,2).^2 + error(:,3).^2);
else
    error_l = sqrt(error(:,1).^2 + error(:,2).^2);
end
max(error_l)
id=find(error_l==max(error_l));
% for id = 1:(num_dpts - 2)
span = findspan(num_cpts -1 , degree , uk(id + 1) ,kv );
N  = basisfun( span , uk(id + 1) ,degree ,kv );
max_error_point = N * controls_points(span - degree + 1 : span + 1 , :);
plot( [max_error_point(1)  points(id + 1,1)], [max_error_point(2)  points(id + 1,2)], 'r');
% end

index = 1;
ploy_n = 500;
for u = 0:1/ploy_n:1
    span = findspan(num_cpts -1 , degree , u ,kv );
    N  = basisfun( span , u ,degree ,kv );
    new_point(index,:) = N * controls_points(span - degree + 1 : span + 1 , :);
    index = index + 1;
end
plot(new_point(:,1),new_point(:,2),'k'); 
axis equal














