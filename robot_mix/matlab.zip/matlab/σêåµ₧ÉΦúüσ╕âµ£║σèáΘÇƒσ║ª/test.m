clc;clear;
file_name = '4.NC';
start_line = [20,320,426,730];
end_line = [308,412,710,1009];

% start_line = [20];
% end_line = [308];

for i = 1:length(start_line)

    start_line_no = start_line(i);
    end_line_no = end_line(i);
    p = 3;
    [line_before, point_struct_array ,line_end] = get_nc_data(file_name,start_line_no,end_line_no);
    n = size(point_struct_array,2);

    X = zeros(1,n);
    Y = zeros(1,n);
    Z = zeros(1,n);
   
    segment_start_no = 1;
    segment_flag = true;
   
    for k = 1:n
        X(k) = point_struct_array(k).X;
        Y(k) = point_struct_array(k).Y;
        Z(k) = point_struct_array(k).Z;
        plot([X(k) X(k) + 5*cos(Z(k)/180*pi)],[Y(k) Y(k) + 5*sin(Z(k)/180*pi)],'-r')   
        hold on
        
        if (k > 1) 
            if segment_flag  
                if (abs(Z(k) - Z(k-1)) > 20)   || (k == n)
%                   plot(X(segment_start_no:k - 1),Y(segment_start_no:k - 1),'*');
%                     line_number = k - segment_start_no - 1
                    send_line = sprintf('%d', k - segment_start_no);
                    for j =  segment_start_no + 1: k 
                        xx = sprintf('0 1 %0.3f %0.3f %0.3f %0.3f',X(j-1),Y(j-1), X(j),Y(j));
                        send_line = sprintf('%s %s', send_line, xx);
                    end
                    send_line
                    newx = X(segment_start_no:k - 1);
                    newy = Y(segment_start_no:k - 1);
                    points = [newx' newy'];
                    new_points = fit_fun(points, 0.2);
                    out_line = '';
                    out_line = sprintf('%d', size(new_points,1));
                    for k = 1:size(new_points,1)
                        xx = sprintf('%0.3f %0.3f ',new_points(k,2),new_points(k,1));
                        out_line = sprintf('%s %s', out_line, xx);
                    end
                    out_line
                    plot(new_points(:,1) , new_points(:,2) , '-*');
                    segment_flag = false;
                end
            else
                if abs(Z(k) - Z(k-1)) < 20
                    segment_start_no = k + 1;
                    segment_flag = true;
                end
            end                   
        end
        pause(0.1);
    end
end

% plot(X,Y,'-b');
% % hold on









     
     











