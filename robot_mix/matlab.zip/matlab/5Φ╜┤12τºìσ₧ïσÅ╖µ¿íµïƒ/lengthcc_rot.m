clc;clear ;close all;
origin_control_points = [ -45    -16
   -46     -4
   -45     8
   -33     14
   -24     9
   -22     -1
   -15    0
   -8      9
   6     12
   13    3
   24    9
   26    -2
   9     -8
   21   -10
   1    -27
   -13   -18
   -28   -18
   -45    -16
   -46     -4
   -45     8
];

x_t = 20; y_t = 20;
angle = 45/180 * pi;
temp_controls_points = [origin_control_points'; ones(1,20)];
rotation_vet = [cos(angle) -sin(angle) 0;sin(angle) cos(angle) 0 ; 0 0 1];
transfer_vet = [1 0 x_t;0 1 y_t;0 0 1];
new_control_points = transfer_vet * rotation_vet * temp_controls_points;
rt_control_points = new_control_points(1:2,:)';

num_cpts = 17;
degree = 3;
ploy_n = 2400;
u_inter_len = num_cpts/ (ploy_n - 1);
kv = -degree :num_cpts + degree;
index = 1;

for u = 0: u_inter_len : num_cpts
    span = findspan(num_cpts + degree -1 , degree , u ,kv );
    N  = basisfun( span , u ,degree ,kv );
    rt_new_points(index,:) = N * rt_control_points(span - degree + 1 : span + 1 , :);
    origin_new_points(index,:) = N * origin_control_points(span - degree + 1 : span + 1 , :);
    index = index + 1;
end 
  
%���������������Ϊ�˰����λ���޸ĳ������ģʽ
index = randi(200);
for i = 0: 12: ploy_n - 12 
    index = mod(index , 200) + 1;
    choose_index = i + randi(12);
    rand_origin_points(index,:) = origin_new_points(choose_index , :);
end

%���������������Ϊ�˰����λ���޸ĳ������ģʽ
index = randi(100);
for i = 0: 24: ploy_n - 24
    index = mod(index , 100) + 1;
    choose_index = i + randi(24);
    rand_rt_points(index,:) = rt_new_points(choose_index , :);
end

subplot(1,2,1)
plot(origin_control_points(:,1), origin_control_points(:,2));
hold on
plot(origin_new_points(:,1),origin_new_points(:,2),'-k'); 
hold on
plot(rand_origin_points(:,1),rand_origin_points(:,2),'*g'); 
plot(rand_origin_points(1,1),rand_origin_points(1,2),'+r');

axis([-50 50  -50 50])
subplot(1,2,2)
plot(rt_control_points(:,1), rt_control_points(:,2));
hold on
plot(rt_new_points(:,1),rt_new_points(:,2),'-k'); 
plot(rand_rt_points(:,1),rand_rt_points(:,2),'*g'); 
plot(rand_rt_points(1,1),rand_rt_points(1,2),'+r'); 
axis([-50 50  -50 50])

%��ȡԭʼ����240����,ԭʼ���ݱ�������ת���������Ҫ����ƫ����һ���Ҫ










