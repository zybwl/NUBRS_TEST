
r = 20;
x0=0;y0=0;z0=0;

%ֻ��һ����Բ
angleA = zeros(11,21);
angleC = zeros(11,21);
x1 = zeros(11,21);
y1 = zeros(11,21);
z1 = zeros(11,21);
for i = 1 : 11
    for j = 1: 21
        u = (i - 1) * pi / 20;
        v = (j - 1) * pi / 10;
        angleA(i,j) = u;
        angleC(i,j) = v;
        x1(i,j) = r * sin(u) * sin(v) + x0;
        y1(i,j) = r * sin(u) * cos(v) + y0;
        z1(i,j) = r* cos(u) + z0;
    end
end

s = [];
for i = 1 : 11
    for j = 1: 21     
        k = (i - 1) * 21 + j;
        line_str = '';
        x = num2str(x1(i,j),'X%-8.3f');
        line_str = strcat(line_str,x); 
        y = num2str(y1(i,j),'Y%-8.3f');
        line_str = strcat( line_str , y ); 
        z = num2str(z1(i,j),'Z%-8.3f');
        line_str = strcat( line_str , z ); 
        a = num2str(angleA(i,j) * 180 / pi ,'A%-8.3f');
        line_str = strcat( line_str , a );
        c = num2str(angleC(i,j) * 180 / pi ,'C%-8.3f');
        s{k,1} = strcat( line_str , c );
    end
end

file_name = 'xxx.NC';
fid= fopen(file_name,'a');

for i = 1:221
     fprintf(fid,'%s\n', s{i,1});
end

fclose(fid);




