clc;clear all
xPosRef = 10;
yPosRef = 10;
zPosRef = 10;
L = 10;
centerC = [-2,3,2];
centerA = [0,1,0];
point = [0,0,0;0,0,-L;0,2,-L+3;0,2,0];

now_center = repmat(centerA,size(point,1), 1);
% rot_a_point = point - now_center;
for theta = 0:90
    vect_point = point - now_center;
    angle = theta / 180 * pi;
    rot_a_point = now_center + vect_point * [1 0 0; 0 cos(angle) sin(angle); 0 -sin(angle) cos(angle)] ;
    all_point = [centerC;centerA;rot_a_point;centerA];
    plot3(all_point(:,1),all_point(:,2),all_point(:,3));
%     plot(all_point(:,2),all_point(:,3));
    axis equal
    axis([-15 15 -15 15 -15 15]);
%     view(-90,0);
%     axis([-20 20 -20 20]);
    pause(0.1);
end

new_point = [centerA;rot_a_point;centerA];
now_center = repmat(centerC,size(new_point,1), 1);

for theta = 0:90
    vect_point = new_point - now_center;
    angle = theta / 180 * pi;
    rot_c_point = now_center + vect_point * [ cos(angle) sin(angle) 0;-sin(angle) cos(angle) 0;0 0 1] ;
%     ���鵽��ת���ĵĳ����Ƿ����仯
%     xx = rot_c_point(2,:) - centerC;
%     ll = xx * xx'
    all_point = [centerC;rot_c_point];
    plot3(all_point(:,1),all_point(:,2),all_point(:,3)); 
%     plot(all_point(:,1),all_point(:,2));
%     axis([-20 20 -20 20]);
    axis equal
    axis([-15 15 -15 15 -15 15]);
%     view(0,90);
    pause(0.1);
end

%���յ���仯��Ϊ��
last_point = rot_c_point(3,:)


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ���ڿ�ʼ��ר�ŵĹ�ʽ����
% ������λ��Ϊ
% centerC = [-2,3,2];
% centerA = [0,1,0];
% point = [0,0,0;0,0,-L;0,2,-L+3;0,2,0];
% 
% mcx = 
% mcy = 
% may = 1;
% angleA = 270; angleC = 90
% sinA = -1;
% cosA = 0;
% sinC = 1
% cosC = 0;
% 
% x = Mcx*cosC - (May*cosA - L*sinA + Mcy)*sinC - Mcx;
% y = Mcx*sinC + (May*cosA - L*sinA + Mcy)*cosC - May - Mcy;
% z = May*sinA + L*cosA;




% all_point = [centerC;centerA;point;centerA];
% plot3(all_point(:,1),all_point(:,2),all_point(:,3));
% axis equal
% axis([-10 10 -10 10 -20 10])
% set(gca,'Zdir','reverse');
