function [new_x, new_y, new_z] = get_cylinder_data(center,h,r,angle)

[x, y, z]=cylinder(r); 
z = h * z - h/2;  
n = size(x,2);
new_down = [x(1,:);y(1,:);z(1,:);ones(1,n)];
new_top = [x(2,:);y(2,:);z(2,:);ones(1,n)];

rot_a = get_rotation_matrix(1, angle(1));
rot_c = get_rotation_matrix(2, angle(2));
new_top = rot_a * rot_c * new_top ;
new_down = rot_a * rot_c * new_down;

new_x = [new_top(1,:);new_down(1,:)] + center(1);
new_y = [new_top(2,:);new_down(2,:)] + center(2);
new_z = [new_top(3,:);new_down(3,:)] + center(3);

new_x = new_x';
new_y = new_y';
new_z = new_z';

% figure(1)
% surf(new_x,new_y,new_z,'FaceColor',[1,0,0]); 
% hold on
% fill3(new_x,new_y,new_z,[0 1 0]);   



