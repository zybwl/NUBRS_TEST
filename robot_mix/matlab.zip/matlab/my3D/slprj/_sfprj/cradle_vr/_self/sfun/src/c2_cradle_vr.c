/* Include files */

#include "cradle_vr_sfun.h"
#include "c2_cradle_vr.h"
#include "mwmathutil.h"
#define CHARTINSTANCE_CHARTNUMBER      (chartInstance->chartNumber)
#define CHARTINSTANCE_INSTANCENUMBER   (chartInstance->instanceNumber)
#include "cradle_vr_sfun_debug_macros.h"
#define _SF_MEX_LISTEN_FOR_CTRL_C(S)   sf_mex_listen_for_ctrl_c_with_debugger(S, sfGlobalDebugInstanceStruct);

static void chart_debug_initialization(SimStruct *S, unsigned int
  fullDebuggerInitialization);
static void chart_debug_initialize_data_addresses(SimStruct *S);
static const mxArray* sf_opaque_get_hover_data_for_msg(void *chartInstance,
  int32_T msgSSID);

/* Type Definitions */

/* Named Constants */
#define CALL_EVENT                     (-1)
#define c2_IN_NO_ACTIVE_CHILD          ((uint8_T)0U)
#define c2_IN_FreeDynamics             ((uint8_T)1U)
#define c2_const_g                     (9.81)
#define c2_const_l                     (1.0)
#define c2_const_pi                    (3.141)
#define c2_const_k                     (7)

/* Variable Declarations */

/* Variable Definitions */
static real_T _sfTime_;

/* Function Declarations */
static void initialize_c2_cradle_vr(SFc2_cradle_vrInstanceStruct *chartInstance);
static void initialize_params_c2_cradle_vr(SFc2_cradle_vrInstanceStruct
  *chartInstance);
static void enable_c2_cradle_vr(SFc2_cradle_vrInstanceStruct *chartInstance);
static void disable_c2_cradle_vr(SFc2_cradle_vrInstanceStruct *chartInstance);
static void c2_update_debugger_state_c2_cradle_vr(SFc2_cradle_vrInstanceStruct
  *chartInstance);
static const mxArray *get_sim_state_c2_cradle_vr(SFc2_cradle_vrInstanceStruct
  *chartInstance);
static void set_sim_state_c2_cradle_vr(SFc2_cradle_vrInstanceStruct
  *chartInstance, const mxArray *c2_st);
static void c2_set_sim_state_side_effects_c2_cradle_vr
  (SFc2_cradle_vrInstanceStruct *chartInstance);
static void finalize_c2_cradle_vr(SFc2_cradle_vrInstanceStruct *chartInstance);
static void sf_gateway_c2_cradle_vr(SFc2_cradle_vrInstanceStruct *chartInstance);
static void mdl_start_c2_cradle_vr(SFc2_cradle_vrInstanceStruct *chartInstance);
static void zeroCrossings_c2_cradle_vr(SFc2_cradle_vrInstanceStruct
  *chartInstance);
static void derivatives_c2_cradle_vr(SFc2_cradle_vrInstanceStruct *chartInstance);
static void outputs_c2_cradle_vr(SFc2_cradle_vrInstanceStruct *chartInstance);
static void initSimStructsc2_cradle_vr(SFc2_cradle_vrInstanceStruct
  *chartInstance);
static void c2_eml_ini_fcn_to_be_inlined_70(SFc2_cradle_vrInstanceStruct
  *chartInstance);
static void c2_eml_term_fcn_to_be_inlined_70(SFc2_cradle_vrInstanceStruct
  *chartInstance);
static void init_script_number_translation(uint32_T c2_machineNumber, uint32_T
  c2_chartNumber, uint32_T c2_instanceNumber);
static const mxArray *c2_emlrt_marshallOut(SFc2_cradle_vrInstanceStruct
  *chartInstance, const int32_T c2_u);
static const mxArray *c2_sf_marshallOut(void *chartInstanceVoid, void *c2_inData);
static int32_T c2_emlrt_marshallIn(SFc2_cradle_vrInstanceStruct *chartInstance,
  const mxArray *c2_b_sfEvent, const char_T *c2_identifier);
static int32_T c2_b_emlrt_marshallIn(SFc2_cradle_vrInstanceStruct *chartInstance,
  const mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId);
static void c2_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c2_mxArrayInData, const char_T *c2_varName, void *c2_outData);
static const mxArray *c2_b_emlrt_marshallOut(SFc2_cradle_vrInstanceStruct
  *chartInstance, const uint8_T c2_u);
static const mxArray *c2_b_sf_marshallOut(void *chartInstanceVoid, void
  *c2_inData);
static uint8_T c2_c_emlrt_marshallIn(SFc2_cradle_vrInstanceStruct *chartInstance,
  const mxArray *c2_b_tp_FreeDynamics, const char_T *c2_identifier);
static uint8_T c2_d_emlrt_marshallIn(SFc2_cradle_vrInstanceStruct *chartInstance,
  const mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId);
static void c2_b_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c2_mxArrayInData, const char_T *c2_varName, void *c2_outData);
static const mxArray *c2_c_emlrt_marshallOut(SFc2_cradle_vrInstanceStruct
  *chartInstance, const boolean_T c2_u);
static const mxArray *c2_c_sf_marshallOut(void *chartInstanceVoid, void
  *c2_inData);
static const mxArray *c2_d_emlrt_marshallOut(SFc2_cradle_vrInstanceStruct
  *chartInstance, const real_T c2_u[7]);
static const mxArray *c2_d_sf_marshallOut(void *chartInstanceVoid, void
  *c2_inData);
static void c2_e_emlrt_marshallIn(SFc2_cradle_vrInstanceStruct *chartInstance,
  const mxArray *c2_b_p_out, const char_T *c2_identifier, real_T c2_y[7]);
static void c2_f_emlrt_marshallIn(SFc2_cradle_vrInstanceStruct *chartInstance,
  const mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId, real_T c2_y[7]);
static void c2_c_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c2_mxArrayInData, const char_T *c2_varName, void *c2_outData);
static const mxArray *c2_e_emlrt_marshallOut(SFc2_cradle_vrInstanceStruct
  *chartInstance, const real_T c2_u);
static const mxArray *c2_e_sf_marshallOut(void *chartInstanceVoid, void
  *c2_inData);
static real_T c2_g_emlrt_marshallIn(SFc2_cradle_vrInstanceStruct *chartInstance,
  const mxArray *c2_i, const char_T *c2_identifier);
static real_T c2_h_emlrt_marshallIn(SFc2_cradle_vrInstanceStruct *chartInstance,
  const mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId);
static void c2_d_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c2_mxArrayInData, const char_T *c2_varName, void *c2_outData);
static const mxArray *c2_f_emlrt_marshallOut(SFc2_cradle_vrInstanceStruct
  *chartInstance);
static void c2_i_emlrt_marshallIn(SFc2_cradle_vrInstanceStruct *chartInstance,
  const mxArray *c2_u);
static const mxArray *c2_j_emlrt_marshallIn(SFc2_cradle_vrInstanceStruct
  *chartInstance, const mxArray *c2_b_setSimStateSideEffectsInfo, const char_T
  *c2_identifier);
static const mxArray *c2_k_emlrt_marshallIn(SFc2_cradle_vrInstanceStruct
  *chartInstance, const mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId);
static const mxArray *sf_get_hover_data_for_msg(SFc2_cradle_vrInstanceStruct
  *chartInstance, int32_T c2_ssid);
static void c2_init_sf_message_store_memory(SFc2_cradle_vrInstanceStruct
  *chartInstance);
static int32_T c2__s32_d_(SFc2_cradle_vrInstanceStruct *chartInstance, real_T
  c2_b, uint32_T c2_ssid, int32_T c2_offset, int32_T c2_length);
static void init_dsm_address_info(SFc2_cradle_vrInstanceStruct *chartInstance);
static void init_simulink_io_address(SFc2_cradle_vrInstanceStruct *chartInstance);

/* Function Definitions */
static void initialize_c2_cradle_vr(SFc2_cradle_vrInstanceStruct *chartInstance)
{
  int32_T c2_i0;
  int32_T c2_i1;
  int32_T c2_i2;
  int32_T c2_i3;
  int32_T c2_i4;
  int32_T c2_i5;
  int32_T c2_i6;
  int32_T c2_i7;
  if (sf_is_first_init_cond(chartInstance->S)) {
    chart_debug_initialize_data_addresses(chartInstance->S);
  }

  chartInstance->c2_sfEvent = CALL_EVENT;
  _sfTime_ = sf_get_time(chartInstance->S);
  chartInstance->c2_doSetSimStateSideEffects = 0U;
  chartInstance->c2_setSimStateSideEffectsInfo = NULL;
  chartInstance->c2_tp_FreeDynamics = 0U;
  chartInstance->c2_is_active_c2_cradle_vr = 0U;
  chartInstance->c2_is_c2_cradle_vr = c2_IN_NO_ACTIVE_CHILD;
  for (c2_i0 = 0; c2_i0 < 7; c2_i0++) {
    (*chartInstance->c2_p)[c2_i0] = 0.0;
  }

  for (c2_i1 = 0; c2_i1 < 7; c2_i1++) {
    _SFD_DATA_RANGE_CHECK((*chartInstance->c2_p)[c2_i1], 0U, 1U, 0U,
                          chartInstance->c2_sfEvent, false);
  }

  for (c2_i2 = 0; c2_i2 < 7; c2_i2++) {
    (*chartInstance->c2_v)[c2_i2] = 0.0;
  }

  for (c2_i3 = 0; c2_i3 < 7; c2_i3++) {
    _SFD_DATA_RANGE_CHECK((*chartInstance->c2_v)[c2_i3], 1U, 1U, 0U,
                          chartInstance->c2_sfEvent, false);
  }

  chartInstance->c2_g = 9.81;
  _SFD_DATA_RANGE_CHECK(chartInstance->c2_g, 14U, 1U, 0U,
                        chartInstance->c2_sfEvent, false);
  chartInstance->c2_l = 1.0;
  _SFD_DATA_RANGE_CHECK(chartInstance->c2_l, 16U, 1U, 0U,
                        chartInstance->c2_sfEvent, false);
  chartInstance->c2_pi = 3.141;
  _SFD_DATA_RANGE_CHECK(chartInstance->c2_pi, 17U, 1U, 0U,
                        chartInstance->c2_sfEvent, false);
  chartInstance->c2_k = 7;
  _SFD_DATA_RANGE_CHECK((real_T)chartInstance->c2_k, 15U, 1U, 0U,
                        chartInstance->c2_sfEvent, false);
  if (!(sf_get_output_port_reusable(chartInstance->S, 1) != 0)) {
    for (c2_i4 = 0; c2_i4 < 7; c2_i4++) {
      (*chartInstance->c2_p_out)[c2_i4] = 0.0;
    }

    for (c2_i6 = 0; c2_i6 < 7; c2_i6++) {
      _SFD_DATA_RANGE_CHECK((*chartInstance->c2_p_out)[c2_i6], 9U, 1U, 0U,
                            chartInstance->c2_sfEvent, false);
    }
  }

  if (!(sf_get_output_port_reusable(chartInstance->S, 2) != 0)) {
    for (c2_i5 = 0; c2_i5 < 7; c2_i5++) {
      (*chartInstance->c2_v_out)[c2_i5] = 0.0;
    }

    for (c2_i7 = 0; c2_i7 < 7; c2_i7++) {
      _SFD_DATA_RANGE_CHECK((*chartInstance->c2_v_out)[c2_i7], 10U, 1U, 0U,
                            chartInstance->c2_sfEvent, false);
    }
  }
}

static void initialize_params_c2_cradle_vr(SFc2_cradle_vrInstanceStruct
  *chartInstance)
{
  (void)chartInstance;
}

static void enable_c2_cradle_vr(SFc2_cradle_vrInstanceStruct *chartInstance)
{
  _sfTime_ = sf_get_time(chartInstance->S);
}

static void disable_c2_cradle_vr(SFc2_cradle_vrInstanceStruct *chartInstance)
{
  _sfTime_ = sf_get_time(chartInstance->S);
}

static void c2_update_debugger_state_c2_cradle_vr(SFc2_cradle_vrInstanceStruct
  *chartInstance)
{
  uint32_T c2_prevAniVal;
  c2_prevAniVal = _SFD_GET_ANIMATION();
  _SFD_SET_ANIMATION(0U);
  _SFD_SET_HONOR_BREAKPOINTS(0U);
  if (chartInstance->c2_is_active_c2_cradle_vr == 1U) {
    _SFD_CC_CALL(CHART_ACTIVE_TAG, 0U, chartInstance->c2_sfEvent);
  }

  if (chartInstance->c2_is_c2_cradle_vr == c2_IN_FreeDynamics) {
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 0U, chartInstance->c2_sfEvent);
  } else {
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 0U, chartInstance->c2_sfEvent);
  }

  _SFD_SET_ANIMATION(c2_prevAniVal);
  _SFD_SET_HONOR_BREAKPOINTS(1U);
  _SFD_ANIMATE();
}

static const mxArray *get_sim_state_c2_cradle_vr(SFc2_cradle_vrInstanceStruct
  *chartInstance)
{
  const mxArray *c2_st = NULL;
  c2_st = NULL;
  sf_mex_assign(&c2_st, c2_f_emlrt_marshallOut(chartInstance), false);
  return c2_st;
}

static void set_sim_state_c2_cradle_vr(SFc2_cradle_vrInstanceStruct
  *chartInstance, const mxArray *c2_st)
{
  c2_i_emlrt_marshallIn(chartInstance, sf_mex_dup(c2_st));
  chartInstance->c2_doSetSimStateSideEffects = 1U;
  c2_update_debugger_state_c2_cradle_vr(chartInstance);
  sf_mex_destroy(&c2_st);
}

static void c2_set_sim_state_side_effects_c2_cradle_vr
  (SFc2_cradle_vrInstanceStruct *chartInstance)
{
  if (chartInstance->c2_doSetSimStateSideEffects != 0) {
    chartInstance->c2_tp_FreeDynamics = (uint8_T)
      (chartInstance->c2_is_c2_cradle_vr == c2_IN_FreeDynamics);
    chartInstance->c2_doSetSimStateSideEffects = 0U;
  }
}

static void finalize_c2_cradle_vr(SFc2_cradle_vrInstanceStruct *chartInstance)
{
  sf_mex_destroy(&chartInstance->c2_setSimStateSideEffectsInfo);
}

static void sf_gateway_c2_cradle_vr(SFc2_cradle_vrInstanceStruct *chartInstance)
{
  int32_T c2_i8;
  int32_T c2_i9;
  int32_T c2_i10;
  int32_T c2_i11;
  int32_T c2_i12;
  int32_T c2_i13;
  int32_T c2_i14;
  int32_T c2_i15;
  real_T c2_collision;
  real_T c2_i;
  int32_T c2_i16;
  int32_T c2_i17;
  int32_T c2_i18;
  int32_T c2_i19;
  boolean_T c2_out;
  int32_T c2_i20;
  real_T c2_d0;
  int32_T c2_i21;
  real_T c2_d1;
  boolean_T c2_b_out;
  int32_T c2_i22;
  boolean_T c2_c_out;
  int32_T c2_i23;
  real_T c2_tmp;
  real_T c2_b_i;
  int32_T c2_i24;
  int32_T c2_i25;
  int32_T c2_i26;
  boolean_T c2_d_out;
  real_T c2_d2;
  real_T c2_d3;
  boolean_T c2_e_out;
  int32_T c2_i27;
  int32_T c2_i28;
  int32_T c2_i29;
  int32_T c2_i30;
  int32_T exitg1;
  int32_T exitg2;
  c2_set_sim_state_side_effects_c2_cradle_vr(chartInstance);
  _SFD_SYMBOL_SCOPE_PUSH(0U, 0U);
  _sfTime_ = sf_get_time(chartInstance->S);
  if (ssIsMajorTimeStep(chartInstance->S) != 0) {
    chartInstance->c2_lastMajorTime = _sfTime_;
    chartInstance->c2_stateChanged = (boolean_T)0;
    _SFD_CC_CALL(CHART_ENTER_SFUNCTION_TAG, 0U, chartInstance->c2_sfEvent);
    _SFD_DATA_RANGE_CHECK((real_T)*chartInstance->c2_input6, 8U, 1U, 0U,
                          chartInstance->c2_sfEvent, false);
    _SFD_DATA_RANGE_CHECK((real_T)*chartInstance->c2_input5, 7U, 1U, 0U,
                          chartInstance->c2_sfEvent, false);
    _SFD_DATA_RANGE_CHECK((real_T)*chartInstance->c2_input4, 6U, 1U, 0U,
                          chartInstance->c2_sfEvent, false);
    _SFD_DATA_RANGE_CHECK((real_T)*chartInstance->c2_input3, 5U, 1U, 0U,
                          chartInstance->c2_sfEvent, false);
    _SFD_DATA_RANGE_CHECK((real_T)*chartInstance->c2_input2, 4U, 1U, 0U,
                          chartInstance->c2_sfEvent, false);
    _SFD_DATA_RANGE_CHECK((real_T)*chartInstance->c2_input1, 3U, 1U, 0U,
                          chartInstance->c2_sfEvent, false);
    _SFD_DATA_RANGE_CHECK((real_T)*chartInstance->c2_input0, 2U, 1U, 0U,
                          chartInstance->c2_sfEvent, false);
    chartInstance->c2_sfEvent = CALL_EVENT;
    for (c2_i11 = 0; c2_i11 < 7; c2_i11++) {
      (*chartInstance->c2_p_out)[c2_i11] = 0.0;
    }

    for (c2_i13 = 0; c2_i13 < 7; c2_i13++) {
      _SFD_DATA_RANGE_CHECK((*chartInstance->c2_p_out)[c2_i13], 9U, 1U, 0U,
                            chartInstance->c2_sfEvent, false);
    }

    for (c2_i14 = 0; c2_i14 < 7; c2_i14++) {
      (*chartInstance->c2_v_out)[c2_i14] = 0.0;
    }

    for (c2_i15 = 0; c2_i15 < 7; c2_i15++) {
      _SFD_DATA_RANGE_CHECK((*chartInstance->c2_v_out)[c2_i15], 10U, 1U, 0U,
                            chartInstance->c2_sfEvent, false);
    }

    _SFD_CC_CALL(CHART_ENTER_DURING_FUNCTION_TAG, 0U, chartInstance->c2_sfEvent);
    if (chartInstance->c2_is_active_c2_cradle_vr == 0U) {
      _SFD_CC_CALL(CHART_ENTER_ENTRY_FUNCTION_TAG, 0U, chartInstance->c2_sfEvent);
      chartInstance->c2_stateChanged = true;
      chartInstance->c2_is_active_c2_cradle_vr = 1U;
      _SFD_CC_CALL(EXIT_OUT_OF_FUNCTION_TAG, 0U, chartInstance->c2_sfEvent);
      _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 2U, chartInstance->c2_sfEvent);
      for (c2_i16 = 0; c2_i16 < 7; c2_i16++) {
        (*chartInstance->c2_p)[c2_i16] = 0.0;
      }

      for (c2_i17 = 0; c2_i17 < 7; c2_i17++) {
        _SFD_DATA_RANGE_CHECK((*chartInstance->c2_p)[c2_i17], 0U, 5U, 2U,
                              chartInstance->c2_sfEvent, false);
      }

      for (c2_i18 = 0; c2_i18 < 7; c2_i18++) {
        (*chartInstance->c2_v)[c2_i18] = 0.0;
      }

      for (c2_i19 = 0; c2_i19 < 7; c2_i19++) {
        _SFD_DATA_RANGE_CHECK((*chartInstance->c2_v)[c2_i19], 1U, 5U, 2U,
                              chartInstance->c2_sfEvent, false);
      }

      (*chartInstance->c2_p)[0] = 1.047 * (real_T)*chartInstance->c2_input0;
      for (c2_i20 = 0; c2_i20 < 7; c2_i20++) {
        _SFD_DATA_RANGE_CHECK((*chartInstance->c2_p)[c2_i20], 0U, 5U, 2U,
                              chartInstance->c2_sfEvent, false);
      }

      (*chartInstance->c2_p)[1] = 1.047 * (real_T)*chartInstance->c2_input1;
      for (c2_i21 = 0; c2_i21 < 7; c2_i21++) {
        _SFD_DATA_RANGE_CHECK((*chartInstance->c2_p)[c2_i21], 0U, 5U, 2U,
                              chartInstance->c2_sfEvent, false);
      }

      (*chartInstance->c2_p)[2] = 1.047 * (real_T)*chartInstance->c2_input2;
      for (c2_i22 = 0; c2_i22 < 7; c2_i22++) {
        _SFD_DATA_RANGE_CHECK((*chartInstance->c2_p)[c2_i22], 0U, 5U, 2U,
                              chartInstance->c2_sfEvent, false);
      }

      (*chartInstance->c2_p)[3] = 1.047 * (real_T)*chartInstance->c2_input3;
      for (c2_i23 = 0; c2_i23 < 7; c2_i23++) {
        _SFD_DATA_RANGE_CHECK((*chartInstance->c2_p)[c2_i23], 0U, 5U, 2U,
                              chartInstance->c2_sfEvent, false);
      }

      (*chartInstance->c2_p)[4] = 1.047 * (real_T)*chartInstance->c2_input4;
      for (c2_i24 = 0; c2_i24 < 7; c2_i24++) {
        _SFD_DATA_RANGE_CHECK((*chartInstance->c2_p)[c2_i24], 0U, 5U, 2U,
                              chartInstance->c2_sfEvent, false);
      }

      (*chartInstance->c2_p)[5] = 1.047 * (real_T)*chartInstance->c2_input5;
      for (c2_i25 = 0; c2_i25 < 7; c2_i25++) {
        _SFD_DATA_RANGE_CHECK((*chartInstance->c2_p)[c2_i25], 0U, 5U, 2U,
                              chartInstance->c2_sfEvent, false);
      }

      (*chartInstance->c2_p)[6] = 1.047 * (real_T)*chartInstance->c2_input6;
      for (c2_i26 = 0; c2_i26 < 7; c2_i26++) {
        _SFD_DATA_RANGE_CHECK((*chartInstance->c2_p)[c2_i26], 0U, 5U, 2U,
                              chartInstance->c2_sfEvent, false);
      }

      chartInstance->c2_stateChanged = true;
      chartInstance->c2_is_c2_cradle_vr = c2_IN_FreeDynamics;
      _SFD_CS_CALL(STATE_ACTIVE_TAG, 0U, chartInstance->c2_sfEvent);
      chartInstance->c2_tp_FreeDynamics = 1U;
    } else {
      _SFD_CS_CALL(STATE_ENTER_DURING_FUNCTION_TAG, 0U,
                   chartInstance->c2_sfEvent);
      _SFD_CT_CALL(TRANSITION_BEFORE_PROCESSING_TAG, 12U,
                   chartInstance->c2_sfEvent);
      _SFD_SET_DATA_VALUE_PTR(18U, &c2_collision);
      _SFD_SET_DATA_VALUE_PTR(13U, &c2_i);
      _SFD_CS_CALL(FUNCTION_ACTIVE_TAG, 1U, chartInstance->c2_sfEvent);
      _SFD_SYMBOL_SCOPE_PUSH(2U, 0U);
      _SFD_SYMBOL_SCOPE_ADD_IMPORTABLE("collision", &c2_collision,
        c2_e_sf_marshallOut, c2_d_sf_marshallIn);
      _SFD_SYMBOL_SCOPE_ADD_IMPORTABLE("i", &c2_i, c2_e_sf_marshallOut,
        c2_d_sf_marshallIn);
      _SFD_CS_CALL(STATE_ENTER_DURING_FUNCTION_TAG, 1U,
                   chartInstance->c2_sfEvent);
      c2_i = 0.0;
      _SFD_DATA_RANGE_CHECK(c2_i, 13U, 4U, 1U, chartInstance->c2_sfEvent, false);
      c2_collision = 0.0;
      _SFD_DATA_RANGE_CHECK(c2_collision, 18U, 4U, 1U, chartInstance->c2_sfEvent,
                            false);
      _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 3U, chartInstance->c2_sfEvent);
      c2_i = 0.0;
      _SFD_DATA_RANGE_CHECK(c2_i, 13U, 5U, 3U, chartInstance->c2_sfEvent, false);
      do {
        exitg2 = 0;
        _SFD_CT_CALL(TRANSITION_BEFORE_PROCESSING_TAG, 5U,
                     chartInstance->c2_sfEvent);
        c2_out = (CV_TRANSITION_EVAL(5U, (int32_T)_SFD_CCP_CALL(5U, 0,
                    CV_RELATIONAL_EVAL(5U, 5U, 0, c2_i, 6.0, -1, 2U, c2_i < 6.0)
                    != 0U, chartInstance->c2_sfEvent)) != 0);
        if (c2_out) {
          _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 5U, chartInstance->c2_sfEvent);
          _SFD_CT_CALL(TRANSITION_BEFORE_PROCESSING_TAG, 6U,
                       chartInstance->c2_sfEvent);
          c2_d0 = (*chartInstance->c2_p)[sf_array_bounds_check
            (sfGlobalDebugInstanceStruct, chartInstance->S, 16U, 1, 19, 0U,
             c2__s32_d_(chartInstance, c2_i, 10U, 1U, 1U), 0, 6)];
          c2_d1 = (*chartInstance->c2_p)[sf_array_bounds_check
            (sfGlobalDebugInstanceStruct, chartInstance->S, 16U, 1, 19, 0U,
             c2__s32_d_(chartInstance, c2_i + 1.0, 10U, 8U, 1U), 0, 6)];
          c2_b_out = (CV_TRANSITION_EVAL(6U, (int32_T)_SFD_CCP_CALL(6U, 0,
            CV_RELATIONAL_EVAL(5U, 6U, 0, c2_d0, c2_d1, -1, 2U, c2_d0 < c2_d1)
            != 0U, chartInstance->c2_sfEvent)) != 0);
          if (c2_b_out) {
            _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 6U, chartInstance->c2_sfEvent);
            c2_collision = 1.0;
            _SFD_DATA_RANGE_CHECK(c2_collision, 18U, 5U, 6U,
                                  chartInstance->c2_sfEvent, false);
            exitg2 = 1;
          } else {
            _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 7U, chartInstance->c2_sfEvent);
            c2_i++;
            _SFD_DATA_RANGE_CHECK(c2_i, 13U, 5U, 7U, chartInstance->c2_sfEvent,
                                  false);
            _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
          }
        } else {
          _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 4U, chartInstance->c2_sfEvent);
          c2_collision = 0.0;
          _SFD_DATA_RANGE_CHECK(c2_collision, 18U, 5U, 4U,
                                chartInstance->c2_sfEvent, false);
          exitg2 = 1;
        }
      } while (exitg2 == 0);

      _SFD_SYMBOL_SCOPE_POP();
      _SFD_CS_CALL(FUNCTION_INACTIVE_TAG, 1U, chartInstance->c2_sfEvent);
      _SFD_UNSET_DATA_VALUE_PTR(18U);
      _SFD_UNSET_DATA_VALUE_PTR(13U);
      _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 1U, chartInstance->c2_sfEvent);
      c2_c_out = (CV_TRANSITION_EVAL(12U, (int32_T)_SFD_CCP_CALL(12U, 0,
        c2_collision != 0U, chartInstance->c2_sfEvent)) != 0);
      if (c2_c_out) {
        _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 12U, chartInstance->c2_sfEvent);
        _SFD_SET_DATA_VALUE_PTR(12U, &c2_tmp);
        _SFD_SET_DATA_VALUE_PTR(11U, &c2_b_i);
        _SFD_CS_CALL(FUNCTION_ACTIVE_TAG, 2U, chartInstance->c2_sfEvent);
        _SFD_SYMBOL_SCOPE_PUSH(2U, 0U);
        _SFD_SYMBOL_SCOPE_ADD_IMPORTABLE("i", &c2_b_i, c2_e_sf_marshallOut,
          c2_d_sf_marshallIn);
        _SFD_SYMBOL_SCOPE_ADD_IMPORTABLE("tmp", &c2_tmp, c2_e_sf_marshallOut,
          c2_d_sf_marshallIn);
        _SFD_CS_CALL(STATE_ENTER_DURING_FUNCTION_TAG, 2U,
                     chartInstance->c2_sfEvent);
        c2_b_i = 0.0;
        _SFD_DATA_RANGE_CHECK(c2_b_i, 11U, 4U, 2U, chartInstance->c2_sfEvent,
                              false);
        c2_tmp = 0.0;
        _SFD_DATA_RANGE_CHECK(c2_tmp, 12U, 4U, 2U, chartInstance->c2_sfEvent,
                              false);
        _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 8U, chartInstance->c2_sfEvent);
        c2_b_i = 0.0;
        _SFD_DATA_RANGE_CHECK(c2_b_i, 11U, 5U, 8U, chartInstance->c2_sfEvent,
                              false);
        do {
          exitg1 = 0;
          _SFD_CT_CALL(TRANSITION_BEFORE_PROCESSING_TAG, 10U,
                       chartInstance->c2_sfEvent);
          c2_d_out = (CV_TRANSITION_EVAL(10U, (int32_T)_SFD_CCP_CALL(10U, 0,
            CV_RELATIONAL_EVAL(5U, 10U, 0, c2_b_i, 6.0, -1, 2U, c2_b_i < 6.0) !=
            0U, chartInstance->c2_sfEvent)) != 0);
          if (c2_d_out) {
            _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 10U, chartInstance->c2_sfEvent);
            _SFD_CT_CALL(TRANSITION_BEFORE_PROCESSING_TAG, 11U,
                         chartInstance->c2_sfEvent);
            c2_d2 = (*chartInstance->c2_p)[sf_array_bounds_check
              (sfGlobalDebugInstanceStruct, chartInstance->S, 16U, 25, 27, 0U,
               c2__s32_d_(chartInstance, c2_b_i, 15U, 1U, 1U), 0, 6)];
            c2_d3 = (*chartInstance->c2_p)[sf_array_bounds_check
              (sfGlobalDebugInstanceStruct, chartInstance->S, 16U, 25, 27, 0U,
               c2__s32_d_(chartInstance, c2_b_i + 1.0, 15U, 8U, 1U), 0, 6)];
            c2_e_out = (CV_TRANSITION_EVAL(11U, (int32_T)_SFD_CCP_CALL(11U, 0,
              CV_RELATIONAL_EVAL(5U, 11U, 0, c2_d2, c2_d3, -1, 2U, c2_d2 < c2_d3)
              != 0U, chartInstance->c2_sfEvent)) != 0);
            if (c2_e_out) {
              _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 11U, chartInstance->c2_sfEvent);
              c2_tmp = (*chartInstance->c2_p)[sf_array_bounds_check
                (sfGlobalDebugInstanceStruct, chartInstance->S, 16U, 25, 27, 0U,
                 c2__s32_d_(chartInstance, c2_b_i, 15U, 36U, 11U), 0, 6)];
              _SFD_DATA_RANGE_CHECK(c2_tmp, 12U, 5U, 11U,
                                    chartInstance->c2_sfEvent, false);
              (*chartInstance->c2_p)[sf_array_bounds_check
                (sfGlobalDebugInstanceStruct, chartInstance->S, 16U, 25, 27, 0U,
                 c2__s32_d_(chartInstance, c2_b_i, 15U, 48U, 14U), 0, 6)] =
                (*chartInstance->c2_p)[sf_array_bounds_check
                (sfGlobalDebugInstanceStruct, chartInstance->S, 16U, 25, 27, 0U,
                 c2__s32_d_(chartInstance, c2_b_i + 1.0, 15U, 48U, 14U), 0, 6)];
              for (c2_i27 = 0; c2_i27 < 7; c2_i27++) {
                _SFD_DATA_RANGE_CHECK((*chartInstance->c2_p)[c2_i27], 0U, 5U,
                                      11U, chartInstance->c2_sfEvent, false);
              }

              (*chartInstance->c2_p)[sf_array_bounds_check
                (sfGlobalDebugInstanceStruct, chartInstance->S, 16U, 25, 27, 0U,
                 c2__s32_d_(chartInstance, c2_b_i + 1.0, 15U, 63U, 1U), 0, 6)] =
                c2_tmp;
              for (c2_i28 = 0; c2_i28 < 7; c2_i28++) {
                _SFD_DATA_RANGE_CHECK((*chartInstance->c2_p)[c2_i28], 0U, 5U,
                                      11U, chartInstance->c2_sfEvent, false);
              }

              c2_tmp = (*chartInstance->c2_v)[sf_array_bounds_check
                (sfGlobalDebugInstanceStruct, chartInstance->S, 16U, 25, 27, 1U,
                 c2__s32_d_(chartInstance, c2_b_i, 15U, 96U, 11U), 0, 6)];
              _SFD_DATA_RANGE_CHECK(c2_tmp, 12U, 5U, 11U,
                                    chartInstance->c2_sfEvent, false);
              (*chartInstance->c2_v)[sf_array_bounds_check
                (sfGlobalDebugInstanceStruct, chartInstance->S, 16U, 25, 27, 1U,
                 c2__s32_d_(chartInstance, c2_b_i, 15U, 108U, 14U), 0, 6)] =
                (*chartInstance->c2_v)[sf_array_bounds_check
                (sfGlobalDebugInstanceStruct, chartInstance->S, 16U, 25, 27, 1U,
                 c2__s32_d_(chartInstance, c2_b_i + 1.0, 15U, 108U, 14U), 0, 6)];
              for (c2_i29 = 0; c2_i29 < 7; c2_i29++) {
                _SFD_DATA_RANGE_CHECK((*chartInstance->c2_v)[c2_i29], 1U, 5U,
                                      11U, chartInstance->c2_sfEvent, false);
              }

              (*chartInstance->c2_v)[sf_array_bounds_check
                (sfGlobalDebugInstanceStruct, chartInstance->S, 16U, 25, 27, 1U,
                 c2__s32_d_(chartInstance, c2_b_i + 1.0, 15U, 123U, 1U), 0, 6)] =
                c2_tmp;
              for (c2_i30 = 0; c2_i30 < 7; c2_i30++) {
                _SFD_DATA_RANGE_CHECK((*chartInstance->c2_v)[c2_i30], 1U, 5U,
                                      11U, chartInstance->c2_sfEvent, false);
              }
            } else {
              _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 1U, chartInstance->c2_sfEvent);
            }

            _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 0U, chartInstance->c2_sfEvent);
            c2_b_i++;
            _SFD_DATA_RANGE_CHECK(c2_b_i, 11U, 5U, 0U, chartInstance->c2_sfEvent,
                                  false);
            _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
          } else {
            exitg1 = 1;
          }
        } while (exitg1 == 0);

        _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 9U, chartInstance->c2_sfEvent);
        _SFD_SYMBOL_SCOPE_POP();
        _SFD_CS_CALL(FUNCTION_INACTIVE_TAG, 2U, chartInstance->c2_sfEvent);
        _SFD_UNSET_DATA_VALUE_PTR(12U);
        _SFD_UNSET_DATA_VALUE_PTR(11U);
        _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 2U, chartInstance->c2_sfEvent);
        chartInstance->c2_tp_FreeDynamics = 0U;
        _SFD_CS_CALL(STATE_INACTIVE_TAG, 0U, chartInstance->c2_sfEvent);
        chartInstance->c2_stateChanged = true;
        chartInstance->c2_is_c2_cradle_vr = c2_IN_FreeDynamics;
        _SFD_CS_CALL(STATE_ACTIVE_TAG, 0U, chartInstance->c2_sfEvent);
        chartInstance->c2_tp_FreeDynamics = 1U;
      } else {
        _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 0U, chartInstance->c2_sfEvent);
      }
    }

    _SFD_CC_CALL(EXIT_OUT_OF_FUNCTION_TAG, 0U, chartInstance->c2_sfEvent);
    if (chartInstance->c2_stateChanged) {
      ssSetSolverNeedsReset(chartInstance->S);
    }
  }

  _sfTime_ = sf_get_time(chartInstance->S);
  _SFD_CS_CALL(STATE_ENTER_DURING_FUNCTION_TAG, 0U, chartInstance->c2_sfEvent);
  for (c2_i8 = 0; c2_i8 < 7; c2_i8++) {
    (*chartInstance->c2_p_out)[c2_i8] = (*chartInstance->c2_p)[c2_i8];
  }

  for (c2_i9 = 0; c2_i9 < 7; c2_i9++) {
    _SFD_DATA_RANGE_CHECK((*chartInstance->c2_p_out)[c2_i9], 9U, 4U, 0U,
                          chartInstance->c2_sfEvent, false);
  }

  for (c2_i10 = 0; c2_i10 < 7; c2_i10++) {
    (*chartInstance->c2_v_out)[c2_i10] = (*chartInstance->c2_v)[c2_i10];
  }

  for (c2_i12 = 0; c2_i12 < 7; c2_i12++) {
    _SFD_DATA_RANGE_CHECK((*chartInstance->c2_v_out)[c2_i12], 10U, 4U, 0U,
                          chartInstance->c2_sfEvent, false);
  }

  _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 0U, chartInstance->c2_sfEvent);
  _SFD_SYMBOL_SCOPE_POP();
  _SFD_CHECK_FOR_STATE_INCONSISTENCY(_cradle_vrMachineNumber_,
    chartInstance->chartNumber, chartInstance->instanceNumber);
}

static void mdl_start_c2_cradle_vr(SFc2_cradle_vrInstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static void zeroCrossings_c2_cradle_vr(SFc2_cradle_vrInstanceStruct
  *chartInstance)
{
  real_T c2_collision;
  real_T c2_i;
  boolean_T c2_out;
  real_T c2_d4;
  real_T c2_d5;
  boolean_T c2_b_out;
  boolean_T c2_c_out;
  real_T *c2_zcVar;
  int32_T exitg1;
  c2_zcVar = (real_T *)(ssGetNonsampledZCs_wrapper(chartInstance->S) + 0);
  _sfTime_ = sf_get_time(chartInstance->S);
  if (chartInstance->c2_lastMajorTime == _sfTime_) {
    *c2_zcVar = -1.0;
  } else {
    chartInstance->c2_stateChanged = (boolean_T)0;
    if (chartInstance->c2_is_active_c2_cradle_vr == 0U) {
      chartInstance->c2_stateChanged = true;
    } else {
      _SFD_SET_DATA_VALUE_PTR(18U, &c2_collision);
      _SFD_SET_DATA_VALUE_PTR(13U, &c2_i);
      _SFD_SYMBOL_SCOPE_PUSH(2U, 0U);
      _SFD_SYMBOL_SCOPE_ADD_IMPORTABLE("collision", &c2_collision,
        c2_e_sf_marshallOut, c2_d_sf_marshallIn);
      _SFD_SYMBOL_SCOPE_ADD_IMPORTABLE("i", &c2_i, c2_e_sf_marshallOut,
        c2_d_sf_marshallIn);
      c2_i = 0.0;
      _SFD_DATA_RANGE_CHECK(c2_i, 13U, 4U, 1U, chartInstance->c2_sfEvent, false);
      c2_collision = 0.0;
      _SFD_DATA_RANGE_CHECK(c2_collision, 18U, 4U, 1U, chartInstance->c2_sfEvent,
                            false);
      c2_i = 0.0;
      _SFD_DATA_RANGE_CHECK(c2_i, 13U, 5U, 3U, chartInstance->c2_sfEvent, false);
      do {
        exitg1 = 0;
        c2_out = (CV_TRANSITION_EVAL(5U, (int32_T)_SFD_CCP_CALL(5U, 0,
                    CV_RELATIONAL_EVAL(5U, 5U, 0, c2_i, 6.0, -1, 2U, c2_i < 6.0)
                    != 0U, chartInstance->c2_sfEvent)) != 0);
        if (c2_out) {
          c2_d4 = (*chartInstance->c2_p)[sf_array_bounds_check
            (sfGlobalDebugInstanceStruct, chartInstance->S, 16U, 1, 19, 0U,
             c2__s32_d_(chartInstance, c2_i, 10U, 1U, 1U), 0, 6)];
          c2_d5 = (*chartInstance->c2_p)[sf_array_bounds_check
            (sfGlobalDebugInstanceStruct, chartInstance->S, 16U, 1, 19, 0U,
             c2__s32_d_(chartInstance, c2_i + 1.0, 10U, 8U, 1U), 0, 6)];
          c2_b_out = (CV_TRANSITION_EVAL(6U, (int32_T)_SFD_CCP_CALL(6U, 0,
            CV_RELATIONAL_EVAL(5U, 6U, 0, c2_d4, c2_d5, -1, 2U, c2_d4 < c2_d5)
            != 0U, chartInstance->c2_sfEvent)) != 0);
          if (c2_b_out) {
            c2_collision = 1.0;
            _SFD_DATA_RANGE_CHECK(c2_collision, 18U, 5U, 6U,
                                  chartInstance->c2_sfEvent, false);
            exitg1 = 1;
          } else {
            c2_i++;
            _SFD_DATA_RANGE_CHECK(c2_i, 13U, 5U, 7U, chartInstance->c2_sfEvent,
                                  false);
            _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
          }
        } else {
          c2_collision = 0.0;
          _SFD_DATA_RANGE_CHECK(c2_collision, 18U, 5U, 4U,
                                chartInstance->c2_sfEvent, false);
          exitg1 = 1;
        }
      } while (exitg1 == 0);

      _SFD_SYMBOL_SCOPE_POP();
      _SFD_UNSET_DATA_VALUE_PTR(18U);
      _SFD_UNSET_DATA_VALUE_PTR(13U);
      c2_c_out = (CV_TRANSITION_EVAL(12U, (int32_T)_SFD_CCP_CALL(12U, 0,
        c2_collision != 0U, chartInstance->c2_sfEvent)) != 0);
      if (c2_c_out) {
        chartInstance->c2_stateChanged = true;
      }
    }

    if (chartInstance->c2_stateChanged) {
      *c2_zcVar = 1.0;
    } else {
      *c2_zcVar = -1.0;
    }
  }
}

static void derivatives_c2_cradle_vr(SFc2_cradle_vrInstanceStruct *chartInstance)
{
  int32_T c2_i31;
  int32_T c2_i32;
  int32_T c2_i33;
  int32_T c2_i34;
  int32_T c2_i35;
  int32_T c2_i36;
  int32_T c2_i37;
  int32_T c2_i38;
  int32_T c2_i39;
  int32_T c2_i40;
  int32_T c2_i41;
  real_T (*c2_p_dot)[7];
  real_T (*c2_v_dot)[7];
  c2_v_dot = (real_T (*)[7])(ssGetdX_wrapper(chartInstance->S) + 7);
  c2_p_dot = (real_T (*)[7])(ssGetdX_wrapper(chartInstance->S) + 0);
  for (c2_i31 = 0; c2_i31 < 7; c2_i31++) {
    (*c2_p_dot)[c2_i31] = 0.0;
  }

  for (c2_i32 = 0; c2_i32 < 7; c2_i32++) {
    _SFD_DATA_RANGE_CHECK((*c2_p_dot)[c2_i32], 0U, 1U, 0U,
                          chartInstance->c2_sfEvent, false);
  }

  for (c2_i33 = 0; c2_i33 < 7; c2_i33++) {
    (*c2_v_dot)[c2_i33] = 0.0;
  }

  for (c2_i34 = 0; c2_i34 < 7; c2_i34++) {
    _SFD_DATA_RANGE_CHECK((*c2_v_dot)[c2_i34], 1U, 1U, 0U,
                          chartInstance->c2_sfEvent, false);
  }

  _sfTime_ = sf_get_time(chartInstance->S);
  _SFD_CS_CALL(STATE_ENTER_DURING_FUNCTION_TAG, 0U, chartInstance->c2_sfEvent);
  for (c2_i35 = 0; c2_i35 < 7; c2_i35++) {
    _SFD_DATA_RANGE_CHECK((*chartInstance->c2_p_out)[c2_i35], 9U, 4U, 0U,
                          chartInstance->c2_sfEvent, false);
  }

  for (c2_i36 = 0; c2_i36 < 7; c2_i36++) {
    _SFD_DATA_RANGE_CHECK((*chartInstance->c2_v_out)[c2_i36], 10U, 4U, 0U,
                          chartInstance->c2_sfEvent, false);
  }

  for (c2_i37 = 0; c2_i37 < 7; c2_i37++) {
    (*c2_p_dot)[c2_i37] = (*chartInstance->c2_v)[c2_i37];
  }

  for (c2_i38 = 0; c2_i38 < 7; c2_i38++) {
    _SFD_DATA_RANGE_CHECK((*c2_p_dot)[c2_i38], 0U, 4U, 0U,
                          chartInstance->c2_sfEvent, false);
  }

  for (c2_i39 = 0; c2_i39 < 7; c2_i39++) {
    (*c2_v_dot)[c2_i39] = muDoubleScalarSin((*chartInstance->c2_p)[c2_i39]);
  }

  for (c2_i40 = 0; c2_i40 < 7; c2_i40++) {
    (*c2_v_dot)[c2_i40] *= -9.81;
  }

  for (c2_i41 = 0; c2_i41 < 7; c2_i41++) {
    _SFD_DATA_RANGE_CHECK((*c2_v_dot)[c2_i41], 1U, 4U, 0U,
                          chartInstance->c2_sfEvent, false);
  }

  _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 0U, chartInstance->c2_sfEvent);
}

static void outputs_c2_cradle_vr(SFc2_cradle_vrInstanceStruct *chartInstance)
{
  int32_T c2_i42;
  int32_T c2_i43;
  int32_T c2_i44;
  int32_T c2_i45;
  _sfTime_ = sf_get_time(chartInstance->S);
  _SFD_CS_CALL(STATE_ENTER_DURING_FUNCTION_TAG, 0U, chartInstance->c2_sfEvent);
  for (c2_i42 = 0; c2_i42 < 7; c2_i42++) {
    (*chartInstance->c2_p_out)[c2_i42] = (*chartInstance->c2_p)[c2_i42];
  }

  for (c2_i43 = 0; c2_i43 < 7; c2_i43++) {
    _SFD_DATA_RANGE_CHECK((*chartInstance->c2_p_out)[c2_i43], 9U, 4U, 0U,
                          chartInstance->c2_sfEvent, false);
  }

  for (c2_i44 = 0; c2_i44 < 7; c2_i44++) {
    (*chartInstance->c2_v_out)[c2_i44] = (*chartInstance->c2_v)[c2_i44];
  }

  for (c2_i45 = 0; c2_i45 < 7; c2_i45++) {
    _SFD_DATA_RANGE_CHECK((*chartInstance->c2_v_out)[c2_i45], 10U, 4U, 0U,
                          chartInstance->c2_sfEvent, false);
  }

  _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 0U, chartInstance->c2_sfEvent);
}

static void initSimStructsc2_cradle_vr(SFc2_cradle_vrInstanceStruct
  *chartInstance)
{
  (void)chartInstance;
}

static void c2_eml_ini_fcn_to_be_inlined_70(SFc2_cradle_vrInstanceStruct
  *chartInstance)
{
  (void)chartInstance;
}

static void c2_eml_term_fcn_to_be_inlined_70(SFc2_cradle_vrInstanceStruct
  *chartInstance)
{
  (void)chartInstance;
}

static void init_script_number_translation(uint32_T c2_machineNumber, uint32_T
  c2_chartNumber, uint32_T c2_instanceNumber)
{
  (void)c2_machineNumber;
  (void)c2_chartNumber;
  (void)c2_instanceNumber;
}

const mxArray *sf_c2_cradle_vr_get_eml_resolved_functions_info(void)
{
  const mxArray *c2_nameCaptureInfo = NULL;
  c2_nameCaptureInfo = NULL;
  sf_mex_assign(&c2_nameCaptureInfo, sf_mex_create("nameCaptureInfo", NULL, 0,
    0U, 1U, 0U, 2, 0, 1), false);
  return c2_nameCaptureInfo;
}

static const mxArray *c2_emlrt_marshallOut(SFc2_cradle_vrInstanceStruct
  *chartInstance, const int32_T c2_u)
{
  const mxArray *c2_y = NULL;
  (void)chartInstance;
  c2_y = NULL;
  sf_mex_assign(&c2_y, sf_mex_create("y", &c2_u, 6, 0U, 0U, 0U, 0), false);
  return c2_y;
}

static const mxArray *c2_sf_marshallOut(void *chartInstanceVoid, void *c2_inData)
{
  const mxArray *c2_mxArrayOutData = NULL;
  SFc2_cradle_vrInstanceStruct *chartInstance;
  chartInstance = (SFc2_cradle_vrInstanceStruct *)chartInstanceVoid;
  c2_mxArrayOutData = NULL;
  sf_mex_assign(&c2_mxArrayOutData, c2_emlrt_marshallOut(chartInstance,
    *(int32_T *)c2_inData), false);
  return c2_mxArrayOutData;
}

static int32_T c2_emlrt_marshallIn(SFc2_cradle_vrInstanceStruct *chartInstance,
  const mxArray *c2_b_sfEvent, const char_T *c2_identifier)
{
  int32_T c2_y;
  emlrtMsgIdentifier c2_thisId;
  c2_thisId.fIdentifier = c2_identifier;
  c2_thisId.fParent = NULL;
  c2_thisId.bParentIsCell = false;
  c2_y = c2_b_emlrt_marshallIn(chartInstance, sf_mex_dup(c2_b_sfEvent),
    &c2_thisId);
  sf_mex_destroy(&c2_b_sfEvent);
  return c2_y;
}

static int32_T c2_b_emlrt_marshallIn(SFc2_cradle_vrInstanceStruct *chartInstance,
  const mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId)
{
  int32_T c2_y;
  int32_T c2_i46;
  (void)chartInstance;
  sf_mex_import(c2_parentId, sf_mex_dup(c2_u), &c2_i46, 1, 6, 0U, 0, 0U, 0);
  c2_y = c2_i46;
  sf_mex_destroy(&c2_u);
  return c2_y;
}

static void c2_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c2_mxArrayInData, const char_T *c2_varName, void *c2_outData)
{
  SFc2_cradle_vrInstanceStruct *chartInstance;
  chartInstance = (SFc2_cradle_vrInstanceStruct *)chartInstanceVoid;
  *(int32_T *)c2_outData = c2_emlrt_marshallIn(chartInstance, sf_mex_dup
    (c2_mxArrayInData), c2_varName);
  sf_mex_destroy(&c2_mxArrayInData);
}

static const mxArray *c2_b_emlrt_marshallOut(SFc2_cradle_vrInstanceStruct
  *chartInstance, const uint8_T c2_u)
{
  const mxArray *c2_y = NULL;
  (void)chartInstance;
  c2_y = NULL;
  sf_mex_assign(&c2_y, sf_mex_create("y", &c2_u, 3, 0U, 0U, 0U, 0), false);
  return c2_y;
}

static const mxArray *c2_b_sf_marshallOut(void *chartInstanceVoid, void
  *c2_inData)
{
  const mxArray *c2_mxArrayOutData = NULL;
  SFc2_cradle_vrInstanceStruct *chartInstance;
  chartInstance = (SFc2_cradle_vrInstanceStruct *)chartInstanceVoid;
  c2_mxArrayOutData = NULL;
  sf_mex_assign(&c2_mxArrayOutData, c2_b_emlrt_marshallOut(chartInstance,
    *(uint8_T *)c2_inData), false);
  return c2_mxArrayOutData;
}

static uint8_T c2_c_emlrt_marshallIn(SFc2_cradle_vrInstanceStruct *chartInstance,
  const mxArray *c2_b_tp_FreeDynamics, const char_T *c2_identifier)
{
  uint8_T c2_y;
  emlrtMsgIdentifier c2_thisId;
  c2_thisId.fIdentifier = c2_identifier;
  c2_thisId.fParent = NULL;
  c2_thisId.bParentIsCell = false;
  c2_y = c2_d_emlrt_marshallIn(chartInstance, sf_mex_dup(c2_b_tp_FreeDynamics),
    &c2_thisId);
  sf_mex_destroy(&c2_b_tp_FreeDynamics);
  return c2_y;
}

static uint8_T c2_d_emlrt_marshallIn(SFc2_cradle_vrInstanceStruct *chartInstance,
  const mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId)
{
  uint8_T c2_y;
  uint8_T c2_u0;
  (void)chartInstance;
  sf_mex_import(c2_parentId, sf_mex_dup(c2_u), &c2_u0, 1, 3, 0U, 0, 0U, 0);
  c2_y = c2_u0;
  sf_mex_destroy(&c2_u);
  return c2_y;
}

static void c2_b_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c2_mxArrayInData, const char_T *c2_varName, void *c2_outData)
{
  SFc2_cradle_vrInstanceStruct *chartInstance;
  chartInstance = (SFc2_cradle_vrInstanceStruct *)chartInstanceVoid;
  *(uint8_T *)c2_outData = c2_c_emlrt_marshallIn(chartInstance, sf_mex_dup
    (c2_mxArrayInData), c2_varName);
  sf_mex_destroy(&c2_mxArrayInData);
}

static const mxArray *c2_c_emlrt_marshallOut(SFc2_cradle_vrInstanceStruct
  *chartInstance, const boolean_T c2_u)
{
  const mxArray *c2_y = NULL;
  (void)chartInstance;
  c2_y = NULL;
  sf_mex_assign(&c2_y, sf_mex_create("y", &c2_u, 11, 0U, 0U, 0U, 0), false);
  return c2_y;
}

static const mxArray *c2_c_sf_marshallOut(void *chartInstanceVoid, void
  *c2_inData)
{
  const mxArray *c2_mxArrayOutData = NULL;
  SFc2_cradle_vrInstanceStruct *chartInstance;
  chartInstance = (SFc2_cradle_vrInstanceStruct *)chartInstanceVoid;
  c2_mxArrayOutData = NULL;
  sf_mex_assign(&c2_mxArrayOutData, c2_c_emlrt_marshallOut(chartInstance,
    *(boolean_T *)c2_inData), false);
  return c2_mxArrayOutData;
}

static const mxArray *c2_d_emlrt_marshallOut(SFc2_cradle_vrInstanceStruct
  *chartInstance, const real_T c2_u[7])
{
  const mxArray *c2_y = NULL;
  (void)chartInstance;
  c2_y = NULL;
  sf_mex_assign(&c2_y, sf_mex_create("y", c2_u, 0, 0U, 1U, 0U, 1, 7), false);
  return c2_y;
}

static const mxArray *c2_d_sf_marshallOut(void *chartInstanceVoid, void
  *c2_inData)
{
  const mxArray *c2_mxArrayOutData = NULL;
  SFc2_cradle_vrInstanceStruct *chartInstance;
  chartInstance = (SFc2_cradle_vrInstanceStruct *)chartInstanceVoid;
  c2_mxArrayOutData = NULL;
  sf_mex_assign(&c2_mxArrayOutData, c2_d_emlrt_marshallOut(chartInstance,
    *(real_T (*)[7])c2_inData), false);
  return c2_mxArrayOutData;
}

static void c2_e_emlrt_marshallIn(SFc2_cradle_vrInstanceStruct *chartInstance,
  const mxArray *c2_b_p_out, const char_T *c2_identifier, real_T c2_y[7])
{
  emlrtMsgIdentifier c2_thisId;
  c2_thisId.fIdentifier = c2_identifier;
  c2_thisId.fParent = NULL;
  c2_thisId.bParentIsCell = false;
  c2_f_emlrt_marshallIn(chartInstance, sf_mex_dup(c2_b_p_out), &c2_thisId, c2_y);
  sf_mex_destroy(&c2_b_p_out);
}

static void c2_f_emlrt_marshallIn(SFc2_cradle_vrInstanceStruct *chartInstance,
  const mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId, real_T c2_y[7])
{
  real_T c2_dv0[7];
  int32_T c2_i47;
  (void)chartInstance;
  sf_mex_import(c2_parentId, sf_mex_dup(c2_u), c2_dv0, 1, 0, 0U, 1, 0U, 1, 7);
  for (c2_i47 = 0; c2_i47 < 7; c2_i47++) {
    c2_y[c2_i47] = c2_dv0[c2_i47];
  }

  sf_mex_destroy(&c2_u);
}

static void c2_c_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c2_mxArrayInData, const char_T *c2_varName, void *c2_outData)
{
  real_T c2_dv1[7];
  int32_T c2_i48;
  SFc2_cradle_vrInstanceStruct *chartInstance;
  chartInstance = (SFc2_cradle_vrInstanceStruct *)chartInstanceVoid;
  c2_e_emlrt_marshallIn(chartInstance, sf_mex_dup(c2_mxArrayInData), c2_varName,
                        c2_dv1);
  for (c2_i48 = 0; c2_i48 < 7; c2_i48++) {
    (*(real_T (*)[7])c2_outData)[c2_i48] = c2_dv1[c2_i48];
  }

  sf_mex_destroy(&c2_mxArrayInData);
}

static const mxArray *c2_e_emlrt_marshallOut(SFc2_cradle_vrInstanceStruct
  *chartInstance, const real_T c2_u)
{
  const mxArray *c2_y = NULL;
  (void)chartInstance;
  c2_y = NULL;
  sf_mex_assign(&c2_y, sf_mex_create("y", &c2_u, 0, 0U, 0U, 0U, 0), false);
  return c2_y;
}

static const mxArray *c2_e_sf_marshallOut(void *chartInstanceVoid, void
  *c2_inData)
{
  const mxArray *c2_mxArrayOutData = NULL;
  SFc2_cradle_vrInstanceStruct *chartInstance;
  chartInstance = (SFc2_cradle_vrInstanceStruct *)chartInstanceVoid;
  c2_mxArrayOutData = NULL;
  sf_mex_assign(&c2_mxArrayOutData, c2_e_emlrt_marshallOut(chartInstance,
    *(real_T *)c2_inData), false);
  return c2_mxArrayOutData;
}

static real_T c2_g_emlrt_marshallIn(SFc2_cradle_vrInstanceStruct *chartInstance,
  const mxArray *c2_i, const char_T *c2_identifier)
{
  real_T c2_y;
  emlrtMsgIdentifier c2_thisId;
  c2_thisId.fIdentifier = c2_identifier;
  c2_thisId.fParent = NULL;
  c2_thisId.bParentIsCell = false;
  c2_y = c2_h_emlrt_marshallIn(chartInstance, sf_mex_dup(c2_i), &c2_thisId);
  sf_mex_destroy(&c2_i);
  return c2_y;
}

static real_T c2_h_emlrt_marshallIn(SFc2_cradle_vrInstanceStruct *chartInstance,
  const mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId)
{
  real_T c2_y;
  real_T c2_d6;
  (void)chartInstance;
  sf_mex_import(c2_parentId, sf_mex_dup(c2_u), &c2_d6, 1, 0, 0U, 0, 0U, 0);
  c2_y = c2_d6;
  sf_mex_destroy(&c2_u);
  return c2_y;
}

static void c2_d_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c2_mxArrayInData, const char_T *c2_varName, void *c2_outData)
{
  SFc2_cradle_vrInstanceStruct *chartInstance;
  chartInstance = (SFc2_cradle_vrInstanceStruct *)chartInstanceVoid;
  *(real_T *)c2_outData = c2_g_emlrt_marshallIn(chartInstance, sf_mex_dup
    (c2_mxArrayInData), c2_varName);
  sf_mex_destroy(&c2_mxArrayInData);
}

static const mxArray *c2_f_emlrt_marshallOut(SFc2_cradle_vrInstanceStruct
  *chartInstance)
{
  const mxArray *c2_y;
  int32_T c2_i49;
  real_T c2_dv2[7];
  int32_T c2_i50;
  real_T c2_dv3[7];
  int32_T c2_i51;
  real_T c2_dv4[7];
  int32_T c2_i52;
  real_T c2_dv5[7];
  c2_y = NULL;
  c2_y = NULL;
  sf_mex_assign(&c2_y, sf_mex_createcellmatrix(6, 1), false);
  for (c2_i49 = 0; c2_i49 < 7; c2_i49++) {
    c2_dv2[c2_i49] = (*chartInstance->c2_p_out)[c2_i49];
  }

  sf_mex_setcell(c2_y, 0, c2_d_emlrt_marshallOut(chartInstance, c2_dv2));
  for (c2_i50 = 0; c2_i50 < 7; c2_i50++) {
    c2_dv3[c2_i50] = (*chartInstance->c2_v_out)[c2_i50];
  }

  sf_mex_setcell(c2_y, 1, c2_d_emlrt_marshallOut(chartInstance, c2_dv3));
  for (c2_i51 = 0; c2_i51 < 7; c2_i51++) {
    c2_dv4[c2_i51] = (*chartInstance->c2_p)[c2_i51];
  }

  sf_mex_setcell(c2_y, 2, c2_d_emlrt_marshallOut(chartInstance, c2_dv4));
  for (c2_i52 = 0; c2_i52 < 7; c2_i52++) {
    c2_dv5[c2_i52] = (*chartInstance->c2_v)[c2_i52];
  }

  sf_mex_setcell(c2_y, 3, c2_d_emlrt_marshallOut(chartInstance, c2_dv5));
  sf_mex_setcell(c2_y, 4, c2_b_emlrt_marshallOut(chartInstance,
    chartInstance->c2_is_active_c2_cradle_vr));
  sf_mex_setcell(c2_y, 5, c2_b_emlrt_marshallOut(chartInstance,
    chartInstance->c2_is_c2_cradle_vr));
  return c2_y;
}

static void c2_i_emlrt_marshallIn(SFc2_cradle_vrInstanceStruct *chartInstance,
  const mxArray *c2_u)
{
  real_T c2_dv6[7];
  int32_T c2_i53;
  real_T c2_dv7[7];
  int32_T c2_i54;
  real_T c2_dv8[7];
  int32_T c2_i55;
  real_T c2_dv9[7];
  int32_T c2_i56;
  c2_e_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell("p_out", c2_u,
    0)), "p_out", c2_dv6);
  for (c2_i53 = 0; c2_i53 < 7; c2_i53++) {
    (*chartInstance->c2_p_out)[c2_i53] = c2_dv6[c2_i53];
  }

  c2_e_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell("v_out", c2_u,
    1)), "v_out", c2_dv7);
  for (c2_i54 = 0; c2_i54 < 7; c2_i54++) {
    (*chartInstance->c2_v_out)[c2_i54] = c2_dv7[c2_i54];
  }

  c2_e_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell("p", c2_u, 2)),
                        "p", c2_dv8);
  for (c2_i55 = 0; c2_i55 < 7; c2_i55++) {
    (*chartInstance->c2_p)[c2_i55] = c2_dv8[c2_i55];
  }

  c2_e_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell("v", c2_u, 3)),
                        "v", c2_dv9);
  for (c2_i56 = 0; c2_i56 < 7; c2_i56++) {
    (*chartInstance->c2_v)[c2_i56] = c2_dv9[c2_i56];
  }

  chartInstance->c2_is_active_c2_cradle_vr = c2_c_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell("is_active_c2_cradle_vr", c2_u, 4)),
    "is_active_c2_cradle_vr");
  chartInstance->c2_is_c2_cradle_vr = c2_c_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell("is_c2_cradle_vr", c2_u, 5)), "is_c2_cradle_vr");
  sf_mex_assign(&chartInstance->c2_setSimStateSideEffectsInfo,
                c2_j_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(
    "setSimStateSideEffectsInfo", c2_u, 6)), "setSimStateSideEffectsInfo"), true);
  sf_mex_destroy(&c2_u);
}

static const mxArray *c2_j_emlrt_marshallIn(SFc2_cradle_vrInstanceStruct
  *chartInstance, const mxArray *c2_b_setSimStateSideEffectsInfo, const char_T
  *c2_identifier)
{
  const mxArray *c2_y = NULL;
  emlrtMsgIdentifier c2_thisId;
  c2_y = NULL;
  c2_thisId.fIdentifier = c2_identifier;
  c2_thisId.fParent = NULL;
  c2_thisId.bParentIsCell = false;
  sf_mex_assign(&c2_y, c2_k_emlrt_marshallIn(chartInstance, sf_mex_dup
    (c2_b_setSimStateSideEffectsInfo), &c2_thisId), false);
  sf_mex_destroy(&c2_b_setSimStateSideEffectsInfo);
  return c2_y;
}

static const mxArray *c2_k_emlrt_marshallIn(SFc2_cradle_vrInstanceStruct
  *chartInstance, const mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId)
{
  const mxArray *c2_y = NULL;
  (void)chartInstance;
  (void)c2_parentId;
  c2_y = NULL;
  sf_mex_assign(&c2_y, sf_mex_duplicatearraysafe(&c2_u), false);
  sf_mex_destroy(&c2_u);
  return c2_y;
}

static const mxArray *sf_get_hover_data_for_msg(SFc2_cradle_vrInstanceStruct
  *chartInstance, int32_T c2_ssid)
{
  (void)chartInstance;
  (void)c2_ssid;
  return NULL;
}

static void c2_init_sf_message_store_memory(SFc2_cradle_vrInstanceStruct
  *chartInstance)
{
  (void)chartInstance;
}

static int32_T c2__s32_d_(SFc2_cradle_vrInstanceStruct *chartInstance, real_T
  c2_b, uint32_T c2_ssid, int32_T c2_offset, int32_T c2_length)
{
  int32_T c2_a;
  real_T c2_b_b;
  c2_a = (int32_T)c2_b;
  if (c2_b < 0.0) {
    c2_b_b = muDoubleScalarCeil(c2_b);
  } else {
    c2_b_b = muDoubleScalarFloor(c2_b);
  }

  if ((real_T)c2_a != c2_b_b) {
    _SFD_OVERFLOW_DETECTION(SFDB_OVERFLOW, 1U, c2_ssid, c2_offset, c2_length, 0U,
      chartInstance->c2_sfEvent, false);
  }

  return c2_a;
}

static void init_dsm_address_info(SFc2_cradle_vrInstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static void init_simulink_io_address(SFc2_cradle_vrInstanceStruct *chartInstance)
{
  chartInstance->c2_input0 = (boolean_T *)ssGetInputPortSignal_wrapper
    (chartInstance->S, 0);
  chartInstance->c2_p_out = (real_T (*)[7])ssGetOutputPortSignal_wrapper
    (chartInstance->S, 1);
  chartInstance->c2_v_out = (real_T (*)[7])ssGetOutputPortSignal_wrapper
    (chartInstance->S, 2);
  chartInstance->c2_p = (real_T (*)[7])(ssGetContStates_wrapper(chartInstance->S)
    + 0);
  chartInstance->c2_v = (real_T (*)[7])(ssGetContStates_wrapper(chartInstance->S)
    + 7);
  chartInstance->c2_input1 = (boolean_T *)ssGetInputPortSignal_wrapper
    (chartInstance->S, 1);
  chartInstance->c2_input2 = (boolean_T *)ssGetInputPortSignal_wrapper
    (chartInstance->S, 2);
  chartInstance->c2_input3 = (boolean_T *)ssGetInputPortSignal_wrapper
    (chartInstance->S, 3);
  chartInstance->c2_input4 = (boolean_T *)ssGetInputPortSignal_wrapper
    (chartInstance->S, 4);
  chartInstance->c2_input5 = (boolean_T *)ssGetInputPortSignal_wrapper
    (chartInstance->S, 5);
  chartInstance->c2_input6 = (boolean_T *)ssGetInputPortSignal_wrapper
    (chartInstance->S, 6);
}

/* SFunction Glue Code */
#ifdef utFree
#undef utFree
#endif

#ifdef utMalloc
#undef utMalloc
#endif

#ifdef __cplusplus

extern "C" void *utMalloc(size_t size);
extern "C" void utFree(void*);

#else

extern void *utMalloc(size_t size);
extern void utFree(void*);

#endif

void sf_c2_cradle_vr_get_check_sum(mxArray *plhs[])
{
  ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(2610178312U);
  ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(910460757U);
  ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(2964443255U);
  ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(1278948374U);
}

mxArray* sf_c2_cradle_vr_get_post_codegen_info(void);
mxArray *sf_c2_cradle_vr_get_autoinheritance_info(void)
{
  const char *autoinheritanceFields[] = { "checksum", "inputs", "parameters",
    "outputs", "locals", "postCodegenInfo" };

  mxArray *mxAutoinheritanceInfo = mxCreateStructMatrix(1, 1, sizeof
    (autoinheritanceFields)/sizeof(autoinheritanceFields[0]),
    autoinheritanceFields);

  {
    mxArray *mxChecksum = mxCreateString("l1eXdUw6wLR1SzIqvdqZUD");
    mxSetField(mxAutoinheritanceInfo,0,"checksum",mxChecksum);
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,7,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,0,mxREAL);
      double *pr = mxGetPr(mxSize);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt", "isFixedPointType" };

      mxArray *mxType = mxCreateStructMatrix(1,1,sizeof(typeFields)/sizeof
        (typeFields[0]),typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(1));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxType,0,"isFixedPointType",mxCreateDoubleScalar(0));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,0,mxREAL);
      double *pr = mxGetPr(mxSize);
      mxSetField(mxData,1,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt", "isFixedPointType" };

      mxArray *mxType = mxCreateStructMatrix(1,1,sizeof(typeFields)/sizeof
        (typeFields[0]),typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(1));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxType,0,"isFixedPointType",mxCreateDoubleScalar(0));
      mxSetField(mxData,1,"type",mxType);
    }

    mxSetField(mxData,1,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,0,mxREAL);
      double *pr = mxGetPr(mxSize);
      mxSetField(mxData,2,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt", "isFixedPointType" };

      mxArray *mxType = mxCreateStructMatrix(1,1,sizeof(typeFields)/sizeof
        (typeFields[0]),typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(1));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxType,0,"isFixedPointType",mxCreateDoubleScalar(0));
      mxSetField(mxData,2,"type",mxType);
    }

    mxSetField(mxData,2,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,0,mxREAL);
      double *pr = mxGetPr(mxSize);
      mxSetField(mxData,3,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt", "isFixedPointType" };

      mxArray *mxType = mxCreateStructMatrix(1,1,sizeof(typeFields)/sizeof
        (typeFields[0]),typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(1));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxType,0,"isFixedPointType",mxCreateDoubleScalar(0));
      mxSetField(mxData,3,"type",mxType);
    }

    mxSetField(mxData,3,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,0,mxREAL);
      double *pr = mxGetPr(mxSize);
      mxSetField(mxData,4,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt", "isFixedPointType" };

      mxArray *mxType = mxCreateStructMatrix(1,1,sizeof(typeFields)/sizeof
        (typeFields[0]),typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(1));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxType,0,"isFixedPointType",mxCreateDoubleScalar(0));
      mxSetField(mxData,4,"type",mxType);
    }

    mxSetField(mxData,4,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,0,mxREAL);
      double *pr = mxGetPr(mxSize);
      mxSetField(mxData,5,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt", "isFixedPointType" };

      mxArray *mxType = mxCreateStructMatrix(1,1,sizeof(typeFields)/sizeof
        (typeFields[0]),typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(1));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxType,0,"isFixedPointType",mxCreateDoubleScalar(0));
      mxSetField(mxData,5,"type",mxType);
    }

    mxSetField(mxData,5,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,0,mxREAL);
      double *pr = mxGetPr(mxSize);
      mxSetField(mxData,6,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt", "isFixedPointType" };

      mxArray *mxType = mxCreateStructMatrix(1,1,sizeof(typeFields)/sizeof
        (typeFields[0]),typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(1));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxType,0,"isFixedPointType",mxCreateDoubleScalar(0));
      mxSetField(mxData,6,"type",mxType);
    }

    mxSetField(mxData,6,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"inputs",mxData);
  }

  {
    mxSetField(mxAutoinheritanceInfo,0,"parameters",mxCreateDoubleMatrix(0,0,
                mxREAL));
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,2,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,1,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(7);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt", "isFixedPointType" };

      mxArray *mxType = mxCreateStructMatrix(1,1,sizeof(typeFields)/sizeof
        (typeFields[0]),typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxType,0,"isFixedPointType",mxCreateDoubleScalar(0));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,1,mxREAL);
      double *pr = mxGetPr(mxSize);
      pr[0] = (double)(7);
      mxSetField(mxData,1,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt", "isFixedPointType" };

      mxArray *mxType = mxCreateStructMatrix(1,1,sizeof(typeFields)/sizeof
        (typeFields[0]),typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxType,0,"isFixedPointType",mxCreateDoubleScalar(0));
      mxSetField(mxData,1,"type",mxType);
    }

    mxSetField(mxData,1,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"outputs",mxData);
  }

  {
    mxSetField(mxAutoinheritanceInfo,0,"locals",mxCreateDoubleMatrix(0,0,mxREAL));
  }

  {
    mxArray* mxPostCodegenInfo = sf_c2_cradle_vr_get_post_codegen_info();
    mxSetField(mxAutoinheritanceInfo,0,"postCodegenInfo",mxPostCodegenInfo);
  }

  return(mxAutoinheritanceInfo);
}

mxArray *sf_c2_cradle_vr_third_party_uses_info(void)
{
  mxArray * mxcell3p = mxCreateCellMatrix(1,0);
  return(mxcell3p);
}

mxArray *sf_c2_cradle_vr_jit_fallback_info(void)
{
  const char *infoFields[] = { "fallbackType", "fallbackReason",
    "hiddenFallbackType", "hiddenFallbackReason", "incompatibleSymbol" };

  mxArray *mxInfo = mxCreateStructMatrix(1, 1, 5, infoFields);
  mxArray *fallbackType = mxCreateString("early");
  mxArray *fallbackReason = mxCreateString("plant_model_chart");
  mxArray *hiddenFallbackType = mxCreateString("");
  mxArray *hiddenFallbackReason = mxCreateString("");
  mxArray *incompatibleSymbol = mxCreateString("");
  mxSetField(mxInfo, 0, infoFields[0], fallbackType);
  mxSetField(mxInfo, 0, infoFields[1], fallbackReason);
  mxSetField(mxInfo, 0, infoFields[2], hiddenFallbackType);
  mxSetField(mxInfo, 0, infoFields[3], hiddenFallbackReason);
  mxSetField(mxInfo, 0, infoFields[4], incompatibleSymbol);
  return mxInfo;
}

mxArray *sf_c2_cradle_vr_updateBuildInfo_args_info(void)
{
  mxArray *mxBIArgs = mxCreateCellMatrix(1,0);
  return mxBIArgs;
}

mxArray* sf_c2_cradle_vr_get_post_codegen_info(void)
{
  const char* fieldNames[] = { "exportedFunctionsUsedByThisChart",
    "exportedFunctionsChecksum" };

  mwSize dims[2] = { 1, 1 };

  mxArray* mxPostCodegenInfo = mxCreateStructArray(2, dims, sizeof(fieldNames)/
    sizeof(fieldNames[0]), fieldNames);

  {
    mxArray* mxExportedFunctionsChecksum = mxCreateString("");
    mwSize exp_dims[2] = { 0, 1 };

    mxArray* mxExportedFunctionsUsedByThisChart = mxCreateCellArray(2, exp_dims);
    mxSetField(mxPostCodegenInfo, 0, "exportedFunctionsUsedByThisChart",
               mxExportedFunctionsUsedByThisChart);
    mxSetField(mxPostCodegenInfo, 0, "exportedFunctionsChecksum",
               mxExportedFunctionsChecksum);
  }

  return mxPostCodegenInfo;
}

static const mxArray *sf_get_sim_state_info_c2_cradle_vr(void)
{
  const char *infoFields[] = { "chartChecksum", "varInfo" };

  mxArray *mxInfo = mxCreateStructMatrix(1, 1, 2, infoFields);
  const char *infoEncStr[] = {
    "100 S1x6'type','srcId','name','auxInfo'{{M[1],M[25],T\"p_out\",},{M[1],M[26],T\"v_out\",},{M[5],M[30],T\"p\",},{M[5],M[31],T\"v\",},{M[8],M[0],T\"is_active_c2_cradle_vr\",},{M[9],M[0],T\"is_c2_cradle_vr\",}}"
  };

  mxArray *mxVarInfo = sf_mex_decode_encoded_mx_struct_array(infoEncStr, 6, 10);
  mxArray *mxChecksum = mxCreateDoubleMatrix(1, 4, mxREAL);
  sf_c2_cradle_vr_get_check_sum(&mxChecksum);
  mxSetField(mxInfo, 0, infoFields[0], mxChecksum);
  mxSetField(mxInfo, 0, infoFields[1], mxVarInfo);
  return mxInfo;
}

static const mxArray* sf_opaque_get_hover_data_for_msg(void* chartInstance,
  int32_T msgSSID)
{
  return sf_get_hover_data_for_msg( (SFc2_cradle_vrInstanceStruct *)
    chartInstance, msgSSID);
}

static void chart_debug_initialization(SimStruct *S, unsigned int
  fullDebuggerInitialization)
{
  if (!sim_mode_is_rtw_gen(S)) {
    SFc2_cradle_vrInstanceStruct *chartInstance = (SFc2_cradle_vrInstanceStruct *)
      sf_get_chart_instance_ptr(S);
    if (ssIsFirstInitCond(S) && fullDebuggerInitialization==1) {
      /* do this only if simulation is starting */
      {
        unsigned int chartAlreadyPresent;
        chartAlreadyPresent = sf_debug_initialize_chart
          (sfGlobalDebugInstanceStruct,
           _cradle_vrMachineNumber_,
           2,
           3,
           13,
           0,
           19,
           0,
           0,
           0,
           0,
           0,
           &chartInstance->chartNumber,
           &chartInstance->instanceNumber,
           (void *)S);

        /* Each instance must initialize its own list of scripts */
        init_script_number_translation(_cradle_vrMachineNumber_,
          chartInstance->chartNumber,chartInstance->instanceNumber);
        if (chartAlreadyPresent==0) {
          /* this is the first instance */
          sf_debug_set_chart_disable_implicit_casting
            (sfGlobalDebugInstanceStruct,_cradle_vrMachineNumber_,
             chartInstance->chartNumber,1);
          sf_debug_set_chart_event_thresholds(sfGlobalDebugInstanceStruct,
            _cradle_vrMachineNumber_,
            chartInstance->chartNumber,
            0,
            0,
            0);
          _SFD_SET_DATA_PROPS(0,0,0,0,"p");
          _SFD_SET_DATA_PROPS(1,0,0,0,"v");
          _SFD_SET_DATA_PROPS(2,1,1,0,"input0");
          _SFD_SET_DATA_PROPS(3,1,1,0,"input1");
          _SFD_SET_DATA_PROPS(4,1,1,0,"input2");
          _SFD_SET_DATA_PROPS(5,1,1,0,"input3");
          _SFD_SET_DATA_PROPS(6,1,1,0,"input4");
          _SFD_SET_DATA_PROPS(7,1,1,0,"input5");
          _SFD_SET_DATA_PROPS(8,1,1,0,"input6");
          _SFD_SET_DATA_PROPS(9,2,0,1,"p_out");
          _SFD_SET_DATA_PROPS(10,2,0,1,"v_out");
          _SFD_SET_DATA_PROPS(11,6,0,0,"");
          _SFD_SET_DATA_PROPS(12,6,0,0,"");
          _SFD_SET_DATA_PROPS(13,6,0,0,"");
          _SFD_SET_DATA_PROPS(14,7,0,0,"g");
          _SFD_SET_DATA_PROPS(15,7,0,0,"k");
          _SFD_SET_DATA_PROPS(16,7,0,0,"l");
          _SFD_SET_DATA_PROPS(17,7,0,0,"pi");
          _SFD_SET_DATA_PROPS(18,9,0,0,"");
          _SFD_STATE_INFO(0,0,0);
          _SFD_STATE_INFO(1,0,2);
          _SFD_STATE_INFO(2,0,2);
          _SFD_CH_SUBSTATE_COUNT(1);
          _SFD_CH_SUBSTATE_DECOMP(0);
          _SFD_CH_SUBSTATE_INDEX(0,0);
          _SFD_ST_SUBSTATE_COUNT(0,0);
        }

        _SFD_CV_INIT_CHART(1,0,0,0);

        {
          _SFD_CV_INIT_STATE(0,0,0,0,0,0,NULL,NULL);
        }

        {
          _SFD_CV_INIT_STATE(1,0,0,0,0,0,NULL,NULL);
        }

        {
          _SFD_CV_INIT_STATE(2,0,0,0,0,0,NULL,NULL);
        }

        _SFD_CV_INIT_TRANS(2,0,NULL,NULL,0,NULL);

        {
          static unsigned int sStartGuardMap[] = { 1 };

          static unsigned int sEndGuardMap[] = { 22 };

          static int sPostFixPredicateTree[] = { 0 };

          _SFD_CV_INIT_TRANS(12,1,&(sStartGuardMap[0]),&(sEndGuardMap[0]),1,
                             &(sPostFixPredicateTree[0]));
        }

        _SFD_CV_INIT_TRANS(8,0,NULL,NULL,0,NULL);

        {
          static unsigned int sStartGuardMap[] = { 1 };

          static unsigned int sEndGuardMap[] = { 8 };

          static int sPostFixPredicateTree[] = { 0 };

          _SFD_CV_INIT_TRANS(10,1,&(sStartGuardMap[0]),&(sEndGuardMap[0]),1,
                             &(sPostFixPredicateTree[0]));
        }

        {
          static unsigned int sStartRelationalopMap[] = { 1 };

          static unsigned int sEndRelationalopMap[] = { 8 };

          static int sRelationalopEps[] = { -1 };

          static int sRelationalopType[] = { 2, 2, 2 };

          _SFD_CV_INIT_TRANSITION_RELATIONALOP(10,1,&(sStartRelationalopMap[0]),
            &(sEndRelationalopMap[0]),&(sRelationalopEps[0]),
            &(sRelationalopType[0]));
        }

        _SFD_CV_INIT_TRANS(0,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(1,0,NULL,NULL,0,NULL);

        {
          static unsigned int sStartGuardMap[] = { 1 };

          static unsigned int sEndGuardMap[] = { 14 };

          static int sPostFixPredicateTree[] = { 0 };

          _SFD_CV_INIT_TRANS(11,1,&(sStartGuardMap[0]),&(sEndGuardMap[0]),1,
                             &(sPostFixPredicateTree[0]));
        }

        {
          static unsigned int sStartRelationalopMap[] = { 1 };

          static unsigned int sEndRelationalopMap[] = { 14 };

          static int sRelationalopEps[] = { -1 };

          static int sRelationalopType[] = { 2, 2, 2 };

          _SFD_CV_INIT_TRANSITION_RELATIONALOP(11,1,&(sStartRelationalopMap[0]),
            &(sEndRelationalopMap[0]),&(sRelationalopEps[0]),
            &(sRelationalopType[0]));
        }

        _SFD_CV_INIT_TRANS(9,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(3,0,NULL,NULL,0,NULL);

        {
          static unsigned int sStartGuardMap[] = { 1 };

          static unsigned int sEndGuardMap[] = { 8 };

          static int sPostFixPredicateTree[] = { 0 };

          _SFD_CV_INIT_TRANS(5,1,&(sStartGuardMap[0]),&(sEndGuardMap[0]),1,
                             &(sPostFixPredicateTree[0]));
        }

        {
          static unsigned int sStartRelationalopMap[] = { 1 };

          static unsigned int sEndRelationalopMap[] = { 8 };

          static int sRelationalopEps[] = { -1 };

          static int sRelationalopType[] = { 2, 2, 2 };

          _SFD_CV_INIT_TRANSITION_RELATIONALOP(5,1,&(sStartRelationalopMap[0]),
            &(sEndRelationalopMap[0]),&(sRelationalopEps[0]),
            &(sRelationalopType[0]));
        }

        _SFD_CV_INIT_TRANS(7,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(4,0,NULL,NULL,0,NULL);

        {
          static unsigned int sStartGuardMap[] = { 1 };

          static unsigned int sEndGuardMap[] = { 14 };

          static int sPostFixPredicateTree[] = { 0 };

          _SFD_CV_INIT_TRANS(6,1,&(sStartGuardMap[0]),&(sEndGuardMap[0]),1,
                             &(sPostFixPredicateTree[0]));
        }

        {
          static unsigned int sStartRelationalopMap[] = { 1 };

          static unsigned int sEndRelationalopMap[] = { 14 };

          static int sRelationalopEps[] = { -1 };

          static int sRelationalopType[] = { 2, 2, 2 };

          _SFD_CV_INIT_TRANSITION_RELATIONALOP(6,1,&(sStartRelationalopMap[0]),
            &(sEndRelationalopMap[0]),&(sRelationalopEps[0]),
            &(sRelationalopType[0]));
        }

        {
          unsigned int dimVector[1];
          dimVector[0]= 7U;
          _SFD_SET_DATA_COMPILED_PROPS(0,SF_DOUBLE,1,&(dimVector[0]),0,0,0,0.0,
            1.0,0,0,(MexFcnForType)c2_d_sf_marshallOut,(MexInFcnForType)
            c2_c_sf_marshallIn);
        }

        {
          unsigned int dimVector[1];
          dimVector[0]= 7U;
          _SFD_SET_DATA_COMPILED_PROPS(1,SF_DOUBLE,1,&(dimVector[0]),0,0,0,0.0,
            1.0,0,0,(MexFcnForType)c2_d_sf_marshallOut,(MexInFcnForType)
            c2_c_sf_marshallIn);
        }

        _SFD_SET_DATA_COMPILED_PROPS(2,SF_UINT8,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c2_c_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(3,SF_UINT8,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c2_c_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(4,SF_UINT8,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c2_c_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(5,SF_UINT8,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c2_c_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(6,SF_UINT8,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c2_c_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(7,SF_UINT8,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c2_c_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(8,SF_UINT8,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c2_c_sf_marshallOut,(MexInFcnForType)NULL);

        {
          unsigned int dimVector[1];
          dimVector[0]= 7U;
          _SFD_SET_DATA_COMPILED_PROPS(9,SF_DOUBLE,1,&(dimVector[0]),0,0,0,0.0,
            1.0,0,0,(MexFcnForType)c2_d_sf_marshallOut,(MexInFcnForType)
            c2_c_sf_marshallIn);
        }

        {
          unsigned int dimVector[1];
          dimVector[0]= 7U;
          _SFD_SET_DATA_COMPILED_PROPS(10,SF_DOUBLE,1,&(dimVector[0]),0,0,0,0.0,
            1.0,0,0,(MexFcnForType)c2_d_sf_marshallOut,(MexInFcnForType)
            c2_c_sf_marshallIn);
        }

        _SFD_SET_DATA_COMPILED_PROPS(11,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c2_e_sf_marshallOut,(MexInFcnForType)c2_d_sf_marshallIn);
        _SFD_SET_DATA_COMPILED_PROPS(12,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c2_e_sf_marshallOut,(MexInFcnForType)c2_d_sf_marshallIn);
        _SFD_SET_DATA_COMPILED_PROPS(13,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c2_e_sf_marshallOut,(MexInFcnForType)c2_d_sf_marshallIn);
        _SFD_SET_DATA_COMPILED_PROPS(14,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c2_e_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(15,SF_INT32,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c2_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(16,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c2_e_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(17,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c2_e_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(18,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c2_e_sf_marshallOut,(MexInFcnForType)c2_d_sf_marshallIn);
        _SFD_SET_DATA_VALUE_PTR(11,(void *)(NULL));
        _SFD_SET_DATA_VALUE_PTR(12,(void *)(NULL));
        _SFD_SET_DATA_VALUE_PTR(13,(void *)(NULL));
        _SFD_SET_DATA_VALUE_PTR(18,(void *)(NULL));
      }
    } else {
      sf_debug_reset_current_state_configuration(sfGlobalDebugInstanceStruct,
        _cradle_vrMachineNumber_,chartInstance->chartNumber,
        chartInstance->instanceNumber);
    }
  }
}

static void chart_debug_initialize_data_addresses(SimStruct *S)
{
  if (!sim_mode_is_rtw_gen(S)) {
    SFc2_cradle_vrInstanceStruct *chartInstance = (SFc2_cradle_vrInstanceStruct *)
      sf_get_chart_instance_ptr(S);
    if (ssIsFirstInitCond(S)) {
      /* do this only if simulation is starting and after we know the addresses of all data */
      {
        _SFD_SET_DATA_VALUE_PTR(2U, chartInstance->c2_input0);
        _SFD_SET_DATA_VALUE_PTR(9U, *chartInstance->c2_p_out);
        _SFD_SET_DATA_VALUE_PTR(10U, *chartInstance->c2_v_out);
        _SFD_SET_DATA_VALUE_PTR(14U, &chartInstance->c2_g);
        _SFD_SET_DATA_VALUE_PTR(16U, &chartInstance->c2_l);
        _SFD_SET_DATA_VALUE_PTR(17U, &chartInstance->c2_pi);
        _SFD_SET_DATA_VALUE_PTR(0U, *chartInstance->c2_p);
        _SFD_SET_DATA_VALUE_PTR(1U, *chartInstance->c2_v);
        _SFD_SET_DATA_VALUE_PTR(15U, &chartInstance->c2_k);
        _SFD_SET_DATA_VALUE_PTR(3U, chartInstance->c2_input1);
        _SFD_SET_DATA_VALUE_PTR(4U, chartInstance->c2_input2);
        _SFD_SET_DATA_VALUE_PTR(5U, chartInstance->c2_input3);
        _SFD_SET_DATA_VALUE_PTR(6U, chartInstance->c2_input4);
        _SFD_SET_DATA_VALUE_PTR(7U, chartInstance->c2_input5);
        _SFD_SET_DATA_VALUE_PTR(8U, chartInstance->c2_input6);
      }
    }
  }
}

static const char* sf_get_instance_specialization(void)
{
  return "sP9NSWOLhZvsZ5wetlhOZ0C";
}

static void sf_opaque_initialize_c2_cradle_vr(void *chartInstanceVar)
{
  chart_debug_initialization(((SFc2_cradle_vrInstanceStruct*) chartInstanceVar
    )->S,0);
  initialize_params_c2_cradle_vr((SFc2_cradle_vrInstanceStruct*)
    chartInstanceVar);
  initialize_c2_cradle_vr((SFc2_cradle_vrInstanceStruct*) chartInstanceVar);
}

static void sf_opaque_enable_c2_cradle_vr(void *chartInstanceVar)
{
  enable_c2_cradle_vr((SFc2_cradle_vrInstanceStruct*) chartInstanceVar);
}

static void sf_opaque_disable_c2_cradle_vr(void *chartInstanceVar)
{
  disable_c2_cradle_vr((SFc2_cradle_vrInstanceStruct*) chartInstanceVar);
}

static void sf_opaque_zeroCrossings_c2_cradle_vr(void *chartInstanceVar)
{
  zeroCrossings_c2_cradle_vr((SFc2_cradle_vrInstanceStruct*) chartInstanceVar);
}

static void sf_opaque_derivatives_c2_cradle_vr(void *chartInstanceVar)
{
  derivatives_c2_cradle_vr((SFc2_cradle_vrInstanceStruct*) chartInstanceVar);
}

static void sf_opaque_outputs_c2_cradle_vr(void *chartInstanceVar)
{
  outputs_c2_cradle_vr((SFc2_cradle_vrInstanceStruct*) chartInstanceVar);
}

static void sf_opaque_gateway_c2_cradle_vr(void *chartInstanceVar)
{
  sf_gateway_c2_cradle_vr((SFc2_cradle_vrInstanceStruct*) chartInstanceVar);
}

static const mxArray* sf_opaque_get_sim_state_c2_cradle_vr(SimStruct* S)
{
  return get_sim_state_c2_cradle_vr((SFc2_cradle_vrInstanceStruct *)
    sf_get_chart_instance_ptr(S));     /* raw sim ctx */
}

static void sf_opaque_set_sim_state_c2_cradle_vr(SimStruct* S, const mxArray *st)
{
  set_sim_state_c2_cradle_vr((SFc2_cradle_vrInstanceStruct*)
    sf_get_chart_instance_ptr(S), st);
}

static void sf_opaque_terminate_c2_cradle_vr(void *chartInstanceVar)
{
  if (chartInstanceVar!=NULL) {
    SimStruct *S = ((SFc2_cradle_vrInstanceStruct*) chartInstanceVar)->S;
    if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
      sf_clear_rtw_identifier(S);
      unload_cradle_vr_optimization_info();
    }

    finalize_c2_cradle_vr((SFc2_cradle_vrInstanceStruct*) chartInstanceVar);
    utFree(chartInstanceVar);
    if (ssGetUserData(S)!= NULL) {
      sf_free_ChartRunTimeInfo(S);
    }

    ssSetUserData(S,NULL);
  }
}

static void sf_opaque_init_subchart_simstructs(void *chartInstanceVar)
{
  initSimStructsc2_cradle_vr((SFc2_cradle_vrInstanceStruct*) chartInstanceVar);
}

extern unsigned int sf_machine_global_initializer_called(void);
static void mdlProcessParameters_c2_cradle_vr(SimStruct *S)
{
  int i;
  for (i=0;i<ssGetNumRunTimeParams(S);i++) {
    if (ssGetSFcnParamTunable(S,i)) {
      ssUpdateDlgParamAsRunTimeParam(S,i);
    }
  }

  if (sf_machine_global_initializer_called()) {
    initialize_params_c2_cradle_vr((SFc2_cradle_vrInstanceStruct*)
      sf_get_chart_instance_ptr(S));
  }
}

static void mdlSetWorkWidths_c2_cradle_vr(SimStruct *S)
{
  ssMdlUpdateIsEmpty(S, 1);
  if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
    mxArray *infoStruct = load_cradle_vr_optimization_info(sim_mode_is_rtw_gen(S),
      sim_mode_is_modelref_sim(S), sim_mode_is_external(S));
    int_T chartIsInlinable =
      (int_T)sf_is_chart_inlinable(sf_get_instance_specialization(),infoStruct,2);
    ssSetStateflowIsInlinable(S,chartIsInlinable);
    ssSetRTWCG(S,1);
    ssSetEnableFcnIsTrivial(S,1);
    ssSetDisableFcnIsTrivial(S,1);
    ssSetNotMultipleInlinable(S,sf_rtw_info_uint_prop
      (sf_get_instance_specialization(),infoStruct,2,
       "gatewayCannotBeInlinedMultipleTimes"));
    sf_set_chart_accesses_machine_info(S, sf_get_instance_specialization(),
      infoStruct, 2);
    sf_update_buildInfo(S, sf_get_instance_specialization(),infoStruct,2);
    if (chartIsInlinable) {
      ssSetInputPortOptimOpts(S, 0, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 1, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 2, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 3, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 4, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 5, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 6, SS_REUSABLE_AND_LOCAL);
      sf_mark_chart_expressionable_inputs(S,sf_get_instance_specialization(),
        infoStruct,2,7);
      sf_mark_chart_reusable_outputs(S,sf_get_instance_specialization(),
        infoStruct,2,2);
    }

    {
      unsigned int outPortIdx;
      for (outPortIdx=1; outPortIdx<=2; ++outPortIdx) {
        ssSetOutputPortOptimizeInIR(S, outPortIdx, 1U);
      }
    }

    {
      unsigned int inPortIdx;
      for (inPortIdx=0; inPortIdx < 7; ++inPortIdx) {
        ssSetInputPortOptimizeInIR(S, inPortIdx, 1U);
      }
    }

    sf_set_rtw_dwork_info(S,sf_get_instance_specialization(),infoStruct,2);
    ssSetHasSubFunctions(S,!(chartIsInlinable));
  } else {
  }

  ssSetOptions(S,ssGetOptions(S)|SS_OPTION_WORKS_WITH_CODE_REUSE);
  ssSetChecksum0(S,(2918350066U));
  ssSetChecksum1(S,(3756942328U));
  ssSetChecksum2(S,(2707372360U));
  ssSetChecksum3(S,(4053782994U));
  ssSetNumContStates(S,14);
  ssSetExplicitFCSSCtrl(S,1);
  ssSupportsMultipleExecInstances(S,1);
}

static void mdlRTW_c2_cradle_vr(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S)) {
    ssWriteRTWStrParam(S, "StateflowChartType", "Stateflow");
  }
}

static void mdlStart_c2_cradle_vr(SimStruct *S)
{
  SFc2_cradle_vrInstanceStruct *chartInstance;
  chartInstance = (SFc2_cradle_vrInstanceStruct *)utMalloc(sizeof
    (SFc2_cradle_vrInstanceStruct));
  if (chartInstance==NULL) {
    sf_mex_error_message("Could not allocate memory for chart instance.");
  }

  memset(chartInstance, 0, sizeof(SFc2_cradle_vrInstanceStruct));
  chartInstance->chartInfo.chartInstance = chartInstance;
  chartInstance->chartInfo.isEMLChart = 0;
  chartInstance->chartInfo.chartInitialized = 0;
  chartInstance->chartInfo.sFunctionGateway = sf_opaque_gateway_c2_cradle_vr;
  chartInstance->chartInfo.initializeChart = sf_opaque_initialize_c2_cradle_vr;
  chartInstance->chartInfo.terminateChart = sf_opaque_terminate_c2_cradle_vr;
  chartInstance->chartInfo.enableChart = sf_opaque_enable_c2_cradle_vr;
  chartInstance->chartInfo.disableChart = sf_opaque_disable_c2_cradle_vr;
  chartInstance->chartInfo.getSimState = sf_opaque_get_sim_state_c2_cradle_vr;
  chartInstance->chartInfo.setSimState = sf_opaque_set_sim_state_c2_cradle_vr;
  chartInstance->chartInfo.getSimStateInfo = sf_get_sim_state_info_c2_cradle_vr;
  chartInstance->chartInfo.zeroCrossings = sf_opaque_zeroCrossings_c2_cradle_vr;
  chartInstance->chartInfo.outputs = sf_opaque_outputs_c2_cradle_vr;
  chartInstance->chartInfo.derivatives = sf_opaque_derivatives_c2_cradle_vr;
  chartInstance->chartInfo.mdlRTW = mdlRTW_c2_cradle_vr;
  chartInstance->chartInfo.mdlStart = mdlStart_c2_cradle_vr;
  chartInstance->chartInfo.mdlSetWorkWidths = mdlSetWorkWidths_c2_cradle_vr;
  chartInstance->chartInfo.callGetHoverDataForMsg =
    sf_opaque_get_hover_data_for_msg;
  chartInstance->chartInfo.extModeExec = NULL;
  chartInstance->chartInfo.restoreLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.restoreBeforeLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.storeCurrentConfiguration = NULL;
  chartInstance->chartInfo.callAtomicSubchartUserFcn = NULL;
  chartInstance->chartInfo.callAtomicSubchartAutoFcn = NULL;
  chartInstance->chartInfo.debugInstance = sfGlobalDebugInstanceStruct;
  chartInstance->S = S;
  sf_init_ChartRunTimeInfo(S, &(chartInstance->chartInfo), false, 0);
  init_dsm_address_info(chartInstance);
  init_simulink_io_address(chartInstance);
  if (!sim_mode_is_rtw_gen(S)) {
  }

  chart_debug_initialization(S,1);
  mdl_start_c2_cradle_vr(chartInstance);
}

void c2_cradle_vr_method_dispatcher(SimStruct *S, int_T method, void *data)
{
  switch (method) {
   case SS_CALL_MDL_START:
    mdlStart_c2_cradle_vr(S);
    break;

   case SS_CALL_MDL_SET_WORK_WIDTHS:
    mdlSetWorkWidths_c2_cradle_vr(S);
    break;

   case SS_CALL_MDL_PROCESS_PARAMETERS:
    mdlProcessParameters_c2_cradle_vr(S);
    break;

   default:
    /* Unhandled method */
    sf_mex_error_message("Stateflow Internal Error:\n"
                         "Error calling c2_cradle_vr_method_dispatcher.\n"
                         "Can't handle method %d.\n", method);
    break;
  }
}
