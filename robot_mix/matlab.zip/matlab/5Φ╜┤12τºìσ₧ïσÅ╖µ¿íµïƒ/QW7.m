
clc;clear all;close all;
% [FileName,PathName] = uigetfile('./*.*','Select the file');
% file_name = strcat(PathName,FileName);

file_name = './QW7.NC';
fid= fopen(file_name);

%��ȡ�ļ�
point_struct_array = get_nc_data(file_name, 11,1000);
n = size(point_struct_array,2);

% for i= 1:9
%     points(i, 1) = point_struct_array(i).X;
%     points(i, 2) = point_struct_array(i).Y;
%     points(i, 3) = point_struct_array(i).Z;
% end
 
% for i= 10:30
%     points(i-9, 1) = point_struct_array(i).X;
%     points(i-9, 2) = point_struct_array(i).Y;
%     points(i-9, 3) = point_struct_array(i).Z;
% end

% for i= 32:44
%     points(i-31, 1) = point_struct_array(i).X;
%     points(i-31, 2) = point_struct_array(i).Y;
%     points(i-31, 3) = point_struct_array(i).Z;
% end

for i= 57:299
    points(i-56, 1) = point_struct_array(i).Y;
    points(i-56, 2) = point_struct_array(i).Z;
    points(i-56, 3) = point_struct_array(i).C;
end

new_data = fitting(points , 20 , 500);
figure(1)
plot3(points(:,1),points(:,2),points(:,3), 'b')
hold on
plot3(new_data(:,1),new_data(:,2),new_data(:,3),'-r'); 

% xxx = '';
% for j = 1:501
%     xxx = sprintf('%s X%.3f Y%.3f Z%.3f A90. C-7.681\n',xxx, new_data(j,1) ,new_data(j,2),new_data(j,3));
% end

xxx = '';
for j = 1:501
    xxx = sprintf('%s X3.255 Y%.3f Z%.3f A90. C%.3f\n',xxx, new_data(j,1) ,new_data(j,2),new_data(j,3));
end
xxx

% for i= 10:30
%     x2(i-9) = point_struct_array(i).X;
%     y2(i-9) = point_struct_array(i).Y;
%     z2(i-9) = point_struct_array(i).Z;
% end
% 
% figure(1)
% plot3(x1,y1,z1)
% figure(2)
% plot3(x2,y2,z2)