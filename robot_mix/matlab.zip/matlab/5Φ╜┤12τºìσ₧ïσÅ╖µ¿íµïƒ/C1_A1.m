clc;clear all
r = 20;
x0= 0 ;y0 = 0;z0= 0;
%�ο��Ǿ���B������2ҳ
%ֻ��һ����Բ
angleA = zeros(11,21);
angleC = zeros(11,21);
x1 = zeros(11,21);
y1 = zeros(11,21);
z1 = zeros(11,21);
for i = 1 : 11
    for j = 1: 21
        u = (i - 1) * pi / 20;
        v = (j - 1) * pi / 10;
        angleA(i,j) = u;
        angleC(i,j) = v;
        x1(i,j) = sin(u) * cos(v);
        y1(i,j) = sin(u)*sin(v);
        z1(i,j) = cos(u);
    end
end

%�����Լ�AC���Ķ���
L = 10;
center_knife = [0,0,25];
cylinder_h = 40; cylinder_r = 3;
%���嵶�ĳ�ʼ��״

% hold on

center_A = [0 ,5,0];
center_C = [5,0,0];
kkk = 1;

% ball_point = {};
new_knife_center = [0,0,50 ];
for k = 1:11
    for f = 1:21
        A = angleA(k,f) ;
        C = angleC(k,f)  ;
        for i = 1 : 11
            for j = 1: 21

                ball_point{i,j} = [r*x1(i,j)+x0, r*y1(i,j)+y0, r*z1(i,j)+z0];
                v1 = ball_point{i,j} - center_A ;
                v1 = [v1 1]';

                %A������ת
                Ra = [1 0 0 0 ; 0 cos(A) -sin(A) 0 ; 0 sin(A) cos(A) 0 ;0 0 0 1];
                %C������ת
                Rc = [cos(C) -sin(C) 0 0 ; sin(C) cos(C) 0 0 ; 0 0 1 0;0 0 0 1]; 

                T = center_A - center_C;
                T1 = [eye(3) T' ; zeros(1,3) 1]; 
                T2 = [eye(3) center_C'; zeros(1,3) 1];
                new_ball_point(:,kkk) = T2 * Rc * T1 *  Ra  * v1; 
                new_x(i,j) = new_ball_point(1,kkk);
                new_y(i,j) = new_ball_point(2,kkk);
                new_z(i,j) = new_ball_point(3,kkk);
                
                if i == k && j == 6
                    vect = [new_x(i,j),new_y(i,j), new_z(i,j)];
                end
%                 new_knife_center(3) = center_knife(3) + new_z(i,j);
            end   
        end
        pause(0.1)
        mesh(new_x, new_y , new_z);
        axis([-40,40,-40,40,-30,80]);
        hold on
        new_knife_center = center_knife + vect ;
        draw_cylinder(new_knife_center, cylinder_h, cylinder_r, [0 0 0], 1);  
        hold off
    end
    pause(1)
end
% mesh(r*x1+x0,r*y1+y0,r*z1+z0);
% mesh(new_x, new_y , new_z);
% hold on
% draw_cylinder(new_knife_center, cylinder_h, cylinder_r, [0 0 0], 1);    

% plot3(new_ball_point(1,:),new_ball_point(2,:),new_ball_point(3,:))


