function uk = compute_params_curve(points , use_centripetal)

n = size(points,1);
uk = zeros(1,n);
d = 0;
for k = 2:n
    vect = points(k,:) - points(k-1,:);
    d_l = sqrt(vect* vect');
    if use_centripetal
        d_l = sqrt(d_l);
    end
    d = d + d_l;
    uk(k) = d ;   
end
uk = uk./uk(end);
