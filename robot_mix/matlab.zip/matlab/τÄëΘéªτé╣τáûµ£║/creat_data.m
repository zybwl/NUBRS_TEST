clc;clear all;
t = 0: 2*pi/4: 2*pi;
rand_r = 3;
points(:,1) = 1250 + 300 * cos(t) + rand_r *rand(size(t)) - rand_r/2;
points(:,2) = 1000 + 300 * sin(t) + rand_r *rand(size(t)) - rand_r/2;

z = 35 + rand_r *rand(size(t)) - rand_r/2
