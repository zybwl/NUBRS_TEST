clc;clear;
%file_name = 'NEW_FILE.NC.nc';
file_name = 'SIJIAO.NC';
% start_line_no = 11;
% end_line_no = 31;
start_line_no = 38;
end_line_no = 58;
point_struct_array = get_nc_data(file_name,start_line_no,end_line_no);
n = size(point_struct_array,2);

p = 3;
U = zeros(1,n + 2*p);

for k = 1:n
    B = point_struct_array(k).B;
    C = point_struct_array(k).C;
    X = point_struct_array(k).X;
    Y = point_struct_array(k).Y;
    Z = point_struct_array(k).Z;
    point(:,k) = [X;Y;Z];
    if k == 1
        U(p + k) = 0;
    else
        vect = point(:,k) - point(:,k-1);
        U(1,p + k) = U(1, p + k -1) + sqrt(vect'* vect);
    end
end
U  = U / U(p + n);
U(n+p + 1: end) = 1;

for i = 1:p-1
    point(:,n + i) = point(:,n);
end
n = n + p -1;

ploy_n = 30;
index = 1;
for u = 0:1/ploy_n:1    
    span = findspan(n , p , u ,U );
    N = basisfun(span,u,p,U);   
    new_point(:,index) = point(: , span - p + 1 : span + 1) * N';
    if index >= ploy_n
        break;
    end
    index = index + 1;
end
    
plot3(point(1,:),point(2,:),point(3,:),'-o');
hold on
plot3(new_point(1,:),new_point(2,:),new_point(3,:),'-o');   





     
     











