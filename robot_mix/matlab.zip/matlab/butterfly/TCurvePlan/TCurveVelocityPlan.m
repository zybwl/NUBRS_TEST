function Sparam = TCurveVelocityPlan(plan_param)
% T �滮
global INTERVAL;
Ts=INTERVAL;
Sparam = initSparam;

% ���룺�����ٶȡ������ٶȡ����jerk�������ٶȡ�·�����ȡ���ʼ�ٶȡ���ֹ�ٶ�
A = plan_param(1);
D = plan_param(2);
F = plan_param(3);
S = plan_param(4);
vs = plan_param(5);
ve = plan_param(6);


%�ж���ľ�����ٶΣ��ܷ�ﵽ����ٶ�
s1=(F^2-vs^2)/(2*A);
s2=(F^2-ve^2)/(2*D);

if S>(s1+s2)
    % ���ٶ�/���ٶ�
    T(1) = abs(F-vs)/A;   
    T(3) = abs(F-ve)/D; 
    
    %%����Բ��%%%%%%
    T(1)=ceil(T(1)/Ts)*Ts;
    T(3)=ceil(T(3)/Ts)*Ts;
    
    T(2)=(S-0.5*T(1)*vs-0.5*T(3)*ve)/F-0.5*T(1)-0.5*T(3);
    T(2)=ceil(T(2)/Ts)*Ts;
    F=(S-0.5*T(1)*vs-0.5*T(3)*ve)/(0.5*T(1)+0.5*T(3)+T(2));
    %%%%%%%%%%%%%%
    if T(1)==0 
        A=0;
    else
        A=(F-vs)/T(1);
    end
    if T(3)==0 
        D=0;
    else
        D=(F-ve)/T(3);
    end
    %%%%%%%%%%%%%%
    % ÿ���׶ε�ĩ�ٶ�
    v(1) = F;
    v(2) = F;
    v(3) = ve;
    % ÿ���׶ε���ĩλ��
    sa(1) = 0.5*(F+vs)*T(1);
    sa(2) = F*T(2);
    sa(3) = 0.5*(F+ve)*T(3); 
    Sad=sa(1)+sa(2)+sa(3);
else
    Vmax=sqrt((4*A*D*S+2*D*ve^2+2*A*vs^2)/(2*A+2*D));    %%%%���¼�������ٶ�
    if Vmax>vs && Vmax>ve   %%%%%%%%�����½�
             % ���ٶ�/���ٶ�
            T(1) = abs(Vmax-vs)/A; 
            T(2)=0;
            T(3) = abs(Vmax-ve)/D; 
            %%����Բ��%%%%%%
            T(1)=ceil(T(1)/Ts)*Ts;
            T(3)=ceil(T(3)/Ts)*Ts;
            Vmax=(2*S-vs*T(1)-ve*T(3))/(T(1)+T(3));
            
            %%%%%%%%%%%%%%
            F=Vmax;
            if T(1)==0 
                A=0;
            else
                A=(F-vs)/T(1);
            end
            if T(3)==0 
                D=0;
            else
                D=(F-ve)/T(3);
            end
            
            %%%%%%%%%%%%%%
            % ÿ���׶ε�ĩ�ٶ�
            v(1) = F;
            v(2) = F;
            v(3) = ve;
            % ÿ���׶ε���ĩλ��
            sa(1) = 0.5*(F+vs)*T(1);
            sa(2) = 0;
            sa(3) = 0.5*(F+ve)*T(3);             
            Sad=sa(1)+sa(2)+sa(3);
    elseif vs<Vmax && Vmax<=ve %%%%%%%������
        F=ve;
        T(1)=2*S/(vs+ve);
        %T(1)=ceil(T(1)/Ts)*Ts;
        T(2)=0;
        T(3)=0;
         %%%%%%%%%%%%%%
        %A=(F-vs)/T(1);
        D=0;
        %%%%%%%%%%%%%%
        % ÿ���׶ε�ĩ�ٶ�
        v(1) = F;
        v(2) = ve;
        v(3) = ve;
        % ÿ���׶ε���ĩλ��
        sa(1) = 0.5*(F+vs)*T(1);
        sa(2) = 0;
        sa(3) = 0;   
        Sad=sa(1)+sa(2)+sa(3);
    elseif vs>=Vmax && Vmax>ve %%%%%%%%%�½���   
        F=vs;
        T(1)=0;        
        T(2)=0;
        T(3)=2*S/(vs+ve);
        %T(3)=ceil(T(3)/Ts)*Ts;
         %%%%%%%%%%%%%%
         A=0;
       % D=(F-ve)/T(3);
        %%%%%%%%%%%%%%
        % ÿ���׶ε�ĩ�ٶ�
        v(1) = F;
        v(2) = vs;
        v(3) = ve;
        % ÿ���׶ε���ĩλ��
        sa(1) = 0;
        sa(2) = 0;
        sa(3) = 0.5*(F+vs)*T(3);  
        Sad=sa(1)+sa(2)+sa(3);
    elseif vs==Vmax && Vmax==ve
        T(1)=0;        
        T(3)=0;
        
        T(2)=S/F;
        T(2)=ceil(T(2)/Ts)*Ts;
        F=S/T(2);
        A=0;
        D=0;
        
        v(1) = F;
        v(2) = F;
        v(3) = F;
        
        sa(1) = 0;
        sa(2) = S;
        sa(3) = 0;  
        Sad=S;
    end
end
%%%%%%%%%%%%%%%%%%%
Sparam.vs = vs;
Sparam.ve = ve;
Sparam.T = T;
Sparam.vknot = v;
Sparam.sknot = sa;
Sparam.Amax = A;
Sparam.Dec = D;
Sparam.Vmax = F;
Sparam.displacementOfAD = Sad;
Sparam.t = cumsum(Sparam.T);
Sparam.Stol = S;
% Sparam.Jamax = 1;
% Sparam.Jdmax = 1;


%%%%%%%%%%%%%%%%%%%
  function sp = initSparam
        sp.Amax = [];
        sp.Dec = [];
        sp.Vmax = [];
        sp.T = [];
        sp.t = [];
        sp.vknot = [];
        sp.sknot = [];
        sp.vs = [];
        sp.ve = [];
        sp.Stol = [];
    end
end

