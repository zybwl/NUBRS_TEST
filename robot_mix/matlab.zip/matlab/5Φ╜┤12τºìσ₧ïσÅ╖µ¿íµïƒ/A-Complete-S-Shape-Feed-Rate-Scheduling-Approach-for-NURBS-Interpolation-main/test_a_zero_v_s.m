clc;clear;close all;
J = 2;
a_max = 8;

v_begin = 30;
a_array = zeros(1,1000);
v_array = zeros(1,1000);
s_array = zeros(1,1000);
v_start = v_begin;
s_start = 0;

direct = 1;
for i = 1:1000
    t = i/100;
    if t<= 4
        a_array(i) = J* t;
    elseif t<= 6
        a_array(i) = 8;
    else
        a_array(i) = a_max - (t - 6)*2;
    end
    v_array(i) = v_start + a_array(i) / 100;
    s_array(i) = s_start + v_array(i) / 100;
    v_start = v_array(i);
    s_start = s_array(i); 
end

figure(1)
plot(1:1000, a_array,'LineWidth',4);
set(gca,'FontSize',30,'FontWeight','bold','FontName','Times New Roman')
xlabel('Time(s)','FontSize',30,'FontWeight','bold','FontName','Times New Roman')
ylabel('ACC(mm^2/s)','FontSize',30,'FontWeight','bold','FontName','Times New Roman')

figure(2)
plot(1:1000, v_array,'LineWidth',4);
set(gca,'FontSize',30,'FontWeight','bold','FontName','Times New Roman')
xlabel('Time(s)','FontSize',30,'FontWeight','bold','FontName','Times New Roman')
ylabel('VEC(mm^2/s)','FontSize',30,'FontWeight','bold','FontName','Times New Roman')

figure(3)
plot(1:1000, s_array,'LineWidth',4);
set(gca,'FontSize',30,'FontWeight','bold','FontName','Times New Roman')
xlabel('Time(s)','FontSize',30,'FontWeight','bold','FontName','Times New Roman')
ylabel('Length(mm)','FontSize',30,'FontWeight','bold','FontName','Times New Roman')


vi1 = v_begin;
vi = v_array(end);

k = (J * vi^2 + a_max^2 * vi - J*vi1^2 + a_max^2 * vi1)/2/a_max/J;
si = s_array(end);
xishu = k/ si

% v1 = v_array(400)
% v2 = v_array(600)
% v3 = v_array(end)
% s1 = s_array(400)
% s2 = s_array(600)
% s3 = s_array(end)



% for i = 1:999
%     
%     vi1 = v_array(i);
%     vi = v_array(i+1);
%     k = (vi^3 + vi1*vi^2 - vi1^2*vi - vi^3)/J;
%     si = (s_array(i+1) - s_array(i))^2;
%     xishu = k/ si
%     
% end

