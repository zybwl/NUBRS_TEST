
% �����߶�֮��ļн�
function theta = get_inter_angle(v1_x,v1_y,v2_x,v2_y)
    
    new_x = (v1_x * v2_x + v1_y * v2_y);
    new_y = (v1_x * v2_y - v2_x * v1_y);

    theta = acos(new_x / sqrt(new_x^2 + new_y^2))*180/pi;
    if new_y < 0
        theta =  -theta ;
    end
