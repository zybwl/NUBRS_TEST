clc;clear;
file_name = 'NEW_FILE.NC.nc';
start_line_no = 100;
end_line_no = 327;
point_struct_array = get_nc_data(file_name,start_line_no,end_line_no);
n = size(point_struct_array,2);
filter_factor = 16;

index = 1;
for k = 1:n
    B = point_struct_array(k).U;
    C = point_struct_array(k).V;
    X = point_struct_array(k).X;
    Y = point_struct_array(k).Y;
    Z = point_struct_array(k).Z;
    
    B = B*pi/180;
    C = C*pi/180;
    a = [cos(C)*cos(B)  -sin(C)  sin(B)*cos(C);
         cos(B)*sin(C)   cos(C)  sin(B)*sin(C)   ;
         -sin(B)        0        cos(B)   ];
     
     inv_a = inv(a);
     %new_para(:,index) = inv(a)*[X;Y;Z];
     
     if index == 1
         init = a\[X;Y;Z];
         new_para(:,1) = [0,0,0];
         filter_param(:,1) = [0,0,0];
     else
         new_para(:,index) = a\[X;Y;Z] - init;
         filter_param(:,index) = ((filter_factor-1)*filter_param(:,index-1) + new_para(:,index))/filter_factor;
     end
     
     index = index + 1;
end

for k = 0:filter_factor-1
    filter_param(:,index + k) = ((filter_factor-4)*filter_param(:,index + k -1) + 4 * new_para(:,index - 1))/filter_factor;
end

x_max = max(new_para(1,:));
x_min = min(new_para(1,:));
y_max = max(new_para(2,:));
y_min = min(new_para(2,:));
z_max = max(new_para(3,:));
z_min = min(new_para(3,:));

plot3(new_para(1,:),new_para(2,:),new_para(3,:));
axis([x_min x_max y_min y_max z_min z_max]);
hold on
plot3(filter_param(1,:),filter_param(2,:),filter_param(3,:),'r');

B = -11.480 ; 
C = 21.100;
B = B*pi/180;
C = C*pi/180;
a = [cos(C)*cos(B)  -sin(C)  sin(B)*cos(C);
     cos(B)*sin(C)   cos(C)  sin(B)*sin(C)   ;
     -sin(B)        0        cos(B)   ];
 new_point = a * filter_param;
     
     
%�������
% for k = 1:n
%     x = new_para(1,k);
%     y = new_para(2,k);
%     z = new_para(3,k);
%     new_z = get_z(x,y,z);
%     ploy_para(k,:) = [x,y,new_z];
% end
% plot3(ploy_para(:,1),ploy_para(:,2),ploy_para(:,3),'r');
% �����ѷ�����
% index = 1;
% for k = 2:n-1
%     vect1 = new_para(:,k) - new_para(:,1);
%     vect2 = new_para(:,n) - new_para(:,k);
%     dict_c = cross(vect1,vect2);
%     dict(:,index) = dict_c/norm(dict_c);
%     index = index + 1;
% end
% dict

% param = zeros(n,7);
% for k = 1:n
%     x = new_para(1,k);
%     y = new_para(2,k);
%     z = new_para(3,k);
%     vect = [x^2 y^2 z^2 x*y x*z y*z 1];
%     param(k,:) = vect;
% end
% A = param';
% y = 0.01 * rand(n,1);
% c = (A*A')\A* y;










