function new_points = get_tr_position(center_a, center_c , angle_a, angle_c, points)

n = size(points, 2);
center1_reshape = [reshape(center_c, 3,1);0];
center1_points = repmat(center1_reshape , 1, n);
% points = [points; ones(1,n)];
v1 = points - center1_points;
v2 = center_c - center_a;
v3 = center_a;
t1 = get_translation_matrix(v2);
t2 = get_translation_matrix(v3);
rot_a = get_rotation_matrix(1, angle_a);
rot_c = get_rotation_matrix(3, angle_c);

new_points = t2 * rot_a * t1 * rot_c * v1;






