function output = inv_program(matrix_a, matrix_result)
% clc;clear;
%A = rand(10,10)
%A = [2 0;2 3];
% matrix_a = randi(100,10,10);
% matrix_b = [3;6;13];

% matrix_a = [1 1 1;1 3 2;1 5 7];
% matrix_b = [3 6 13];

% LU-Factorization method using Doolittle's Method for solution of linear systems.
% Decomposes the matrix :math:`A` such that :math:`A = LU`.
% The input matrix is represented by a list or a tuple. The input matrix is **2-dimensional**, i.e. list of lists of
% integers and/or floats.

output = zeros(size(matrix_result));
n = size(matrix_a,1);
dim = size(matrix_result,2);

for kk = 1:dim

    matrix_b = matrix_result(:,kk);
    matrix_u = zeros(size(matrix_a));
    matrix_l = zeros(size(matrix_a));
    for i = 1:n
        for k = i:n
            s = 0;
            for j = 1:i
                s = s + matrix_l(i,j) * matrix_u(j,k);
            end
            matrix_u(i,k) = matrix_a(i,k) - s;

            s = 0;
            if i == k
                matrix_l(i,i) = 1.0;
            else              
                for j = 1:i         
                     s  = s + matrix_l(k,j) * matrix_u(j,i);
                end
                matrix_l(k,i) = matrix_a(k,i) - s;

                if abs(matrix_u(i,i)) > 1e-5
                    matrix_l(k,i) = matrix_l(k,i)/matrix_u(i,i);
                else
                    matrix_l(k,i) = 0.0;
                end
             end
        end
    end

    % matrix_l
    % matrix_u
    % Q = matrix_l * matrix_u - matrix_a

    % forward_substitution(matrix_l, matrix_b):
    % """ Forward substitution method for the solution of linear systems.
    % Solves the equation :math:`Ly = b` using forward substitution method
    % where :math:`L` is a lower triangular matrix and :math:`b` is a column matrix.

    q = length(matrix_b);
    matrix_y = zeros(1,q);
    matrix_y(1) = matrix_b(1)/ matrix_l(1,1); 
    for i = 2:q
        s = 0;
        for j = 1:i       
            s =  s + matrix_l(i,j) * matrix_y(j) ;               
        end
        matrix_y(i) = matrix_b(i) - s;
        matrix_y(i) = matrix_y(i)/matrix_l(i,i);
    end

    % backward_substitution(matrix_u, matrix_y):
    % Backward substitution method for the solution of linear systems.
    % Solves the equation :math:`Ux = y` using backward substitution method
    % where :math:`U` is a upper triangular matrix and :math:`y` is a column matrix.
    q = length(matrix_y);
    matrix_x = zeros(q,1);
    matrix_x(q) = matrix_y(q) / matrix_u(q ,q);

    for i = q - 1 :-1:1
        s = 0;
        for j = i:q  
            s =  s + matrix_u(i,j) * matrix_x(j);
        end
         matrix_x(i) = matrix_y(i) - s;
         matrix_x(i) = matrix_x(i) / matrix_u(i,i);
    end
    output(:,1) = matrix_x;
end



