N = 40;
r =  10;
[X,Y,Z] = sphere(N);
x = r * X;
y = r * Y;
z = r * Z - r;
figure(1);
surf(x,y,z);
hold on
center1_init = [-2 0 10];
center2_init = [-1 0 9];
center3_init = [0 0 6];
vect1 = center2_init - center1_init;
vect2 = center3_init - center2_init;
h1 = 4;      r1 = 1;
h2 = 4.2;    r2 = 0.5;
h3 = 8;      r3 = 1;
draw_cylinder(center1_init, h1, r1, [0 0 0], 0)
draw_cylinder(center2_init, h2, r2, [0 90 0],0)
draw_cylinder(center3_init, h3, r3, [0 0 0], 1)
hold off

may = 0;  maz = 9;
mcx = -2; mcy = 0;
center_orgin = [mcx; mcy; maz];
[m,n] = size(X);
angleA = linspace(0,2*pi,m);
angleC = linspace(0,2*pi,n);
for i = 1:m
    for j = 1:n
        surf(x,y,z);
        hold on
        rotation_pos = C_A_RTCP_POS(angleC(j) ,mcx, mcy ,angleA(i), may,maz);
        mov_vect = rotation_pos' - center_orgin';
        center1 = center1_init + mov_vect;
        Rc = [cos(C) -sin(C) 0; sin(C) cos(C) 0 ; 0 0 1];
        center2 =  center1 +  vect1 * Rc';
        Ra = [1 0 0 ; 0 cos(A) -sin(A) ; 0 sin(A) cos(A)];
        center3 =  center1 +  (vect2 * Ra' - center1_init) * Rc';
        draw_cylinder(center1, h1, r1, [0 0 0],                 0)
        draw_cylinder(center2, h2, r2, [angleA(i) 90 angleC(j)],0)
        draw_cylinder(center3, h3, r3, [angleA(i) 0  angleC(j)],1)
        hold off
        pause(0.1);
    end
end



