function draw_cylinder(center_point,h,r,angle,is_knife)
[x, y, z]=cylinder(r); 
z = h * z - h/2;  
n = size(x,2);
new_down = [x(1,:);y(1,:);z(1,:);ones(1,n)];
new_top = [x(2,:);y(2,:);z(2,:);ones(1,n)];
if is_knife
    knife_down = [zeros(2,n);z(1,:) - 5;ones(1,n)];
end
    
for i = 1:3
   
   if angle(i)~=0
        t = angle(i)*pi/180;
        if i == 1
            R = [1 0 0 0;0 cos(t) -sin(t) 0;0 sin(t) cos(t) 0;0 0 0 1];
        elseif i == 2
            R = [cos(t) 0 sin(t) 0;0 1 0 0;-sin(t) 0 cos(t) 0;0 0 0 1];
        else
            R = [cos(t) -sin(t) 0 0;sin(t) cos(t) 0 0;0 0 1 0;0 0 0 1];
        end
        new_top =  R * new_top;
        new_down = R * new_down;
        if is_knife
            knife_down = R * knife_down;
        end
   end           
end
new_x = [new_top(1,:);new_down(1,:)] + center_point(1);
new_y = [new_top(2,:);new_down(2,:)] + center_point(2);
new_z = [new_top(3,:);new_down(3,:)] + center_point(3);

figure(1)
surf(new_x,new_y,new_z,'FaceColor',[1,0,0]); 
hold on
fill3(new_x',new_y',new_z',[0 1 0]);   
daspect([1 1 1])        
if is_knife
    knife_x = [new_down(1,:);knife_down(1,:)] + center_point(1);
    knife_y = [new_down(2,:);knife_down(2,:)] + center_point(2);
    knife_z = [new_down(3,:);knife_down(3,:)] + center_point(3);
    surf(knife_x,knife_y,knife_z,'FaceColor',[0,1,0]);
end

