
% function f=myfun(a,b,c)
% 
% f = a*b;
% 
% end
syms x;
a = [1 2 3;4 5 6;1 1 1];
b = [2 3 4;5 6 7];
% [x,params,conds] = solve(x*a==b,'ReturnConditions', true)

b*inv(a)
% A = [1 2 3;4 5 6];
% C = [2 3 4;5 6 7];

