%flag = 0 ������X�᷽����
%flag = 1 ������Y�᷽����

function result = cutClothWithXY(figure_point_array , xy_value , flag)

    x = figure_point_array.x;
    y = figure_point_array.y;
    n = length(x);
    result = [];
    
    if flag == 0           
        if xy_value > figure_point_array.y_range(2) || xy_value < figure_point_array.y_range(1)
            return ;
        end 
             
        for i = 1:n        
            next_index =  1+ mod(i,n);
            if (y(i) == y(next_index)) continue ; end;
            if xy_value <= min(y(i) , y(next_index))  continue ;  end;
            if xy_value >= max(y(i) , y(next_index))  continue ;  end;
            new_x = (xy_value - y(i)) * (x(next_index) - x(i))/(y(next_index) - y(i)) + x(i);
            result = [result , new_x];
        end
        
    else
         if xy_value > figure_point_array.x_range(2) || xy_value < figure_point_array.x_range(1)
            return ;
        end 
        
        for i = 1:n        
            next_index =  1+ mod(i,n);
            if (x(i) == x(next_index)) continue ; end;
            if xy_value <= min(x(i) , x(next_index))  continue ;  end;
            if xy_value >= max(x(i) , x(next_index))  continue ;  end;
            new_y = (xy_value- x(i)) * (y(next_index) - y(i))/(x(next_index) - x(i)) + y(i);
            result = [result , new_y];
        end

    end