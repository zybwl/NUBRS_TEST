function [pos upos V]= NurbsInterpolation(Sparam,T,L,u0,u1)
global p;
global controlp;
global knotvector;
global w;
global n;
global wPi;
tspan = Sparam.t(end);
N = tspan/T;  %���ٸ�����

u = u0;
pos = curvePoint(n,p,knotvector,controlp,w,u)';
upos = u;%�洢�м�ֵ
sp = calcSParamByTime(Sparam,0);
v = sp(3);
a = sp(2);
s=sp(4);
V=[u0;v];
for i = 1:N
%      C=curvePoint(n,p,knotvector,controlp,w,u)';
%      Wu=getNurbsPointByParam(w,n,p,u,knotvector);
%      %%%%�����u����1��2�׵���(��һ��Ϊһ�׵����ڶ���Ϊ���׵�)
%      D2= DersOfNurbsByRecur(wPi',n,p,u,knotvector,2);
%      W2= DersOfNurbsByRecur(w,n,p,u,knotvector,2);
%      FirstDeri=(D2(:,1)-W2(:,1)* C)/Wu; 
%      %%%%��u����2�׵���
%      SeconDeri=(D2(:,2)-2*W2(:,1)* FirstDeri-W2(:,2)*C)/Wu;
%      
%      dP = norm(FirstDeri); %dP: dP/du
%      du = v/dP;%du:du/dt
%    
%       if k==1
%          u = u + T*du;
%      elseif k==2
% %         ddP = (FirstDeri(1)*SeconDeri(1)+FirstDeri(2)*SeconDeri(2))/dP; %ddP:ddP/ddu
%         ddP = dot(FirstDeri,SeconDeri)/dP;
%         ddu = a/dP - v^2*ddP/dP^3;%ddu:ddu/ddt
%         u = u + T*du + (T^2/2)*ddu;
%       end
if i==N-1
   222;
end
  lpos=s/L(1);
  umid=polyval(L(2:end),lpos); 
  if umid<0
      umid=0;
  end
  u=umid*(u1-u0)+u0;
    if u <= u1
        if i==N
             posi =curvePoint(n,p,knotvector,controlp,w,u1)';
             pos = [pos,posi];
             upos = [upos,u];
             V=[V,[u;v]];
             break;
        end
        posi = curvePoint(n,p,knotvector,controlp,w,u)';
        pos = [pos,posi];
        upos = [upos,u];
        V=[V,[u;v]];
    elseif u>u1
        posi =curvePoint(n,p,knotvector,controlp,w,u1)';
       % pos = [pos,posi];
       % upos = [upos,u];
        %V=[V,[u1;v]]; %%%ÿ�ε�ĩβ���������һ��
        break;
    end
    t = i*T;
    sp = calcSParamByTime(Sparam,t);
    v = sp(3); 
    a = sp(2);
    s=sp(4);
end

end