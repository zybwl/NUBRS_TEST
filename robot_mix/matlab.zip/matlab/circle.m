clc;clear ;
%point_origin = [-3,0;0,4;3,0];
point_origin = [1,0;1,1;0,1];
vect1 = point_origin(2,:) - point_origin(1,:);
vect3 = point_origin(3,:) - point_origin(1,:);
L = sqrt(vect1*vect1');
bottom_l = sqrt(vect3*vect3');
cos_theta = bottom_l /L /2;

% ���֪��Բ�������յ㣬����֪��Բ���Ƕȣ���α����Բ
index = 1;
for u = 0:0.01:1
    ws = (1-u)^2 + 2*cos_theta*u*(1-u)+ u^2;
    point(index,:) = ((1 - u)^2 *point_origin(1,:) + 2*cos_theta*u*(1-u)*point_origin(2,:) + u^2 * point_origin(3,:))/ws;
    index = index + 1;
    plot(point(:,1),point(:,2));
    pause(0.1);
end
hold on
plot([point_origin(:,1) ; point_origin(1,1)],[ point_origin(:,2); point_origin(1,2)]);
axis equal;


