function [Ot radius pnt_start pnt_end]=Solvelinecircle11(A,B,C,Obc,error,circle_clockwise)
 %%%%
Ot=[];
%%AB����
 VectorAB=B(1,:)-A(1,:);
 D=norm(VectorAB);
 
 %%B������������
 Rbc=norm(B(1,:)-Obc(1,:));
 Vector_obcB=(B-Obc)/ Rbc; 
 if circle_clockwise==1 %%1Ϊ˳ʱ�룬0Ϊ��ʱ�� 
     Vectorplane=[0,0,-1];
 else
     Vectorplane=[0,0,1];
 end
  %%��˼���  ע����˳�򣬲�˽�����Ҫ�����
 Vector_tanB=[Vector_obcB(3)*Vectorplane(2)-Vector_obcB(2)*Vectorplane(3),-(Vector_obcB(3)*Vectorplane(1)-Vector_obcB(1)*Vectorplane(3)),Vector_obcB(2)*Vectorplane(1)-Vector_obcB(1)*Vectorplane(2)];
 Vector_tanB=Vector_tanB/norm(Vector_tanB(1,:));
%%%%

%%%%����AB��ObcB�ļн��ж��ڽӺ�����
cos_theat=(VectorAB(1)*Vector_obcB(1)+VectorAB(2)*Vector_obcB(2)+VectorAB(3)*Vector_obcB(3))/D/Rbc;
theta=acos(cos_theat);
%%%%��Բ�ľ�dO2O
   % if theta>=pi/2
   %     dO2O=Rbc+r;
   % else   %%theta<pi/2
   %     dO2O=Rbc-r;
   %  end
%%%%%%%%%%%%

%%��һ������  �����ж�Բ�ķ���
%%%|(y2-y1)x-��x2-x1��y+(x2y1-x1y2)|=r1*d;
%%��B+Vector_tanB���������õ�
P=B+Vector_tanB*1000;
Pflag=P(1,1)*(B(1,2)-A(1,2))-P(1,2)*(B(1,1)-A(1,1))+A(1,2)*B(1,1)-A(1,1)*B(1,2);

%%%��Բ�� �㵽ֱ�߾���
Pflag1=Obc(1,1)*(B(1,2)-A(1,2))-Obc(1,2)*(B(1,1)-A(1,1))+A(1,2)*B(1,1)-A(1,1)*B(1,2);
lotoline=abs(Pflag1)/D;

if Pflag>0
    flag=1;
elseif Pflag<0
        flag=-1;
else
        flag=0;
        if (Vector_tanB(1,1)*VectorAB(1,1)<0)||(Vector_tanB(1,2)*VectorAB(1,2)<0)||(Vector_tanB(1,3)*VectorAB(1,3)<0)
            
                if Pflag1>0
                     flag=1;
                else 
                    flag1=-1;
                end
        else
            return ;   %%%%%����Ҫת�ӣ����У�˳�� 
        end    
end

if theta>=pi/2
    flag2=1;
    %%%%%%����жϹ���%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%�����ж�����  %%%%%%%%%%%%%%%%%%%%%
     %Pflag1=Obc(1,1)*(B(1,2)-A(1,2))-Obc(1,2)*(B(1,1)-A(1,1))+A(1,2)*B(1,1)-A(1,1)*B(1,2);
     %lotoline=abs(Pflag1)/D;
     if Pflag1>0
         flag3=1;
     elseif Pflag1<0
         flag3=-1;
     else
         flag3=0;
     end
     
     lgonggao=Rbc+flag3*flag*lotoline;  %%%%%%%�Ż����ӻ� �жϱ�־
else
    flag2=-1;
    %%%%%%�ڽ��ж� �ҳ�%%%%%%%%%%%%%%%%%%%%%%
    %Pflag1=Obc(1,1)*(B(1,2)-A(1,2))-Obc(1,2)*(B(1,1)-A(1,1))+A(1,2)*B(1,1)-A(1,1)*B(1,2);
    % lotoline=abs(Pflag1)/D;
     if Pflag1>0
         flag3=1;
     elseif Pflag1<0
         flag3=-1;
     else
         flag3=0;
     end     
     lgonggao=Rbc+flag3*flag*lotoline;  %%%%%%%�Ż����ӻ� �жϱ�־
     xianhalfsq=Rbc^2-lotoline^2;
     %���ߵ�һ����ҳ���һ�� ��ƽ���� ��Ȼ���ȥ���ߵ�һ�� ��Ϊת�����
     lgonggao=sqrt(xianhalfsq+lgonggao^2/4)-lgonggao/2;
end
   %%%%%�ж����
   if error>=lgonggao  %%%���ڵ��ڰ�������!!!!!ע��
    error=lgonggao/2;%%%%%%%%%�����ڹ��ߡ��ҳ���ʱ���趨���ߡ��ҳ�һ���������
   end
%%%%%%�ⷽ����
%dO2O=flag2*Rbc+r;

%%%%%%(y2-y1)x+��x1-x2)y+(x2y1-x1y2)=r*D*flag;
%%%%%%(x-Obc(1,1))^2+(y-Obc(1,2))^2=(flag2*Rbc+r)^2
%%%%%%(x-x2)^2+(y-y2)^2=(r+error)^2;  ����ax +by +c=dr
a1=(B(1,1)-Obc(1,1));
b1=(B(1,2)-Obc(1,2));
c1=-(Rbc^2-error^2+B(1,1)^2+B(1,2)^2-Obc(1,1)^2-Obc(1,2)^2)/2;
d1=(flag2*Rbc-error);


a0=(B(1,2)-A(1,2));
b0=(A(1,1)-B(1,1));
c0=(A(1,2)*B(1,1)-A(1,1)*B(1,2));
d0=D*flag;
W=B;
Z=error;

%%%�Ƚⷽ��  a0*x+b0*y+c0=d0*r
%%%%%%%%%%%%a1*x+b1*y+c1=d1*r
[x y r]=solvefunction(a0,b0,c0,d0,a1,b1,c1,d1,W,Z)

    %%%%%%ȡ��ֵr;
    if r(1)<=0&&r(2)>0
        radius=r(2);
        %%%%%%%%%%
        Ot(1)=x(2);
        Ot(2)=y(2);
       %%%%ֱ��B��Obc����Ϊ
       P1=B+Vector_tanB;
      % Pflag=P1(1)*(B(1,2)-Obc(1,2))-P1(2)*(B(1,1)-Obc(1,1))+Obc(1,2)*B(1,1)-Obc(1,1)*B(1,2);
      % Pflag1=x(1)*(B(1,2)-Obc(1,2))-y(1)*(B(1,1)-Obc(1,1))+Obc(1,2)*B(1,1)-Obc(1,1)*B(1,2);
      % Pflag2=x(2)*(B(1,2)-Obc(1,2))-y(2)*(B(1,1)-Obc(1,1))+Obc(1,2)*B(1,1)-Obc(1,1)*B(1,2);
       Pflag=(P1(1)-Obc(1,1))*(B(1,1)-A(1,1))+(P1(2)-Obc(1,2))*(B(1,2)-A(1,2));
       Pflag1=(Ot(1)-Obc(1,1))*(B(1,1)-A(1,1))+(Ot(2)-Obc(1,2))*(B(1,2)-A(1,2));
    elseif r(1)>0&&r(2)<=0
        radius=r(1);
         %%%%%%%%%%
        Ot(1)=x(1);
        Ot(2)=y(1);
        %%%%ֱ��B��Obc����Ϊ
       P1=B+Vector_tanB*1000;
      % Pflag=P1(1)*(B(1,2)-Obc(1,2))-P1(2)*(B(1,1)-Obc(1,1))+Obc(1,2)*B(1,1)-Obc(1,1)*B(1,2);
      % Pflag1=x(1)*(B(1,2)-Obc(1,2))-y(1)*(B(1,1)-Obc(1,1))+Obc(1,2)*B(1,1)-Obc(1,1)*B(1,2);
      % Pflag2=x(2)*(B(1,2)-Obc(1,2))-y(2)*(B(1,1)-Obc(1,1))+Obc(1,2)*B(1,1)-Obc(1,1)*B(1,2);
       Pflag=(B(1)-Obc(1,1))*(B(1,1)-A(1,1))+(B(2)-Obc(1,2))*(B(1,2)-A(1,2));
       Pflag1=(Ot(1)-Obc(1,1))*(B(1,1)-A(1,1))+(Ot(2)-Obc(1,2))*(B(1,2)-A(1,2));
       
    elseif r(1)>0&&r(2)>0
       
       %%%%ֱ��B��Obc����Ϊ
       P1=B+Vector_tanB;
      % Pflag=P1(1)*(B(1,2)-Obc(1,2))-P1(2)*(B(1,1)-Obc(1,1))+Obc(1,2)*B(1,1)-Obc(1,1)*B(1,2);
      % Pflag1=x(1)*(B(1,2)-Obc(1,2))-y(1)*(B(1,1)-Obc(1,1))+Obc(1,2)*B(1,1)-Obc(1,1)*B(1,2);
      % Pflag2=x(2)*(B(1,2)-Obc(1,2))-y(2)*(B(1,1)-Obc(1,1))+Obc(1,2)*B(1,1)-Obc(1,1)*B(1,2);
       Pflag=(B(1)-Obc(1,1))*(B(1,1)-A(1,1))+(B(2)-Obc(1,2))*(B(1,2)-A(1,2));
       Pflag1=(x(1)-Obc(1,1))*(B(1,1)-A(1,1))+(y(1)-Obc(1,2))*(B(1,2)-A(1,2));
       Pflag2=(x(2)-Obc(1,1))*(B(1,1)-A(1,1))+(y(2)-Obc(1,2))*(B(1,2)-A(1,2));
       if Pflag*Pflag1>0
           radius=r(1);
           Ot(1)=x(1);
           Ot(2)=y(1);
       else
           radius=r(2);
           Ot(1)=x(2);
           Ot(2)=y(2);
       end
    else
        return;
    end
 
   %%%%%%%���е��Բ�Ľ�
   Ot(3)=0;
    pnt_start=[];
    pnt_end=[];
    %Բ���������
    %%AB����
    length_BSlu = norm(Ot(1,:)-B(1,:));
    length_intercept = sqrt(length_BSlu*length_BSlu - radius*radius);
    length_AB = norm(A(1,:)-B(1,:));

    lamda = length_intercept / length_AB;
    pnt_start(1) = (1-lamda)*B(1) + lamda*A(1);
    pnt_start(2) = (1-lamda)*B(2) + lamda*A(2);
   

    %%//Բ���յ�����
    OObc=norm(Ot(1,:)-Obc(1,:));
    lamda = Rbc / OObc;
    pnt_end(1) = (1-lamda)*Obc(1) + lamda*Ot(1);
    pnt_end(2) = (1-lamda)*Obc(2) + lamda*Ot(2);
    pnt_end(3) = (1-lamda)*Obc(3) + lamda*Ot(3);
   %%%%%%%�ж� �е������Ƿ����߶�AB��Բ��ǰ1/2��
    if length_intercept > length_AB  %%%�е㲻���߶�AB��
       tag=0;     
    else
       tag=1;
    end
   %%Բ�Ľ��ж�  
   %%%%%��Բ�Ľ�
       vec_start(1)= B(1)-Obc(1);
       vec_start(2)= B(2)-Obc(2);
       vec_start(3)= B(3)-Obc(3);
       norm_start=norm(vec_start);
       vec_start(1)=vec_start(1)/ norm_start;
       vec_start(2)=vec_start(2)/norm_start;
       vec_start(3)=vec_start(3)/ norm_start;
       vec_end(1)= pnt_end(1)-Obc(1);
       vec_end(2)= pnt_end(2)-Obc(2); 
       vec_end(3)= pnt_end(3)-Obc(3); 
       norm_end=norm(vec_end);
       vec_end(1)= vec_end(1)/ norm_end;
       vec_end(2)= vec_end(2)/ norm_end;
       vec_end(3)= vec_end(3)/ norm_end;
   %%%%%%%
       Crossprod(1)= vec_start(2)*vec_end(3)-vec_start(3)*vec_end(2);
       Crossprod(2)= -vec_start(1)*vec_end(3)+vec_start(3)*vec_end(1);
       Crossprod(3)= vec_start(1)*vec_end(2)-vec_start(2)*vec_end(1); 
       sum=Crossprod(1)+Crossprod(2)+Crossprod(3);
       %%%%�нǶ���  0~180
       dot=vec_start(1)*vec_end(1)+vec_start(2)*vec_end(2)
       theta=acos(dot);
       if sum==0
           if theta>0
               res=0;
           else
               res=pi;
           end
       elseif sum>0
           if circle_clockwise==0
               res=theta;
           else
               res=2*pi-theta;
           end
       elseif sum<0
           if circle_clockwise==1
               res=theta;
           else
               res=2*pi-theta;
           end
       end
      %%%%%%%%%%%%%%%%%%%%%%%%
      %%%%%��Բ�Ľ�
       vec_start(1)= B(1)-Obc(1);
       vec_start(2)= B(2)-Obc(2);
       vec_start(3)= B(3)-Obc(3);
       norm_start=norm(vec_start);
       vec_start(1)=vec_start(1)/ norm_start;
       vec_start(2)=vec_start(2)/norm_start;
       vec_start(3)=vec_start(3)/ norm_start;
       vec_end(1)= C(1)-Obc(1);
       vec_end(2)= C(2)-Obc(2); 
       vec_end(3)= C(3)-Obc(3); 
       norm_end=norm(vec_end);
       vec_end(1)= vec_end(1)/ norm_end;
       vec_end(2)= vec_end(2)/ norm_end;
       vec_end(3)= vec_end(3)/ norm_end;
   %%%%%%%
       Crossprod(1)= vec_start(2)*vec_end(3)-vec_start(3)*vec_end(2);
       Crossprod(2)= -vec_start(1)*vec_end(3)+vec_start(3)*vec_end(1);
       Crossprod(3)= vec_start(1)*vec_end(2)-vec_start(2)*vec_end(1); 
       sum=Crossprod(1)+Crossprod(2)+Crossprod(3);
       %%%%�нǶ���  0~180
       dot=vec_start(1)*vec_end(1)+vec_start(2)*vec_end(2)
       theta=acos(dot);
       if sum==0
           if dot>0
               res1=0;
           else
               res1=pi;
           end
       elseif sum>0
           if circle_clockwise==0
               res1=theta;
           else
               res1=2*pi-theta;
           end
       elseif sum<0
           if circle_clockwise==1
               res1=theta;
           else
               res1=2*pi-theta;
           end
       end
      %%%%%%% �Ƕ�res  res/2 ; 
      
      if res<=res1/2
          tag2=1;%%%%��ǰ1/2Բ��
      else
          tag2=0;
      end
      
      if tag*tag2==0
         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         if tag==0 && tag2~=0
         %%%%%%���2 ��ǰ1/2Բ��,����ֱ����
         %%(x-x1)��x2-x1��+��y-y1��(y2-y1)=0;			(1)
         %%(y2-y1)x-��x2-x1��y+(x2y1-x1y2)=flag*r*d;   (2)
         %%(x-Ox2)^2+(y-Oy2)^2=(r+flag2*Rbc)^2;         (3)
 
        a1=(B(1,2)-A(1,2));
        b1=(A(1,1)-B(1,1));
        c1=(A(1,2)*B(1,1)-A(1,1)*B(1,2));
        d1=D*flag;

        a0=(B(1,1)-A(1,1));
        b0=(B(1,2)-A(1,2));
        c0=A(1,1)*(A(1,1)-B(1,1))+A(1,2)*(A(1,2)-B(1,2));
        d0=0;
        W=Obc;
        Z=flag2*Rbc;
        [x y r]=solvefunction(a0,b0,c0,d0,a1,b1,c1,d1,W,Z) 
                   %%%%%%ȡ��ֵr;
            if r(1)<=0&&r(2)>0
                radius=r(2);
                %%%%%%%%%%
                Ot(1)=x(2);
                Ot(2)=y(2);
            elseif r(1)>0&&r(2)<=0
                radius=r(1);
                 %%%%%%%%%%
                Ot(1)=x(1);
                Ot(2)=y(1);
            elseif r(1)>0&&r(2)>0

               %%%%ֱ��B��Obc����Ϊ
               P1=B+Vector_tanB;
               Pflag=P1(1)*(B(1,2)-Obc(1,2))-P1(2)*(B(1,1)-Obc(1,1))+Obc(1,2)*B(1,1)-Obc(1,1)*B(1,2);
               Pflag1=x(1)*(B(1,2)-Obc(1,2))-y(1)*(B(1,1)-Obc(1,1))+Obc(1,2)*B(1,1)-Obc(1,1)*B(1,2);
               Pflag2=x(2)*(B(1,2)-Obc(1,2))-y(2)*(B(1,1)-Obc(1,1))+Obc(1,2)*B(1,1)-Obc(1,1)*B(1,2);
               if Pflag*Pflag1>0
                   radius=r(1);
                   Ot(1)=x(1);
                   Ot(2)=y(1);
               else
                   radius=r(2);
                   Ot(1)=x(2);
                   Ot(2)=y(2);
               end
            else
                return;
            end
            %Բ���������
            pnt_start=A;
            pnt_end=[];
            %%//Բ���յ�����
            OObc=norm(Ot(1,:)-Obc(1,:));
            lamda = Rbc / OObc;
            pnt_end(1) = (1-lamda)*Obc(1) + lamda*Ot(1);
            pnt_end(2) = (1-lamda)*Obc(2) + lamda*Ot(2);
            pnt_end(3) = (1-lamda)*Obc(3) + lamda*Ot(3);  
            
            
         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
         elseif tag~=0 && tag2==0
         %%%%%  ��Բ�����е�  Բ���е�   %%%%%%%%%%%%%%%%%%%%%%%%%%%
         %%%%%%���3 ����ǰ1/2Բ��,��ֱ����
         middle=[];
         %��ת����仯���е㣬Բ�Ľ���֪��res1����ObcB��ת res1/2�ĽǶȡ���
         vecOB(1)=B(1)-Obc(1);
         vecOB(2)=B(2)-Obc(2);
         vecOB(3)=B(3)-Obc(3);
         if circle_clockwise==0  %%%%��ʱ��
            middle(1)=cos(res1/2)*vecOB(1)+(-1)*sin(res1/2)*vecOB(2)+Obc(1);
            middle(2)=sin(res1/2)*vecOB(1)+cos(res1/2)*vecOB(2)+Obc(2);  
         else  %%%%˳ʱ��
            res1=(-1)*res1; 
            middle(1)=cos(res1/2)*vecOB(1)+(-1)*sin(res1/2)*vecOB(2)+Obc(1);
            middle(2)=sin(res1/2)*vecOB(1)+cos(res1/2)*vecOB(2)+Obc(2); 
         end
         middle(3)= vecOB(3);
%          centerm(1)=0.5*(B(1)+C(1));
%          centerm(2)=0.5*(B(2)+C(2));
%          centerm(3)=0.5*(B(3)+C(3));
%          Pflag1=Obc(1,1)*(B(1,2)-A(1,2))-Obc(1,2)*(B(1,1)-A(1,1))+A(1,2)*B(1,1)-A(1,1)*B(1,2);
%          lotoline=abs(Pflag1)/D;  
%          if res1<pi  %%%�ӻ����
%              l1=Rbc-lotoline;
%              lamda=(-1)*l1/Rbc;
%              middle(1) = (1-lamda)*Obc(1) + lamda*centerm(1);
%              middle(2) = (1-lamda)*Obc(2) + lamda*centerm(2);
%              middle(3) = (1-lamda)*Obc(3) + lamda*centerm(3);  
%          elseif res1>pi %%%�Ż����
%              l1=Rbc+lotoline;
%              lamda=Rbc/Rbc+l1;
%              middle(1) = (1-lamda)*centerm(1) + lamda*Obc(1);
%              middle(2) = (1-lamda)*centerm(2) + lamda*Obc(2);
%              middle(3) = (1-lamda)*centerm(3) + lamda*Obc(3); 
%          else %%%����90�����
%             %%
%          end
         %%(x-middle(1))��Oy2-middle(2)��-��y-middle(2)��(Ox2-middle(1))=0;   (1)
         %%(y2-y1)x-��x2-x1��y+(x2y1-x1y2)=flag*r*d;   (2)
         %%(x-Ox2)^2+(y-Oy2)^2=(r+flag2*Rbc)^2;        (3)
         
        a1=(B(1,2)-A(1,2));
        b1=(A(1,1)-B(1,1));
        c1=(A(1,2)*B(1,1)-A(1,1)*B(1,2));
        d1=D*flag;

        a0=(Obc(1,2)-middle(2));
        b0=-1*(Obc(1,1)-middle(1));
        c0=-1*middle(1)*Obc(1,2)+middle(2)*Obc(1,1);
        d0=0;
        W=Obc;
        Z=flag2*Rbc;
        %%%%%%%%%
        [x y r]=solvefunction(a0,b0,c0,d0,a1,b1,c1,d1,W,Z) 
        %%%%%%ȡ��ֵr;
            if r(1)<=0&&r(2)>0
                radius=r(2);
                %%%%%%%%%%
                Ot(1)=x(2);
                Ot(2)=y(2);
            elseif r(1)>0&&r(2)<=0
                radius=r(1);
                 %%%%%%%%%%
                Ot(1)=x(1);
                Ot(2)=y(1);
            elseif r(1)>0&&r(2)>0

               %%%%ֱ��middle��Obc����Ϊ
               P1=B;
               Pflag=P1(1)*(middle(1,2)-Obc(1,2))-P1(2)*(middle(1,1)-Obc(1,1))+Obc(1,2)*middle(1,1)-Obc(1,1)*middle(1,2);
               Pflag1=x(1)*(middle(1,2)-Obc(1,2))-y(1)*(middle(1,1)-Obc(1,1))+Obc(1,2)*middle(1,1)-Obc(1,1)*middle(1,2);
               Pflag2=x(2)*(middle(1,2)-Obc(1,2))-y(2)*(middle(1,1)-Obc(1,1))+Obc(1,2)*middle(1,1)-Obc(1,1)*middle(1,2);
               if Pflag*Pflag1>0
                   radius=r(1);
                   Ot(1)=x(1);
                   Ot(2)=y(1);
               else
                   radius=r(2);
                   Ot(1)=x(2);
                   Ot(2)=y(2);
               end
            else
                return;
            end
            %Բ���������
            pnt_start=[];
            pnt_end=middle;
            %%//ֱ���е�����
             %%AB����
            length_BSlu = norm(Ot(1,:)-B(1,:));
            length_intercept = sqrt(length_BSlu*length_BSlu - radius*radius);
            %length_AB = norm(A(1,:)-B(1,:));

            lamda = length_intercept / length_AB;
            pnt_start(1) = (1-lamda)*B(1) + lamda*A(1);
            pnt_start(2) = (1-lamda)*B(2) + lamda*A(2);             
         
         
         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         else  tag==0 && tag2==0
         %%%%%%���4 ����ǰ1/2Բ��,����ֱ���� 
         
         %if res1>PI
         %1 %%%%%Բ���е�����
         middle=[];
         %��ת����仯���е㣬Բ�Ľ���֪��res1����ObcB��ת res1/2�ĽǶȡ���
         vecOB(1)=B(1)-Obc(1);
         vecOB(2)=B(2)-Obc(2);
         vecOB(3)=B(3)-Obc(3);
         if circle_clockwise==0  %%%%��ʱ��
            middle(1)=cos(res1/3)*vecOB(1)+(-1)*sin(res1/3)*vecOB(2)+Obc(1);
            middle(2)=sin(res1/3)*vecOB(1)+cos(res1/3)*vecOB(2)+Obc(2);  
         else  %%%%˳ʱ��
            res1=(-1)*res1; 
            middle(1)=cos(res1/3)*vecOB(1)+(-1)*sin(res1/3)*vecOB(2)+Obc(1);
            middle(2)=sin(res1/3)*vecOB(1)+cos(res1/3)*vecOB(2)+Obc(2); 
         end
         middle(3)= vecOB(3);
        midAB=[ ];           
		midAB(1)= (A(1,1) + B(1,1)) / 2;
		midAB(2) = (A(1,2) + B(1,2)) / 2;
        midAB(3) = A(3);
         %%%%%%% �󽻵㣬Բ�ġ�middle ֱ�ߺ͹�A�㴹ֱABֱ��  crossoverPoint  
         %%%%%%%%(x-middle(1))��Oy2-middle(2)��-��y-middle(2)��(Ox2-middle(1))=0;   (1)
         %%%%%%%%(x-x1)��x2-x1��+��y-y1��(y2-y1)=0; (2)
         crossoverPoint=[];
          a1=(B(1,1)-midAB(1,1));
          b1=(B(1,2)-midAB(1,2));
          c1=(midAB(1,1)^2+midAB(1,2)^2-midAB(1,1)*B(1,1)-midAB(1,2)*B(1,2));
        
          a0=(Obc(1,2)-middle(2));
          b0=-1*(Obc(1,1)-middle(1));
          c0=-1*middle(1)*Obc(1,2)+middle(2)*Obc(1,1);
         
          if a0*b1-a1*b0==0
              return;
          end
           crossoverPoint(2)=-1*(a1*c0-a0*c1)/(a1*b0-a0*b1);
          if a0~=0
           crossoverPoint(1)=-1*(b0*crossoverPoint(2)+c0)/a0;
          elseif a1~=0
           crossoverPoint(1)=-1*(b1*crossoverPoint(2)+c1)/a1;  
          else
              return;
          end
           crossoverPoint(3)=0;
         %%%%%%%%%%%%%%%%%%%�����������  crossoverPoint  �ж�crossoverPoint-A���Ⱥ�crossoverPoint-middle����
         ll1=norm(crossoverPoint-midAB);
         ll2=norm(crossoverPoint-middle);
         if ll1>ll2
             %%%%���2
                  %%%%%%���2 ��ǰ1/2Բ��,����ֱ����
                 %%(x-x1)��x2-x1��+��y-y1��(y2-y1)=0;			(1)
                 %%(y2-y1)x-��x2-x1��y+(x2y1-x1y2)=flag*r*d;   (2)
                 %%(x-Ox2)^2+(y-Oy2)^2=(r+flag2*Rbc)^2;         (3)

                a1=(B(1,2)-A(1,2));
                b1=(A(1,1)-B(1,1));
                c1=(A(1,2)*B(1,1)-A(1,1)*B(1,2));
                d1=(D/1)*flag;

                a0=(B(1,1)-midAB(1,1));
                b0=(B(1,2)-midAB(1,2));
                c0=midAB(1,1)*(midAB(1,1)-B(1,1))+midAB(1,2)*(midAB(1,2)-B(1,2));
                d0=0;
                W=Obc;
                Z=flag2*Rbc;
                [x y r]=solvefunction(a0,b0,c0,d0,a1,b1,c1,d1,W,Z) 
                           %%%%%%ȡ��ֵr;
                    if r(1)<=0&&r(2)>0
                        radius=r(2);
                        %%%%%%%%%%
                        Ot(1)=x(2);
                        Ot(2)=y(2);
                    elseif r(1)>0&&r(2)<=0
                        radius=r(1);
                         %%%%%%%%%%
                        Ot(1)=x(1);
                        Ot(2)=y(1);
                    elseif r(1)>0&&r(2)>0

                       %%%%ֱ��B��Obc����Ϊ
                       %%%%ֱ��middle��Obc����Ϊ
                       P1=B;
                       Pflag=P1(1)*(middle(1,2)-Obc(1,2))-P1(2)*(middle(1,1)-Obc(1,1))+Obc(1,2)*middle(1,1)-Obc(1,1)*middle(1,2);
                       Pflag1=x(1)*(middle(1,2)-Obc(1,2))-y(1)*(middle(1,1)-Obc(1,1))+Obc(1,2)*middle(1,1)-Obc(1,1)*middle(1,2);
                       Pflag2=x(2)*(middle(1,2)-Obc(1,2))-y(2)*(middle(1,1)-Obc(1,1))+Obc(1,2)*middle(1,1)-Obc(1,1)*middle(1,2);
                       if Pflag*Pflag1>0
                           radius=r(1);
                           Ot(1)=x(1);
                           Ot(2)=y(1);
                       else
                           radius=r(2);
                           Ot(1)=x(2);
                           Ot(2)=y(2);
                       end
                    else
                        return;
                    end
                    %Բ���������
                    pnt_start=midAB;
                    pnt_end=[];
                    %%//Բ���յ�����
                    OObc=norm(Ot(1,:)-Obc(1,:));
                    lamda = Rbc / OObc;
                    pnt_end(1) = (1-lamda)*Obc(1) + lamda*Ot(1);
                    pnt_end(2) = (1-lamda)*Obc(2) + lamda*Ot(2);
                    pnt_end(3) = (1-lamda)*Obc(3) + lamda*Ot(3);       
             
             
             
         else
             %%%���3

                    a1=(B(1,2)-A(1,2));
                    b1=(A(1,1)-B(1,1));
                    c1=(A(1,2)*B(1,1)-A(1,1)*B(1,2));
                    d1=D*flag;

                    a0=(Obc(1,2)-middle(2));
                    b0=-1*(Obc(1,1)-middle(1));
                    c0=-1*middle(1)*Obc(1,2)+middle(2)*Obc(1,1);
                    d0=0;
                    W=Obc;
                    Z=flag2*Rbc;
                    %%%%%%%%%
                    [x y r]=solvefunction(a0,b0,c0,d0,a1,b1,c1,d1,W,Z) 
                    %%%%%%ȡ��ֵr;
                        if r(1)<=0&&r(2)>0
                            radius=r(2);
                            %%%%%%%%%%
                            Ot(1)=x(2);
                            Ot(2)=y(2);
                        elseif r(1)>0&&r(2)<=0
                            radius=r(1);
                             %%%%%%%%%%
                            Ot(1)=x(1);
                            Ot(2)=y(1);
                        elseif r(1)>0&&r(2)>0

                           %%%%ֱ��B��Obc����Ϊ
                                       %%%%ֱ��middle��Obc����Ϊ
                           P1=B;
                           Pflag=P1(1)*(middle(1,2)-Obc(1,2))-P1(2)*(middle(1,1)-Obc(1,1))+Obc(1,2)*middle(1,1)-Obc(1,1)*middle(1,2);
                           Pflag1=x(1)*(middle(1,2)-Obc(1,2))-y(1)*(middle(1,1)-Obc(1,1))+Obc(1,2)*middle(1,1)-Obc(1,1)*middle(1,2);
                           Pflag2=x(2)*(middle(1,2)-Obc(1,2))-y(2)*(middle(1,1)-Obc(1,1))+Obc(1,2)*middle(1,1)-Obc(1,1)*middle(1,2);
                           if Pflag*Pflag1>0
                               radius=r(1);
                               Ot(1)=x(1);
                               Ot(2)=y(1);
                           else
                               radius=r(1);
                               Ot(1)=x(1);
                               Ot(2)=y(1);
                           end
                        else
                            return;
                        end
                        %Բ���������
                        pnt_start=[];
                        pnt_end=middle;
                        %%//ֱ���е�����
                         %%AB����
                        length_BSlu = norm(Ot(1,:)-B(1,:));
                        length_intercept = sqrt(length_BSlu*length_BSlu - radius*radius);
                        length_AB = norm(A(1,:)-B(1,:));

                        lamda = length_intercept / length_AB;
                        pnt_start(1) = (1-lamda)*B(1) + lamda*A(1);
                        pnt_start(2) = (1-lamda)*B(2) + lamda*A(2);               
             
             
         end       
          
        end 
         
      else 
          %%%%%���1���������������%%%%%
      end
      
      



end
