function  x = backward_substitution(matrix_u, y)

    q = length(y);
    x = zeros(q,1);
    x(q) = y(q) / matrix_u(q ,q);

    for i = q - 1 :-1:1
        s = 0;
        for j = i:q  
            s =  s + matrix_u(i,j) * x(j);
        end
         x(i) = y(i) - s;
         x(i) = x(i) / matrix_u(i,i);
    end