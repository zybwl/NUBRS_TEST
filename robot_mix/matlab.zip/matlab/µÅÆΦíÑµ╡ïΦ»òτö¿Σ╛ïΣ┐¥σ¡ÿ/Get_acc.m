function acc = Get_acc(DynamicInfo)
    t = DynamicInfo.t;
    if(DynamicInfo.current_time < t(1))
        relative_time = DynamicInfo.current_time;
        acc = DynamicInfo.J * relative_time;
    elseif(DynamicInfo.current_time < t(2))
        acc = DynamicInfo.acceleration;
    elseif(DynamicInfo.current_time < t(3))
        relative_time = DynamicInfo.current_time - t(2);
        acc = DynamicInfo.acceleration -  DynamicInfo.J * relative_time;
    elseif(DynamicInfo.current_time < t(4))
        acc = 0;
    elseif(DynamicInfo.current_time < t(5))
        relative_time = DynamicInfo.current_time - t(4);
        acc = -DynamicInfo.J * relative_time;
    elseif(DynamicInfo.current_time < t(6))
        acc = -DynamicInfo.deceleration;
    elseif(DynamicInfo.current_time < t(7))
        relative_time = DynamicInfo.current_time - t(6);
        acc = -(DynamicInfo.deceleration - DynamicInfo.J * relative_time);
    else
        acc = 0;
    end
end