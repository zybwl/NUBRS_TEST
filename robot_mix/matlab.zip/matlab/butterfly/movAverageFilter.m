function y = movAverageFilter(x,t)

% ���� x ���� t �˲����ڴ�С
n = length(x);

for i = t:length(x)
    y(i) = sum(x(i-t+1:i))/t;
end

ybegin = cumsum(x(1:t-2));
ybegin = ybegin(1:2:end)./(1:2:(t-2));
yend = cumsum(x(n:-1:n-t+3));
yend = yend(end:-2:1)./(t-2:-2:1);
y = [ybegin,y(t:end),yend];