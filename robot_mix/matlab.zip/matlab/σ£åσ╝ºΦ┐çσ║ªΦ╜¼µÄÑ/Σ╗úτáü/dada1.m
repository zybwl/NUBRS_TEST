A=[0,0,0];%%%�����ֵδ�õ�
B=[100,0,0];
C=[100,50,0];
Oab=[15,0,0];
error=2000;
circle_clockwise=1;
[Ot r startPoint endPoint]=Solvecircleline22(A,B,C,Oab,error,circle_clockwise)

x=[B(1,1) C(1,1)];
y=[B(1,2) C(1,2)];
plot(x,y);
hold on
x0 = Ot(1), y0 = Ot(2); %ԭ��
theta=0:pi/10000:2*pi; %�Ƕ�[0,2*pi]
R=r; %�뾶
x=R*cos(theta)+x0;
y=R*sin(theta)+y0;
plot(x,y,'-r')
axis equal
hold on
x0 = Oab(1), y0 = Oab(2); %ԭ��
theta=0:pi/10000:2*pi; %�Ƕ�[0,2*pi]
R=norm(B-Oab); %�뾶
x=R*cos(theta)+x0;
y=R*sin(theta)+y0;
plot(x,y,'-')
axis equal
grid on
hold on
plot(startPoint(1),startPoint(2),'*');
hold on
plot(endPoint(1),endPoint(2),'*');