% % Matlab�к����Ĳ������ǲ��ð�ֵ���ݵķ�ʽ��û�а����ô��ݵķ�ʽ������C++����Ա�ܲ�ϰ�ߣ��ܶ�ʱ�����ǿ��ܻ���Ҫ���ں�����ʵ��
% % �޸Ĳ�����ֵ���������ڵ����������һ�����ṹ��ʱ,��ʱֻ���ú����Ĳ���ͬʱ��Ϊͬ������ֵ
function TVelocity = TVelocityPlanning
    TVelocity.GetSpeed = @GetSpeed;
    TVelocity.GetDistance = @GetDistance;
    TVelocity.Get_acc = @Get_acc;
    TVelocity.ComputeUniformDistance = @ComputeUniformDistance;
    TVelocity.ComputeTimeLength = @ComputeTimeLength;
    
    TVelocity.m_fs_limit_dist = 0;	%fs^2/(2*A)
	TVelocity.m_fe_limit_dist = 0;	%fe^2/(2*D)
	TVelocity.m_recip_A_D = 0;		%1/(1/2A+1/2D)
    
end

function acc = Get_acc(dynamic_info)
    t = dynamic_info.t;
    if(dynamic_info.current_time < t(1))
        acc = dynamic_info.acceleration;
    elseif(dynamic_info.current_time < t(2))
        acc = 0;
    elseif(dynamic_info.current_time < dynamic_info.total_time - m_half_interpolation_cycle)
        acc = -dynamic_info.deceleration ;  
    else
        acc = 0;
    end
end

function speed = GetSpeed(dynamic_info)
    
    t = dynamic_info.t;
    speed = 0;
    if(dynamic_info.current_time < t(1))
        relative_time = dynamic_info.current_time;
        speed = dynamic_info.fs + dynamic_info.acceleration * relative_time;
    elseif(dynamic_info.current_time < t(2))
        speed = dynamic_info.f;
    elseif(dynamic_info.current_time < dynamic_info.total_time - m_half_interpolation_cycle)
        relative_time = dynamic_info.current_time - t(2);
        speed = dynamic_info.f - dynamic_info.deceleration * relative_time;
    else
        speed = dynamic_info.fe;
    end
end

function l = GetDistance(dynamic_info)
    
    t = dynamic_info.t;    
    l = 0;
    if(dynamic_info.current_time < t(1))
        relative_time = dynamic_info.current_time;      
        l = dynamic_info.ls + dynamic_info.fs * relative_time + 0.5 * dynamic_info.acceleration * relative_time^2;   
    elseif(dynamic_info.current_time < t(2))
        relative_time = dynamic_info.current_time - t(1);
        l = dynamic_info.L(1) + dynamic_info.f * relative_time;
    elseif(dynamic_info.current_time < dynamic_info.total_time - m_half_interpolation_cycle)
        relative_time = dynamic_info.current_time - t(2);
        l = dynamic_info.L(2) + dynamic_info.f * relative_time + 0.5 * dynamic_info.deceleration * relative_time^2;       
    else
        l = dynamic_info_copy.le ;
    end  
end

function uniform_displacement = ComputeUniformDistance(dynamic_info)
    uniform_displacement = dynamic_info.distance - dynamic_info.f^2 * 0.5 * (1.0 / dynamic_info.acceleration ...
    + 1.0 / dynamic_info.deceleration) + TVelocity.m_fs_limit_dist + TVelocity.m_fe_limit_dist;
end

function ComputeTimeLength(dynamic_info)
    uniform_displacement = ComputeUniformDistance(dynamic_info);  
    if (uniform_displacement < -1e-3) 
        %���ٽ׶ξ���С���㣬˵�����ٽ׶β�����
    	if(fabs(dynamic_info.acceleration + dynamic_info.deceleration) < 1e-3)
    		dynamic_info.f = dynamic_info.fe;
        else 
    		%uniform_displacement=0 => f=[(le+fs^2/2A+fe^2/2D)/(1/2A+1/2D)]^0.5
        	dynamic_info.f = sqrt((dynamic_info.distance +  TVelocity.m_fs_limit_dist + TVelocity.m_fe_limit_dist) * TVelocity.m_recip_A_D);
        end
		uniform_displacement = 0.0;
    end
    %���Ŀ���ٶȲ�������
    if(dynamic_info.f > 1e-3) 
    	dynamic_info.T(1) = uniform_displacement / dynamic_info.f;
    else
    	%���Ŀ���ٶ�Ϊ�㣬����Ҫ�޸Ĺ滮�����߳����Լ��յ���롣���߽����м��ĳһ��ֹͣ
    	dynamic_info.T(1) = 0.0;
    	dynamic_info.le = dynamic_info.le - uniform_displacement;
    	dynamic_info.distance = dynamic_info.distance - uniform_displacement;
    end
    dynamic_info.T(0) = (dynamic_info.f - dynamic_info.fs) / dynamic_info.acceleration;
    dynamic_info.T(2) = (dynamic_info.f - dynamic_info.fe) / dynamic_info.deceleration;
end

