% clc;clear ;
% kv = [0 0 0 0 3.65028 5.0645 10.1132 10.1132 10.1132 10.1132];
% u = [0 1.41421 3.65028 5.0645 6.79655 10.1132];
% degree = 3;
% control_points = [0 0 0; 1.21751 3.03358 -0.055443; 1.30228 -2.50778 0.143106; 4.00965 1.62706 -0.347467; 4.97382 1.32298 2.91372; 3 0 4 ];
% 
% index = 1;
% for i = 1:6
%     span = findspan(5  , degree , u(i) ,kv );
%     N  = basisfun( span , u(i) ,degree ,kv );
%     new_points(index,:) = N * control_points(span - degree + 1 : span + 1 , :);
%     index = index + 1
% end 
% 
% new_points




clc;clear ;
kv = [0 0 0 0 23.7877 33.0073 54.6068 54.6068 54.6068 54.60689];
% u = [0 1.41421 3.65028 5.0645 6.79655 10.1132];
u = 0:54.6068/99:54.6068;
degree = 3;
control_points = [-13 4; -7.35458 9.23299; 8.23889 9.9678; 14.5384 -12.0441; -5.48679 -12.6921; -9 -9  ];
xx = [-13, 4;-2,8; 9,3;11,-6;3,-11;-9,-9];

index = 1;
for i = 1:100
    span = findspan(5  , degree , u(i) ,kv );
    N  = basisfun( span , u(i) ,degree ,kv );                                                                                                                                                                                                                                                                                                                                                   
    new_points(index,:) = N * control_points(span - degree + 1 : span + 1 , :);
    index = index + 1
end 

plot(new_points(:,1), new_points(:,2));
hold on
plot(xx(:,1), xx(:,2));


