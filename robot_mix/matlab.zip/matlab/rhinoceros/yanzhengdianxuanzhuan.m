% clc;clear all;
% file_name = 'ez.nc';
% points = get_nc_data(file_name);
% n = length(points);
% line_before = 'T1';
% 
% for i = 1:n
%     one_point = points(i);
%     if one_point.F == 1000
%         line_before = sprintf('%s\nX%.4f Y%.4f Z%.4f A%.4f C%.4f',line_before,one_point.X ,one_point.Y,one_point.Z, -one_point.A, -one_point.C);
%     end        
% end
% 
% output_file = 'yuban.txt';
% fid= fopen(output_file, 'wt');
% fprintf(fid, '%s', line_before);
% fclose(fid);
% 
% 
% 
% 
% % 
points = [3.1028 4.3303 1.3787  1;3.9069  3.5893 1.4649 1;4.5747 2.7212 1.4037 1]';
rot_a = get_rotation_matrix(1, 6);
rot_b = get_rotation_matrix(2, 8);
rot_c = get_rotation_matrix(3, 10);
%��������ϵ�ڶ������Ƕ�
rot_p = rot_c * rot_b * rot_a * points;

% ƽ�ƾ���
tv = [ -6.9946    -47.0039  0];
transfer_matrix =  get_translation_matrix( tv );
% %ƽ�ƺ���µ�
new_p = transfer_matrix * rot_p
% %�Ե����λ��
% center_a = [-24.5,-47,-6];
% center_c = [-8,-47,-3];
% angle_a = 77.1622;
% angle_c = 35.692;
% new_points = get_tr_position(center_a, center_c , angle_a, angle_c, new_p(:,1))
% 
% angle_a = 75.0127;
% angle_c = 46.8535;
% new_points = get_tr_position(center_a, center_c , angle_a, angle_c, new_p(:,2))
% 
% angle_a = 77.1622;
% angle_c = 58.0919;
% new_points = get_tr_position(center_a, center_c , angle_a, angle_c, new_p(:,3))
% % 
% % 
% % % ppp = [-4.4403,-42.3231,1.37421, 1; -3.52545,-42.9193,1.27049 , 1;-2.74617,-43.6521,1.02742 1]';
% % % kkk = new_p  - ppp
% % 
% % % rot_points = [-7.8363,-52.8853,1.36307 1;-6.74549,-52.7732,1.38836 1;-5.68507,-52.5674,1.1974 1]';
% % % center_a = [-24.5,-47,-6,0;-24.5,-47,-6,0;-24.5,-47,-6,0]';
% % % v1 = rot_points - center_a;
% % % v2 = [-24.5 -47 -6] - [-8,-47,-3];
% % % t1 = get_translation_matrix(v2);
% % % t2 = get_translation_matrix([-8,-47,-3]);
% % % rot_a = get_rotation_matrix(1, -77.1622);
% % % rot_c = get_rotation_matrix(3, -35.692);
% % % rot_new_p =  t2 * rot_c * t1 * rot_a * v1;
% % % 
% % % kk = rot_new_p - new_p
% % % kk
% % 
% % 
% % 
% % 
% % 
% % 

% dataA = [-24.5,-47,-6];
% t = 0:2*pi/3:2*pi;
% x = -47 + 10 *cos(t)
% y = -6 + 10 * sin(t)

% dataA = [-8,-47,-3];
% t = 0:2*pi/3:2*pi;
% x = -8 + 6 *cos(t)
% y = -47 + 6 * sin(t)




