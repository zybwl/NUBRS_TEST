function DynamicInfo_copy = GetSpeed(DynamicInfo)
   
    DynamicInfo_copy = DynamicInfo;
    t = DynamicInfo.t;
    speed = 0;
    if(DynamicInfo.current_time < t(1))
        relative_time = DynamicInfo.current_time;
        speed = DynamicInfo.fs + 0.5* DynamicInfo.J * relative_time^2;
        DynamicInfo_copy.F(1) = speed;
    elseif(DynamicInfo.current_time < t(2))
        relative_time = DynamicInfo.current_time - t(1);
        speed = DynamicInfo.F(1) + DynamicInfo.acceleration * relative_time;
        DynamicInfo_copy.F(2) = speed;
    elseif(DynamicInfo.current_time < t(3))
        relative_time = DynamicInfo.current_time - t(2);
        speed = DynamicInfo_copy.F(2) + DynamicInfo_copy.acceleration * relative_time - 0.5 * DynamicInfo_copy.J * relative_time^2;
        DynamicInfo_copy.F(3) = speed;
    elseif(DynamicInfo.current_time < t(4))
        speed = DynamicInfo_copy.F(3);
        DynamicInfo_copy.F(4) = speed;      
    elseif(DynamicInfo.current_time < t(5))
        relative_time = DynamicInfo.current_time - t(4);
        speed = DynamicInfo_copy.F(4) -  0.5 * DynamicInfo.J * relative_time^2;
        DynamicInfo_copy.F(5) = speed;
    elseif(DynamicInfo.current_time < t(6))
        relative_time = DynamicInfo.current_time - t(5);
        speed = DynamicInfo_copy.F(5) -  DynamicInfo.deceleration * relative_time;
        DynamicInfo_copy.F(6) = speed;
    elseif(DynamicInfo.current_time <= t(7))
        relative_time = DynamicInfo.current_time - t(6);
        speed = DynamicInfo_copy.F(6) - DynamicInfo.deceleration * relative_time + 0.5 * DynamicInfo_copy.J * relative_time^2;
        DynamicInfo_copy.F(7) = speed;
    else
        speed = 0;
    end
    DynamicInfo_copy.speed = speed;
end
