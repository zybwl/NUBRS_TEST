function [x,y,z] = get_cuboid_data(cuboid_param , center , angle)
   
    points = [0 0 0; 1 0 0; 1 1 0; 0 1 0; 0 0 1; 1 0 1; 1 1 1; 0 1 1];
    pindex = [1 2 6 5;2 3 7 6;3 4 8 7;4 1 5 8;1 2 3 4;5 6 7 8 ];      
    adjust_x = cuboid_param(1)* points(:,1) - cuboid_param(1)/2 ;
    adjust_y = cuboid_param(2)* points(:,2) - cuboid_param(2)/2 ;
    adjust_z = cuboid_param(3)* points(:,3) - cuboid_param(3)/2 ;
    add_ones = ones(length(adjust_x(:)), 1);
    points = [adjust_x(:),adjust_y(:),adjust_z(:),add_ones]';
    %��תa����תc�Ƕ�
    rot_a = get_rotation_matrix(1, angle(1));
    rot_c = get_rotation_matrix(2, angle(2));
    new_points = rot_c * rot_a * points ;
    new_x = new_points(1,:) + center(1);
    new_y = new_points(2,:) + center(2);
    new_z = new_points(3,:) + center(3); 
    x = zeros(4,6);
    y = zeros(4,6);
    z = zeros(4,6);
    for i = 1:6
        x(:,i) = new_x(pindex(i,:))';
        y(:,i) = new_y(pindex(i,:))';
        z(:,i) = new_z(pindex(i,:))';
    end
%     fill3(x, y, z,[1,0,0]);
%     axis equal
%     xlabel('x');ylabel('y');zlabel('z');
%     camlight

