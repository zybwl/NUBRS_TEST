function  draw_machine_figure(angleA, angleC)

angle = [angleA,0];
cuboid_param = [100, 30, 5];
center1 = [100,100,0];
[x1, y1,z1] = get_cuboid_data(cuboid_param ,center1, angle);
fill3(x1, y1, z1,[1,0,0]);
axis([50 150 80 120 -20 20]);
hold on
axis equal
xlabel('x');ylabel('y');zlabel('z');

angle = [angleA, angleC];
center2 = [125, 100, 3.5];
ra = get_rotation_matrix(1 , angle(1));
ta = get_translation_matrix(center1);
new_center = ta * ra * [center2 - center1 , 1]';
new_center2 = new_center(1:3)';
h = 2;
r = 10;
[x2, y2, z2] = get_cylinder_data(new_center2, h , r ,angle);
surf(x2,y2,z2 ,'FaceColor',[0,0,1]);
fill3(x2,y2,z2, [0 1 0]); 
plot3(x2',y2',z2','*');
axis([50 150 80 120 -20 20]);

angle = [angleA, angleC];
center3 = [127, 103 , 4.5];
rc = get_rotation_matrix(3 , angle(2));
tc = get_translation_matrix(center2 - center1);
new_center = ta * ra * tc * rc * [center3 - center2 , 1]';
new_center3 = new_center(1:3)';
r = 5;
[x3, y3, z3] = get_halfball_data(new_center3,r , angle);
mesh(x3,y3,z3); 
plot3(x3,y3,z3);
axis([50 150 80 120 -20 20]);
