function [sys,x0,str,ts] = pidd11(t,x,u,flag)
switch flag,
    case 0,
        [sys,x0,str,ts]=mdlInitializeSizes;
    case 2,
        sys=mdlUpdate(t,x,u);
    case 3,
        sys=mdlOutputs(t,x,u);
    case {1,4,9},
        sys=[];
    otherwise
        error(['Unhandled flag = ',num2str(flag)]);
end

function [sys,x0,str,ts]=mdlInitializeSizes

sizes = simsizes;
sizes.NumContStates  = 0;
sizes.NumDiscStates  = 3;
sizes.NumOutputs     = 1;
sizes.NumInputs      = 2;
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 1;    % at least one sample time is needed
sys = simsizes(sizes);
x0  = [0 0 0];
str = [];
ts  = [0.01 0];

function sys=mdlUpdate(t,x,u)
sys=[u(1) x(2)+u(1)*0.01 (u(1)-u(2))/0.01];

function sys=mdlOutputs(t,x,u)
p=30;i=5;d=3.2;
sys=p*x(1)+i*x(2)+d*x(3);

