function [x y r]=solvefunction(a0,b0,c0,d0,a1,b1,c1,d1,Obc,Z)

    if (a0*b1-a1*b0)~=0 
        %%%%����������  y=m1*r+n1;x=m0*r+n0;
        m1=(a0*d1-a1*d0)/(a0*b1-a1*b0);  %(a0*b1-a1*b0)�ж��Ƿ����0
        n1=-1*(a0*c1-a1*c0)/(a0*b1-a1*b0);

        m0=(b1*d0-b0*d1)/(a0*b1-a1*b0);
        n0=-1*(b1*c0-b0*c1)/(a0*b1-a1*b0);

        %%����Բ�ķ���2 ���r��ֵ l*r^2+k*r+i=0
        l=m0^2+m1^2-1;
        k=2*(m0*(n0-Obc(1,1))+m1*(n1-Obc(1,2))-Z);
        i=(n0-Obc(1,1))^2+(n1-Obc(1,2))^2-Z^2;
        if abs(l)<10^-10
            if k==0
                return;
            end
            r(1)=-i/k;
            r(2)=r(1);

                x(1)=m0*r(1)+n0;
                y(1)=m1*r(1)+n1;
                x(2)=m0*r(2)+n0;
                y(2)=m1*r(2)+n1;
        else
            if k^2-4*l*i<0
                return;
            end
            r(1)=(-1*k+sqrt(k^2-4*l*i))/(2*l);
            r(2)=(-1*k-sqrt(k^2-4*l*i))/(2*l);

                x(1)=m0*r(1)+n0;
                y(1)=m1*r(1)+n1;
                x(2)=m0*r(2)+n0;
                y(2)=m1*r(2)+n1;
        end
    elseif a0==0&&a1==0 &&(b0~=0&&b1~=0)

        r(1)=(b0*c1-b1*c0)/(b0*d1-b1*d0);
        r(2)=r(1);
        if r(1)<0
            return;
        end
         Ot(2)=(d0*r(1)-c0)/b0;
         %%(x-Obc(1,1))^2=(flag2*Rbc+r)^2-(Ot(2)-Obc(1,2))^2
        if ((Z+r(1))^2-(Ot(2)-Obc(1,2))^2>0)
          Ot11=Obc(1,1)+sqrt((Z+r(1))^2-(Ot(2)-Obc(1,2))^2);
          Ot12=Obc(1,1)-sqrt((Z+r(1))^2-(Ot(2)-Obc(1,2))^2);
        else
            return ;
        end
       y(1)=Ot(2);
       y(2)=Ot(2);
       x(1)=Ot11;
       x(2)=Ot12;    

    elseif b0==0&&b1==0&&a0~=0&&a1~=0

         r(1)=(a0*c1-a1*c0)/(a0*d1-a1*d0);   
         r(2)=r(1);
        if r(1)<0
            return;
        end
         Ot(1)=(d0*r(1)-c0)/a0;
         %%(x-Obc(1,1))^2+(Ot(2)-Obc(1,2))^2=(flag2*Rbc+r)^2
        if ((Z+r(1))^2-(Ot(1)-Obc(1,1))^2>0)
          Ot21=Obc(1,2)+sqrt((Z+r(1))^2-(Ot(1)-Obc(1,1))^2);
          Ot22=Obc(1,2)-sqrt((Z+r(1))^2-(Ot(1)-Obc(1,1))^2);
        else
            return ;
        end
       y(1)=Ot21;
       y(2)=Ot22;
       x(1)=Ot(1);
       x(2)=Ot(1); 

    else
        %%%��ֱ��ƽ��  
        %%%�Ƚⷽ��  a0*x+b0*y+c0=d0*r
        %%%%%%%%%%%%a1*x+b1*y+c1=d1*r
        %%%%%%(y2-y1)x+��x1-x2)y+(x2y1-x1y2)=r*D*flag;
        %%%%%%(x-Obc(1,1))^2+(y-Obc(1,2))^2=(flag2*Rbc+r)^2
        %%%%%%(x-x2)^2+(y-y2)^2=(r+error)^2;  ����ax +by +c=dr
        if (a0*d1-a1*d0)==0
            return;
        end
         r(1)=(a0*c1-a1*c0)/(a0*d1-a1*d0);
         r(2)=r(1);

%        if r<=0
%            %%% ���ٽ�error a0*c1-a1*c0=0 c1=a1*c0/a0
%            zhongjianV=-0.5*(Rbc^2+B(1,1)^2+B(1,2)^2-Obc(1,1)^2-Obc(1,2)^2);
%            xxx1=zhongjianV-a1*c0/a0;
%            yyy1=Rbc-a1*d0/a0;
%            if xxx1>=0
%              error=yyy1;
%            end
% 
%             c1=-(Rbc^2-error^2+B(1,1)^2+B(1,2)^2-Obc(1,1)^2-Obc(1,2)^2)/2;
%             d1=(flag2*Rbc-error);
%             r=(a0*c1-a1*c0)/(a0*d1-a1*d0);
% 
% 
%           %% return;
%        end

            a3=-1*b0/a0;
            b3=(d0*r(1)-c0)/a0;
            %a3=-1*b2/a2;
            %b3=-1*c2/a2;
            %%%% x=a3*y+b3���뷽��3  �ⷽ��
            %%����Բ�ķ���2 ���r��ֵ l*y^2+k*y+i=0
             l=a3^2+1;
             k=2*(a3*(b3-Obc(1,1))-Obc(1,2));
             i=(b3-Obc(1,1))^2+(Obc(1,2))^2-(r(1)+Z)^2;
         if l==0
            if k==0
                return;
            end
            y(1)=-i/k;
            y(2)=y(1);
            x(1)=a3*y1+b3;
            x(2)=a3*y2+b3;    
        else
            if k^2-4*l*i<0
                return;
            end
            y(1)=(-1*k+sqrt(k^2-4*l*i))/(2*l);
            y(2)=(-1*k-sqrt(k^2-4*l*i))/(2*l);
            x(1)=a3*y1+b3;
            x(2)=a3*y2+b3;  
         end
    end

end