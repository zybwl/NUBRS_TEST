clc;clear;
%file_name = 'NEW_FILE.NC.nc';
file_name = 'T1.NC.nc';
start_line_no = 13;
end_line_no = 22;
point_struct_array = get_nc_data(file_name,start_line_no,end_line_no);
n = size(point_struct_array,2);
filter_factor = 16;

index = 1;
for k = 1:n
    B = point_struct_array(k).U;
    C = point_struct_array(k).V;
    X = point_struct_array(k).X;
    Y = point_struct_array(k).Y;
    Z = point_struct_array(k).Z;
    
    B = B*pi/180;
    C = C*pi/180;
    a = [cos(C)*cos(B)  -sin(C)  sin(B)*cos(C);
         cos(B)*sin(C)   cos(C)  sin(B)*sin(C)   ;
         -sin(B)        0        cos(B)   ];
        
     new_para(:,index) = a\[X;Y;Z];
     if index == 1
         filter_param(:,1) = a\[X;Y;Z];
     else        
         filter_param(:,index) = ((filter_factor-1)*filter_param(:,index-1) + new_para(:,index))/filter_factor;
     end
     
     index = index + 1;
end

for k = 0:filter_factor-1
    filter_param(:,index + k) = ((filter_factor-4)*filter_param(:,index + k -1) + 4 * new_para(:,index - 1))/filter_factor;
end

x_max = max(new_para(1,:));
x_min = min(new_para(1,:));
y_max = max(new_para(2,:));
y_min = min(new_para(2,:));
z_max = max(new_para(3,:));
z_min = min(new_para(3,:));

plot3(new_para(1,:),new_para(2,:),new_para(3,:));
axis([x_min x_max y_min y_max z_min z_max]);
hold on
%plot3(filter_param(1,:),filter_param(2,:),filter_param(3,:),'r');
% 
% B = -11.030 ; 
% C = -10.790;
% B = B*pi/180;
% C = C*pi/180;
% a = [cos(C)*cos(B)  -sin(C)  sin(B)*cos(C);
%      cos(B)*sin(C)   cos(C)  sin(B)*sin(C)   ;
%      -sin(B)        0        cos(B)   ];
%  new_point = a * filter_param;
     
     











