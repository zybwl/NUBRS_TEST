clc; clear all;
Full_name = 'NEW_FILE.NC.nc';
real_start_number = 12;
end_line_number = 92;

fid= fopen(Full_name);
line_number = 0;
point = struct('X', 0.0, 'Y', 0.0,'Z',0.0,'U',0.0,'V',0.0);
point_struct_array = [];
tline = fgetl(fid);
    
while ischar(tline)
    line_number = line_number + 1  ;

    if line_number < real_start_number || line_number > end_line_number
        tline = fgetl(fid);
        continue;
    elseif line_number > end_line_number
         break;
    end

    expr = '[XYZUV]-?[0-9]+\.?[0-9]*';
    %expr = '[XYZ]-?[0-9]+.?[0-9]+';  %���ַ�ʽ����ֻҪ1�Σ�֮��ֿ�����
    %G01X0Y349.514Z239.447F10   %�㲻�ӷ�б�ܱ�ʾ����һ���ַ�   +����һ������ *����0������
    %https://blog.csdn.net/zjxiaolu/article/details/45132037
    search_result = regexp(tline,expr,'match');
    if isempty(search_result)
        tline = fgetl(fid);
        continue;
    end

    for k = 1:length(search_result)
        one_result = search_result{k};
        point.(one_result(1)) = str2double(one_result(2:end)); %��һ����ĸΪhash����key�������Ϊֵ
    end

    if line_number >= real_start_number && line_number <=end_line_number
        point_struct_array = [point_struct_array point];
    end           
    tline = fgetl(fid);
end

fclose(fid);

n = size(point_struct_array,2);

index = 1;
for k = 1:n
    B = point_struct_array(k).U;
    C = point_struct_array(k).V;
    X = point_struct_array(k).X;
    Y = point_struct_array(k).Y;
    Z = point_struct_array(k).Z;
    
    B = B*pi/180;
    C = C*pi/180;
    a = [cos(C)*cos(B)  -sin(C)  sin(B)*cos(C);
         cos(B)*sin(C)   cos(C)  sin(B)*sin(C)   ;
         -sin(B)        0        cos(B)   ];
     
     inv_a = inv(a);
     %new_para(:,index) = inv(a)*[X;Y;Z];
     
     if index == 1
         init = inv(a)*[X;Y;Z];
         new_para(:,1) = init;
     else
         new_para(:,index) = inv(a)*[X;Y;Z] - init;
     end
     
     index = index + 1;
end

new_para(:,1) = [0;0;0];
x_max = max(new_para(1,:));
x_min = min(new_para(1,:));
y_max = max(new_para(2,:));
y_min = min(new_para(2,:));
z_max = max(new_para(3,:));
z_min = min(new_para(3,:));

plot3(new_para(1,:),new_para(2,:),new_para(3,:));
axis([x_min x_max y_min y_max z_min z_max]);
hold on

%�������
for k = 1:n
    x = new_para(1,k);
    y = new_para(2,k);
    z = new_para(3,k);
    new_z = get_z(x,y,z);
    ploy_para(k,:) = [x,y,new_z];
end
plot3(ploy_para(:,1),ploy_para(:,2),ploy_para(:,3),'r');
% �����ѷ�����
% index = 1;
% for k = 2:n-1
%     vect1 = new_para(:,k) - new_para(:,1);
%     vect2 = new_para(:,n) - new_para(:,k);
%     dict_c = cross(vect1,vect2);
%     dict(:,index) = dict_c/norm(dict_c);
%     index = index + 1;
% end
% dict

% param = zeros(n,7);
% for k = 1:n
%     x = new_para(1,k);
%     y = new_para(2,k);
%     z = new_para(3,k);
%     vect = [x^2 y^2 z^2 x*y x*z y*z 1];
%     param(k,:) = vect;
% end
% A = param';
% y = 0.01 * rand(n,1);
% c = (A*A')\A* y;










