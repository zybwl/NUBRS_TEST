
function varargout = main_all(varargin)
    
    close all;
    diary('runlog.txt')
    diary on;
    
    d = struct('help',              '0'  ,  ...
               'which_area',        '1'  ,  ...
               'get_area',          '2'  ,  ...
               'get_clock_wise',    '3'  ,  ...
               'get_line_angle',    '4'  ,  ...
               'get_line_cross',    '5'  ,  ...
               'get_cicle_cross',   '6'  ,  ...
               'line_cross' ,       '7'  ,  ...
               'plot_with_movie',   '8'  ,  ...  
               'mark_fig_number',   '9'  ,  ...
               'point_number',      'a'  ,  ...
               'map_array',         'b'  ,  ...
               'circle_center',     'c'  ,  ...
               'circle_r',          'd'  ,  ...
               'circle_angle',      'e'	 ,  ...
               'three_points',      'f'  ,  ...
               'two_points' ,       'g');
           
    help_txt = char('main_all(''help'')'                                                      ,    ...
                    'main_all(''which_area'',''point_number'',3)'                             ,    ...
                    'main_all(''get_area'',''map_array'',[3,7])'                              ,    ...
                    'main_all(''get_clock_wise'',''map_array'',[3,10])'                       ,    ...
                    'main_all(''get_cicle_cross'',''circle_center'',[300,400],''circle_r'',70,''circle_angle'',[110,-220])' ,    ...
                    'main_all(''get_line_angle'',''three_points'',[0 0;2 0;4 2])' ,    ...
                    'main_all(''get_line_cross'',''two_points'',[100 0;350 600])' ,    ...
                    'main_all(''plot_with_movie'',''map_array'',[3 5]) ' );

    if nargin == 0
        disp('��ο��������ӣ����淶������ȷ�÷�');               
        help_txt
        return
    end
       
    key = varargin{1};
    if ~isfield(d, key)
        error_str = strcat(key, '�������Ϸ�');
        disp(error_str);
        help_txt
    end
    index_str = d.(key); 
    value = [];
    for i = 2:2:nargin
        key = varargin{i};
        if isfield(d, key)          
            index_str = strcat(index_str, d.(key));
            value = [value varargin{i + 1}];
        else 
            error_str = strcat(key, '�������Ϸ�');
            disp(error_str);
            return
        end
    end
  
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %%%%%%%%%%%       ��ʼ�������ַ�֧         %%%%%%%%%%%%%%%%%%%%%%%%
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    load map_data
    switch index_str
        case '0'  
            disp('��ο��������ӣ����淶������ȷ�÷�'); 
            help_txt
        case '1a'         
            %%���鿴ĳ�������ĸ�����,ͼ����Ҫ��󻯺��ٵ�   
            if isnumeric(value) && length(value) == 1
                for i = 1:length(map_array)
                    plot(map_array(i).x ,map_array(i).y);
                    hold on
                end
                [x , y]=ginput(value);
            else
                error_str = strcat(num2str(value), 'value�������ȱ���Ϊ1����Ϊ����');
                disp(error_str);
                return
            end

            cloth_index = 0;
            cloth_index_array = [];

            for i = 1:length(x)
                choose_point.x = x(i);
                choose_point.y = y(i);
                for j = 1:length(map_array);  
                    result = isPolygonContainsPoint(map_array(j), choose_point);
                    if result == 1
                         cloth_index_array = [cloth_index_array j];
                    end
                end
            end
            varargout = {cloth_index_array};
            
        case {'2b','3b'}
            %�������ͼԪ���            
             if isnumeric(value) && ~isempty(value)
                area = zeros(1,length(value));
                clock_wise = zeros(1,length(value));
                for i = 1:length(value);  
                    area(i) = countPolygonArea(map_array(i));
                    clock_wise(i) = area(i) > 0;
                end
                if strcmp(index_str,'2b')
                     varargout{1} = {area};
                else
                     varargout{1} = {clock_wise};
                end
            else
                error_str = strcat(num2str(value), '�������ͼԪ˳��ʱ���������Ϊ�����б�');
                disp(error_str);
                return
             end
        case '8b' 
            %�������ͼԪ���            
             if isnumeric(value) && ~isempty(value)
                  for i = 1:length(value)  
                    plotFigureInmMovie(map_array(i));
                  end 
            else
                error_str = strcat(num2str(value), '��̬��ͼ��������Ϊ�����б�');
                disp(error_str);
                return
             end
        case '6cde' 
            %%%
            % ˵���� 
            % Բ���ĽǶȲҪ����360��
            % Բ���ķ�Χ��Ҫ��-360 --- 360 ֮��
            %%%
            circle.r = value(3);
            circle.x = value(1);
            circle.y = value(2);
            circle.ang1 = value(4);
            circle.ang2 = value(5);

            abs_angle = abs(circle.ang1 - circle.ang2);
            if abs_angle >360
                 return
            end

            for i = 1:length(map_array)
                plot(map_array(i).x ,map_array(i).y);
                hold on
            end

            if circle.ang1 < circle.ang2
                ang = circle.ang1:circle.ang2;
            else
                ang = circle.ang2:circle.ang1;
            end
            circle_x = circle.x + circle.r * cos(pi*ang/180);
            circle_y = circle.y + circle.r * sin(pi*ang/180);    
            plot(circle_x,circle_y ,'r');
            hold on

            plot(circle.x,circle.y ,'*g');

            cross_point = [];
            for i = 1:length(map_array);  
               temp_cross_point  =  circleCross(map_array(i), circle);
               cross_point = [cross_point; temp_cross_point]; 
            end
            if isempty(cross_point)
               return;        
            end
             %ȥ������ĵ㣬�������������ĵ��������
            %�Ƕ���С��������
            relative_angle = [];
            if circle.ang2 > circle.ang1
                zero_vect_x =  circle.r * cos(pi*circle.ang1/180);
                zero_vect_y =  circle.r * sin(pi*circle.ang1/180);
            else
                zero_vect_x = circle.r * cos(pi*circle.ang2/180);
                zero_vect_y = circle.r * sin(pi*circle.ang2/180);
            end

            for i = 1:length(cross_point(:,1))
                new_coodinate_x = cross_point(i,1) - circle.x;
                new_coodinate_y = cross_point(i,2) - circle.y; 

                new_x = (new_coodinate_x * zero_vect_x + new_coodinate_y * zero_vect_y);
                new_y = (new_coodinate_y * zero_vect_x - new_coodinate_x * zero_vect_y);
                costheta = acos(new_x / sqrt(new_x^2 + new_y^2))*180/pi;
                if new_y < 0
                    costheta = 360 - costheta;
                end

                if costheta <= abs_angle
                    relative_angle = [relative_angle , costheta];
                end
            end

            angle = sort(relative_angle) ;
            if circle.ang2 < circle.ang1
                %angle = fliplr(angle) ;
                %�ǶȰ���С��������
                angle = angle(end:-1:1) + circle.ang2;
            else
                angle = angle + circle.ang1;
            end

            for i = 1:length(angle)
                circle_x = circle.x + circle.r * cos(pi*angle(i)/180);
                circle_y = circle.y + circle.r * sin(pi*angle(i)/180);    
                plot(circle_x,circle_y ,'*r');
                hold on
                pause(1)
            end
            %axis equal 
            
        case '4f'
            %������������ߵļн�
            value_size = size(value);
            flag = value_size - [3,2];
            if flag*flag' == 0
                point1.x = value(1,1);
                point1.y = value(1,2);
                point2.x = value(2,1);
                point2.y = value(2,2);
                point3.x = value(3,1);
                point3.y = value(3,2);
                angle = twoLineAngle(point1, point2, point3);
                varargout{1} = {angle};
            else
                error_str = strcat('������Ҫ��֤3*2 �ĸ�ʽ �� ʵ�ʸ�ʽ��' , num2str(value_size));
                disp(error_str);
            end
            
        case '5g'
            % % �жϹ���
            
            value_size = size(value);
            flag = value_size - [2,2];
            if flag*flag' == 0
                point_a.x = value(1,1);
                point_a.y = value(1,2);
                point_b.x = value(2,1);
                point_b.y = value(2,2);
            else
                error_str = strcat('������Ҫ��֤2*2 �ĸ�ʽ �� ʵ�ʸ�ʽ��' , num2str(value_size));
                disp(error_str);
                return
            end

            cross_lamda = [];
            for i = 1:length(map_array);  
               temp_lamda  =  lineCross(map_array(i), point_a, point_b);
               cross_lamda = [cross_lamda; temp_lamda]; 
            end
            % ���Ϊ�վͲ���Ҫ������
            if isempty(cross_lamda)
               return;        
            end

            %���Ȱ���С��������
            lamda = sort(cross_lamda) ;

            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %���¶��Ǵ�ӡͼ�񣬿��Բ���
            for i = 1:length(map_array)
                plot(map_array(i).x ,map_array(i).y);
                hold on
            end
            plot([point_a.x point_b.x],[point_a.y point_b.y]);
            hold on
            for i = 1:length(lamda)
                x = point_a.x + lamda(i)*(point_b.x - point_a.x);
                y = point_a.y + lamda(i)*(point_b.y - point_a.y);
                plot( x ,y ,'*r');
                hold on
                pause(1)
            end

        otherwise  
                error_str = strcat('���벻����Ҫ��:  ' ,  index_str);
                disp(error_str);
     end

    diary off;
    

    