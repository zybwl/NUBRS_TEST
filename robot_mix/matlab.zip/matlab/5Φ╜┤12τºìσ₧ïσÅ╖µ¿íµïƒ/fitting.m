function  [new_point,controls_points] = fitting(points, num_cpts, ploy_n)

num_dpts = size(points,1);

%�ο����е�9.5-9.6ʽ��use_centripetal���������ҳ����������������Ĳ���������ڵ�ʸ��
use_centripetal = false;
uk = compute_params_curve(points, use_centripetal);

%������51�����ݣ�������30��������Ͽ��Ƶ�
degree = 4;
%num_cpts = 100;
kv = compute_knot_vector2(degree, num_dpts, num_cpts, uk);

%Compute matrix N
n0p = zeros(1,num_dpts - 2);
nnp = zeros(1,num_dpts - 2);
matrix_n = [];
for i = 2 : num_dpts - 1   
    m_temp = zeros(1, num_cpts - 2);
    span = findspan(num_cpts -1 , degree , uk(i) ,kv ); 
    N  = basisfun( span , uk(i) ,degree ,kv );
    for j = span - degree: span
        if j == 0
            n0p(i - 1) = N(1);
        elseif j == num_cpts - 1
            nnp(i - 1) = N(end);
        else
            m_temp(j) = N(j - span + degree + 1);       
        end                 
    end
    matrix_n = [matrix_n ; m_temp];   
end

% Compute NT
matrix_nt = matrix_n';
% Compute NTN matrix
matrix_ntn = matrix_nt * matrix_n;
% LU-factorization
[matrix_l, matrix_u ] = lu_decomposition(matrix_ntn);

pt0 = points(1,:);
ptm = points(end,:);
[m,n] = size(points);
rk = zeros(m - 2 ,n);
for i = 2: (num_dpts - 1)
    ptk = points(i,:);   
    ptk = ptk - n0p(i - 1) * pt0 - nnp(i -1) * ptm;
    rk(i - 1,:) = ptk;
end

vector_r = matrix_nt * rk;

controls_points = zeros(num_cpts , n);
controls_points(1,:) = pt0 ;
controls_points(end,:) = ptm ;
for i = 1:n
    b = vector_r(:,i);
    y = forward_substitution(matrix_l, b);
    x = backward_substitution(matrix_u, y);
    controls_points(2:(num_cpts-1) ,i) = x;
end
%plot3(controls_points(:,1), controls_points(:,2),controls_points(:,3),'.r');
% hold on

%�ҳ���������λ�ã�����ǳ���
% error = matrix_n * controls_points(2:end - 1,:) - rk ;
% error_l = sqrt(error(:,1).^2 + error(:,2).^2 + error(:,3).^2);
% max(error_l)

% id=find(error_l==max(error_l));
for id = 1:(num_dpts - 2)
    span = findspan(num_cpts -1 , degree , uk(id + 1) ,kv );
    N  = basisfun( span , uk(id + 1) ,degree ,kv );
%     max_error_point = N * controls_points(span - degree + 1 : span + 1 , :);
%     plot3( [max_error_point(1)  points(id + 1,1)], [max_error_point(2)  points(id + 1,2)],[max_error_point(3)  points(id + 1,3)], 'r');
end

index = 1;
%ploy_n = 500;
for u = 0:1/ploy_n:1
    span = findspan(num_cpts -1 , degree , u ,kv );
    N  = basisfun( span , u ,degree ,kv );
    new_point(index,:) = N * controls_points(span - degree + 1 : span + 1 , :);
    index = index + 1;
end
% plot3(new_point(:,1),new_point(:,2),new_point(:,3),'-k'); 
% axis equal
