x = 1:10;
y = 3*x + 5 + 6*(rand(size(x)) - 0.5);
plot(x,y,'r.')
hold on

A=[x;ones(size(x))];
params = (A*A')\A*y';
new_y = params(1) * x + params(2);
plot(x,new_y);
