function [Ot radius pnt_start pnt_end]=Solvecircleline22(A,B,C,Oab,error,circle_clockwise)
 %%%%
Ot=[];
%%BC����
 VectorCB=B(1,:)-C(1,:);
 D=norm(VectorCB);
 
 %%B������������
 Rab=norm(B(1,:)-Oab(1,:));
 Vector_oabB=(B-Oab)/ Rab; 
 if circle_clockwise==1 %%1Ϊ˳ʱ�룬0Ϊ��ʱ�� 
     Vectorplane=[0,0,-1];
 else
     Vectorplane=[0,0,1];
 end
  %%��˼���  ע����˳�򣬲�˽�����Ҫ�����
 Vector_tanB=[ Vector_oabB(3)*Vectorplane(2)- Vector_oabB(2)*Vectorplane(3),-(Vector_oabB(3)*Vectorplane(1)-Vector_oabB(1)*Vectorplane(3)),Vector_oabB(2)*Vectorplane(1)-Vector_oabB(1)*Vectorplane(2)];
 Vector_tanB=Vector_tanB/norm(Vector_tanB(1,:));
%%%%

%%%%����CB��OabB�ļн��ж��ڽӺ�����
cos_theat=(VectorCB(1)*Vector_oabB(1)+VectorCB(2)*Vector_oabB(2)+VectorCB(3)*Vector_oabB(3))/D/Rab;
theta=acos(cos_theat);
%%%%��Բ�ľ�dO2O
   % if theta>=pi/2
   %     dO2O=Rbc+r;
   % else   %%theta<pi/2
   %     dO2O=Rbc-r;
   %  end
%%%%%%%%%%%%

%%��һ������  �����ж�Բ�ķ���
%%%|(y2-y3)x-��x2-x3��y+(x2y3-x3y2)|=r1*d;
%%��B+Vector_tanB���������õ�
P=B-Vector_tanB;
Pflag=P(1,1)*(B(1,2)-C(1,2))-P(1,2)*(B(1,1)-C(1,1))+C(1,2)*B(1,1)-C(1,1)*B(1,2);
%%%��㵽ֱ�߾���
Pflag1=Oab(1,1)*(B(1,2)-C(1,2))-Oab(1,2)*(B(1,1)-C(1,1))+C(1,2)*B(1,1)-C(1,1)*B(1,2);
lotoline=abs(Pflag1)/D;

if Pflag>0
    flag=1;
elseif Pflag<0
        flag=-1;
else
        flag=0;
        if (Vector_tanB(1,1)*VectorCB(1,1)>0)||(Vector_tanB(1,2)*VectorCB(1,2)>0)||(Vector_tanB(1,3)*VectorCB(1,3)>0)
               
                if Pflag1>0
                     flag=1;
                else 
                    flag=-1;
                end
        else
            return ;   %%%%%����Ҫת�ӣ����У�˳�� 
        end    
end

%%%%%%�ⷽ����
if theta>=pi/2
    flag2=1; 
    %%%%%%����жϹ���%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%�����ж�����  %%%%%%%%%%%%%%%%%%%%%
     %Pflag1=Oab(1,1)*(B(1,2)-C(1,2))-Oab(1,2)*(B(1,1)-C(1,1))+C(1,2)*B(1,1)-C(1,1)*B(1,2);
     %lotoline=abs(Pflag1)/D;
     if Pflag1>0
         flag3=1;
     elseif Pflag1<0
         flag3=-1;
     else
         flag3=0;
     end
     
     lgonggao=Rab+flag3*flag*lotoline;  %%%%%%%�Ż����ӻ� �жϱ�־
else
    flag2=-1;
    %%%%%%�ڽ��ж� �ҳ�%%%%%%%%%%%%%%%%%%%%%%
    %Pflag1=Oab(1,1)*(B(1,2)-C(1,2))-Oab(1,2)*(B(1,1)-C(1,1))+C(1,2)*B(1,1)-C(1,1)*B(1,2);
    % lotoline=abs(Pflag1)/D;
     if Pflag1>0
         flag3=1;
     elseif Pflag1<0
         flag3=-1;
     else
         flag3=0;
     end     
     lgonggao=Rab+flag3*flag*lotoline;  %%%%%%%�Ż����ӻ� �жϱ�־
     xianhalfsq=Rab^2-lotoline^2;
     %���ߵ�һ����ҳ���һ�� ��ƽ���� ��Ȼ���ȥ���ߵ�һ�� ��Ϊת�����
     lgonggao=sqrt(xianhalfsq+lgonggao^2/4)-lgonggao/2;
end
   %%%%%�ж����
   if error>=lgonggao  %%%���ڵ��ڰ�������!!!!!ע��
    error=lgonggao/2;%%%%%%%%%�����ڹ��ߡ��ҳ���ʱ���趨���ߡ��ҳ�һ���������
   end
   
   
%%%%%%(y2-y3)x+��x3-x2)y+(x2y3-x3y2)=r*D*flag;
%%%%%%(x-Oab(1,1))^2+(y-Oab(1,2))^2=(flag2*Rab+r)^2
%%%%%%(x-x2)^2+(y-y2)^2=(r+error)^2;  ����ax +by +c=dr
a1=(B(1,1)-Oab(1,1));
b1=(B(1,2)-Oab(1,2));
c1=-(Rab^2-error^2+B(1,1)^2+B(1,2)^2-Oab(1,1)^2-Oab(1,2)^2)/2;
d1=(flag2*Rab-error);


a0=(B(1,2)-C(1,2));
b0=(C(1,1)-B(1,1));
c0=(C(1,2)*B(1,1)-C(1,1)*B(1,2));
d0=D*flag;

W=B;
Z=error;

%%%�Ƚⷽ��  a0*x+b0*y+c0=d0*r
%%%�Ƚⷽ��  a0*x+b0*y+c0=d0*r
%%%%%%%%%%%%a1*x+b1*y+c1=d1*r
[x y r]=solvefunction(a0,b0,c0,d0,a1,b1,c1,d1,W,Z)
 
%%%%%%ȡ��ֵr;
    if r(1)<=0&&r(2)>0
        radius=r(2);
        %%%%%%%%%%
        Ot(1)=x(2);
        Ot(2)=y(2);
    elseif r(1)>0&&r(2)<=0
        radius=r(1);
         %%%%%%%%%%
        Ot(1)=x(1);
        Ot(2)=y(1);
    elseif r(1)>0&&r(2)>0
       
         %%%%ֱ��Oab��B����Ϊ
        P1=B-Vector_tanB;
        Pflag=P1(1)*(B(1,2)-Oab(1,2))-P1(2)*(B(1,1)-Oab(1,1))+Oab(1,2)*B(1,1)-Oab(1,1)*B(1,2);
        Pflag11=x(1)*(B(1,2)-Oab(1,2))-y(1)*(B(1,1)-Oab(1,1))+Oab(1,2)*B(1,1)-Oab(1,1)*B(1,2);
        Pflag12=x(2)*(B(1,2)-Oab(1,2))-y(2)*(B(1,1)-Oab(1,1))+Oab(1,2)*B(1,1)-Oab(1,1)*B(1,2);
       if Pflag*Pflag11>0
           radius=r(1);
           Ot(1)=x(1);
           Ot(2)=y(1);
       else
           radius=r(2);
           Ot(1)=x(2);
           Ot(2)=y(2);
       end
    else
        return;
    end

 
   %%%%%%%���е��Բ�Ľ�
   Ot(3)=0;
    pnt_start=[];
    pnt_end=[];
    %Բ���յ�����
    %%BC����
    length_BSlu = norm(Ot(1,:)-B(1,:));
    length_intercept = sqrt(length_BSlu*length_BSlu - radius*radius);
    length_CB = norm(C(1,:)-B(1,:));

    lamda = length_intercept / length_CB;
    pnt_end(1) = (1-lamda)*B(1) + lamda*C(1);
    pnt_end(2) = (1-lamda)*B(2) + lamda*C(2);   
   
     %%//Բ���������
    OOab=norm(Ot(1,:)-Oab(1,:));
    lamda = Rab / OOab;
    pnt_start(1) = (1-lamda)*Oab(1) + lamda*Ot(1);
    pnt_start(2) = (1-lamda)*Oab(2) + lamda*Ot(2);
    pnt_start(3) = (1-lamda)*Oab(3) + lamda*Ot(3);

    %%%%%%%�ж� �е������Ƿ����߶�AB��Բ��ǰ1/2��
    if length_intercept > length_CB/2  %%%�е㲻���߶�CBǰ1/2������
       tag2=0;     
    else
       tag2=1;
    end
    
     %%Բ�Ľ��ж�  
   %%%%%��Բ�Ľ�
       vec_start(1)= A(1)-Oab(1);
       vec_start(2)= A(2)-Oab(2);
       vec_start(3)= A(3)-Oab(3);
       norm_start=norm(vec_start);
       vec_start(1)=vec_start(1)/ norm_start;
       vec_start(2)=vec_start(2)/norm_start;
       vec_start(3)=vec_start(3)/ norm_start;
       vec_end(1)= B(1)-Oab(1);
       vec_end(2)= B(2)-Oab(2); 
       vec_end(3)= B(3)-Oab(3); 
       norm_end=norm(vec_end);
       vec_end(1)= vec_end(1)/ norm_end;
       vec_end(2)= vec_end(2)/ norm_end;
       vec_end(3)= vec_end(3)/ norm_end;
   %%%%%%%
       Crossprod(1)= vec_start(2)*vec_end(3)-vec_start(3)*vec_end(2);
       Crossprod(2)= -vec_start(1)*vec_end(3)+vec_start(3)*vec_end(1);
       Crossprod(3)= vec_start(1)*vec_end(2)-vec_start(2)*vec_end(1); 
       sum=Crossprod(1)+Crossprod(2)+Crossprod(3);
       %%%%�нǶ���  0~180
       dot=vec_start(1)*vec_end(1)+vec_start(2)*vec_end(2)
       theta=acos(dot);
       if sum==0
           if dot>0
               res=0;
           else
               res=pi;
           end
       elseif sum>0
           if circle_clockwise==0
               res=theta;
           else
               res=2*pi-theta;
           end
       elseif sum<0
           if circle_clockwise==1
               res=theta;
           else
               res=2*pi-theta;
           end
       end
      %%%%%%%%%%%%%%%%%%%%%%%%
       %%Բ�Ľ��ж�  
   %%%%%��Բ�Ľ�
       vec_start(1)= pnt_start(1)-Oab(1);
       vec_start(2)= pnt_start(2)-Oab(2);
       vec_start(3)= pnt_start(3)-Oab(3);
       norm_start=norm(vec_start);
       vec_start(1)=vec_start(1)/ norm_start;
       vec_start(2)=vec_start(2)/norm_start;
       vec_start(3)=vec_start(3)/ norm_start;
       vec_end(1)= B(1)-Oab(1);
       vec_end(2)= B(2)-Oab(2); 
       vec_end(3)= B(3)-Oab(3); 
       norm_end=norm(vec_end);
       vec_end(1)= vec_end(1)/ norm_end;
       vec_end(2)= vec_end(2)/ norm_end;
       vec_end(3)= vec_end(3)/ norm_end;
   %%%%%%%
       Crossprod(1)= vec_start(2)*vec_end(3)-vec_start(3)*vec_end(2);
       Crossprod(2)= -vec_start(1)*vec_end(3)+vec_start(3)*vec_end(1);
       Crossprod(3)= vec_start(1)*vec_end(2)-vec_start(2)*vec_end(1); 
       sum=Crossprod(1)+Crossprod(2)+Crossprod(3);
       %%%%�нǶ���  0~180
       dot=vec_start(1)*vec_end(1)+vec_start(2)*vec_end(2)
       theta=acos(dot);
       if sum==0
           if dot>0
               res1=0;
           else
               res1=pi;
           end
       elseif sum>0
           if circle_clockwise==0
               res1=theta;
           else
               res1=2*pi-theta;
           end
       elseif sum<0
           if circle_clockwise==1
               res1=theta;
           else
               res1=2*pi-theta;
           end
       end
      %%%%%%%%%%%%%%%%%%%%%%%%
       %%%%%%% �Ƕ�res1  res1/2 ; 
      
      if res1<=res
          tag1=1;%%%%��Բ��
      else
          tag1=0;
      end
        if tag1*tag2==0
         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         if tag1==0 && tag2~=0
         %%%%%%���2 ����Բ��,��ֱ��ǰ1/2��  �̶�A��
         %%(x-x1)��Oaby-y1��-��y-y1��(Oabx-x1)=0;     (1)
         %%(y2-y3)x-��x2-x3��y+(x2y3-x3y2)=flag*r*d;     (2)
         %%(x-Oabx)^2+(y-Oaby)^2=(r+flag2*Rab)^2;          (3)
 
        a1=(B(1,2)-C(1,2));
        b1=(C(1,1)-B(1,1));
        c1=(C(1,2)*B(1,1)-C(1,1)*B(1,2));
        d1=D*flag;

        a0=(Oab(1,2)-A(1,2));
        b0=-1*(Oab(1,1)-A(1,1));
        c0=-1*A(1,1)*Oab(1,2)+-A(1,2)*Oab(1,1);
        d0=0;
        W=Oab;
        Z=flag2*Rab;
        [x y r]=solvefunction(a0,b0,c0,d0,a1,b1,c1,d1,W,Z) 
                   %%%%%%ȡ��ֵr;
            if r(1)<=0&&r(2)>0
                radius=r(2);
                %%%%%%%%%%
                Ot(1)=x(2);
                Ot(2)=y(2);
            elseif r(1)>0&&r(2)<=0
                radius=r(1);
                 %%%%%%%%%%
                Ot(1)=x(1);
                Ot(2)=y(1);
            elseif r(1)>0&&r(2)>0

                  %%%%ֱ��Oab��B����Ϊ
                 P1=B-Vector_tanB;
                 Pflag=P1(1)*(B(1,2)-Oab(1,2))-P1(2)*(B(1,1)-Oab(1,1))+Oab(1,2)*B(1,1)-Oab(1,1)*B(1,2);
                 Pflag11=x(1)*(B(1,2)-Oab(1,2))-y(1)*(B(1,1)-Oab(1,1))+Oab(1,2)*B(1,1)-Oab(1,1)*B(1,2);
                 Pflag12=x(2)*(B(1,2)-Oab(1,2))-y(2)*(B(1,1)-Oab(1,1))+Oab(1,2)*B(1,1)-Oab(1,1)*B(1,2);
                 if Pflag*Pflag1>0
                    radius=r(1);
                    Ot(1)=x(1);
                    Ot(2)=y(1);
                 else
                     radius=r(2);
                     Ot(1)=x(2);
                     Ot(2)=y(2);
                  end
            else
                return;
            end
            %Բ���������
            pnt_start=A;
            pnt_end=[];
            %Բ���յ�����
            length_BSlu = norm(Ot(1,:)-B(1,:));
            length_intercept = sqrt(length_BSlu*length_BSlu - radius*radius);
            %length_CB = norm(C(1,:)-B(1,:));

            lamda = length_intercept / length_CB;
            pnt_end(1) = (1-lamda)*B(1) + lamda*C(1);
            pnt_end(2) = (1-lamda)*B(2) + lamda*C(2);     
            
            
         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
         elseif tag1~=0 && tag2==0
         %%%%%  ��Բ����  ����ֱ��ǰ1/2����  �̶�1/2 BC  �е�middle
         %%%%%%���3 
         middle=[];
         middle(1)=0.5*(B(1,1)+C(1,1));
         middle(2)=0.5*(B(1,2)+C(1,2));
         
         %%(x-middle(1))��x2-middle(1)��+��y-middle(2)��(y2-middle(2))=0;(1)
         %%(y2-y3)x-��x2-x3��y+(x2y3-x3y2)=flag*r*d;   (2)
         %%(x-Oabx)^2+(y-Oaby)^2=(r+flag2*Rab)^2;          (3)
         
        a1=(B(1,2)-C(1,2));
        b1=(C(1,1)-B(1,1));
        c1=(C(1,2)*B(1,1)-C(1,1)*B(1,2));
        d1=D*flag;

        a0=(B(1,1)-middle(1));
        b0=(B(1,2)-middle(2));
        c0=middle(1)*(middle(1)-B(1,1))+middle(2)*(middle(2)-B(1,2));
        d0=0;
        
        W=Oab;
        Z=flag2*Rab;
        %%%%%%%%%
        [x y r]=solvefunction(a0,b0,c0,d0,a1,b1,c1,d1,W,Z) 
            
            %%%%%%ȡ��ֵr;
            if r(1)<=0&&r(2)>0
                radius=r(2);
                %%%%%%%%%%
                Ot(1)=x(2);
                Ot(2)=y(2);
            elseif r(1)>0&&r(2)<=0
                radius=r(1);
                 %%%%%%%%%%
                Ot(1)=x(1);
                Ot(2)=y(1);
            elseif r(1)>0&&r(2)>0

                 %%%%ֱ��Oab��B����Ϊ
                P1=B-Vector_tanB;
                Pflag=P1(1)*(B(1,2)-Oab(1,2))-P1(2)*(B(1,1)-Oab(1,1))+Oab(1,2)*B(1,1)-Oab(1,1)*B(1,2);
                Pflag11=x(1)*(B(1,2)-Oab(1,2))-y(1)*(B(1,1)-Oab(1,1))+Oab(1,2)*B(1,1)-Oab(1,1)*B(1,2);
                Pflag12=x(2)*(B(1,2)-Oab(1,2))-y(2)*(B(1,1)-Oab(1,1))+Oab(1,2)*B(1,1)-Oab(1,1)*B(1,2);
               if Pflag*Pflag11>0
                   radius=r(1);
                   Ot(1)=x(1);
                   Ot(2)=y(1);
               else
                   radius=r(2);
                   Ot(1)=x(2);
                   Ot(2)=y(2);
               end
            else
                return;
            end
            %Բ���������
            pnt_start=[];
            pnt_end=middle;
            %%//Բ���������
            OOab=norm(Ot(1,:)-Oab(1,:));
            lamda = Rab / OOab;
            pnt_start(1) = (1-lamda)*Oab(1) + lamda*Ot(1);
            pnt_start(2) = (1-lamda)*Oab(2) + lamda*Ot(2);
            pnt_start(3) = (1-lamda)*Oab(3) + lamda*Ot(3);
         
         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         else  tag1==0 && tag2==0
         %%%%%%���4 ����ǰ1/2Բ��,����ֱ���� 
        
         %1 %%%%%BC�е�����
          %%%%%%���3 
         middle=[];
         middle(1)=0.5*(B(1,1)+C(1,1));
         middle(2)=0.5*(B(1,2)+C(1,2));
         middle(3)=0;
         %%%%%%% �󽻵㣬Բ�ġ�A ֱ�ߺ͹� middle�㴹ֱBCֱ��  crossoverPoint  
         %%%%%%%%(x-x1)��Oaby-y1��-��y-y1��(Oabx-x1)=0;   (1)
         %%(x-middle(1))��x2-middle(1)��+��y-middle(2)��(y2-middle(2))=0;(2)
         crossoverPoint=[];
         a1=(B(1,1)-middle(1));
         b1=(B(1,2)-middle(2));
         c1=middle(1)*(middle(1)-B(1,1))+middle(2)*(middle(2)-B(1,2));
        
        a0=(Oab(1,2)-A(1,2));
        b0=-1*(Oab(1,1)-A(1,1));
        c0=-1*A(1,1)*Oab(1,2)+-A(1,2)*Oab(1,1);
         
          if a0*b1-a1*b0==0
              return;
          end
           crossoverPoint(2)=-1*(a1*c0-a0*c1)/(a1*b0-a0*b1);
          if a0~=0
           crossoverPoint(1)=-1*(b0*crossoverPoint(2)+c0)/a0;
          elseif a1~=0
           crossoverPoint(1)=-1*(b1*crossoverPoint(2)+c1)/a1;  
          else
              return;
          end
           crossoverPoint(3)=0;
         %%%%%%%%%%%%%%%%%%%�����������  crossoverPoint  �ж�crossoverPoint-A���Ⱥ�crossoverPoint-middle����
         ll1=norm(crossoverPoint-A);
         ll2=norm(crossoverPoint-middle);
         if ll1>ll2
            %%%%%%���2 ����Բ��,��ֱ��ǰ1/2��  �̶�A��
                     %%(x-x1)��Oaby-y1��-��y-y1��(Oabx-x1)=0;     (1)
                     %%(y2-y3)x-��x2-x3��y+(x2y3-x3y2)=flag*r*d;     (2)
                     %%(x-Oabx)^2+(y-Oaby)^2=(r+flag2*Rab)^2;          (3)

                    a1=(B(1,2)-C(1,2));
                    b1=(C(1,1)-B(1,1));
                    c1=(C(1,2)*B(1,1)-C(1,1)*B(1,2));
                    d1=D*flag;

                    a0=(Oab(1,2)-A(1,2));
                    b0=-1*(Oab(1,1)-A(1,1));
                    c0=-1*A(1,1)*Oab(1,2)+-A(1,2)*Oab(1,1);
                    d0=0;
                    W=Oab;
                    Z=flag2*Rab;
                    [x y r]=solvefunction(a0,b0,c0,d0,a1,b1,c1,d1,W,Z) 
                               %%%%%%ȡ��ֵr;
                        if r(1)<=0&&r(2)>0
                            radius=r(2);
                            %%%%%%%%%%
                            Ot(1)=x(2);
                            Ot(2)=y(2);
                        elseif r(1)>0&&r(2)<=0
                            radius=r(1);
                             %%%%%%%%%%
                            Ot(1)=x(1);
                            Ot(2)=y(1);
                        elseif r(1)>0&&r(2)>0

                              %%%%ֱ��Oab��B����Ϊ
                             P1=B-Vector_tanB;
                             Pflag=P1(1)*(B(1,2)-Oab(1,2))-P1(2)*(B(1,1)-Oab(1,1))+Oab(1,2)*B(1,1)-Oab(1,1)*B(1,2);
                             Pflag11=x(1)*(B(1,2)-Oab(1,2))-y(1)*(B(1,1)-Oab(1,1))+Oab(1,2)*B(1,1)-Oab(1,1)*B(1,2);
                             Pflag12=x(2)*(B(1,2)-Oab(1,2))-y(2)*(B(1,1)-Oab(1,1))+Oab(1,2)*B(1,1)-Oab(1,1)*B(1,2);
                             if Pflag*Pflag11>0
                                radius=r(1);
                                Ot(1)=x(1);
                                Ot(2)=y(1);
                             else
                                 radius=r(2);
                                 Ot(1)=x(2);
                                 Ot(2)=y(2);
                              end
                        else
                            return;
                        end
                        %Բ���������
                        pnt_start=A;
                        pnt_end=[];
                        %Բ���յ�����
                        length_BSlu = norm(Ot(1,:)-B(1,:));
                        length_intercept = sqrt(length_BSlu*length_BSlu - radius*radius);
                        %length_CB = norm(C(1,:)-B(1,:));

                        lamda = length_intercept / length_CB;
                        pnt_end(1) = (1-lamda)*B(1) + lamda*C(1);
                        pnt_end(2) = (1-lamda)*B(2) + lamda*C(2);    
             
             
             
         else
                          %%%%%  ��Բ����  ����ֱ��ǰ1/2����  �̶�1/2 BC  �е�middle
                         %%(x-middle(1))��x2-middle(1)��+��y-middle(2)��(y2-middle(2))=0;(1)
                         %%(y2-y3)x-��x2-x3��y+(x2y3-x3y2)=flag*r*d;   (2)
                         %%(x-Oabx)^2+(y-Oaby)^2=(r+flag2*Rab)^2;          (3)

                        a1=(B(1,2)-C(1,2));
                        b1=(C(1,1)-B(1,1));
                        c1=(C(1,2)*B(1,1)-C(1,1)*B(1,2));
                        d1=D*flag;

                        a0=(B(1,1)-middle(1));
                        b0=(B(1,2)-middle(2));
                        c0=middle(1)*(middle(1)-B(1,1))+middle(2)*(middle(2)-B(1,2));
                        d0=0;

                        W=Oab;
                        Z=flag2*Rab;
                        %%%%%%%%%
                        [x y r]=solvefunction(a0,b0,c0,d0,a1,b1,c1,d1,W,Z) 

                            %%%%%%ȡ��ֵr;
                            if r(1)<=0&&r(2)>0
                                radius=r(2);
                                %%%%%%%%%%
                                Ot(1)=x(2);
                                Ot(2)=y(2);
                            elseif r(1)>0&&r(2)<=0
                                radius=r(1);
                                 %%%%%%%%%%
                                Ot(1)=x(1);
                                Ot(2)=y(1);
                            elseif r(1)>0&&r(2)>0

                                 %%%%ֱ��Oab��B����Ϊ
                                P1=B-Vector_tanB;
                                Pflag=P1(1)*(B(1,2)-Oab(1,2))-P1(2)*(B(1,1)-Oab(1,1))+Oab(1,2)*B(1,1)-Oab(1,1)*B(1,2);
                                 Pflag11=x(1)*(B(1,2)-Oab(1,2))-y(1)*(B(1,1)-Oab(1,1))+Oab(1,2)*B(1,1)-Oab(1,1)*B(1,2);
                                 Pflag12=x(2)*(B(1,2)-Oab(1,2))-y(2)*(B(1,1)-Oab(1,1))+Oab(1,2)*B(1,1)-Oab(1,1)*B(1,2);
                               if Pflag*Pflag11>0
                                   radius=r(1);
                                   Ot(1)=x(1);
                                   Ot(2)=y(1);
                               else
                                   radius=r(2);
                                   Ot(1)=x(2);
                                   Ot(2)=y(2);
                               end
                            else
                                return;
                            end
                            %Բ���������
                            pnt_start=[];
                            pnt_end=middle;
                            %%//Բ���������
                            OOab=norm(Ot(1,:)-Oab(1,:));
                            lamda = Rab / OOab;
                            pnt_start(1) = (1-lamda)*Oab(1) + lamda*Ot(1);
                            pnt_start(2) = (1-lamda)*Oab(2) + lamda*Ot(2);
                            pnt_start(3) = (1-lamda)*Oab(3) + lamda*Ot(3);         
             
             
         end       
          
        end 
         
      else 
          %%%%%���1���������������%%%%%
      end
      
      
      
end