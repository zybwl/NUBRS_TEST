%A=[0,0,0];
%B=[-10,-15,0];
%C=[10,-35,0];%%%�����ֵδ�õ�
%Obc=[-10,-35,0];
%error=10;
%circle_clockwise=1;
A=[0.11666666666666667,0.033333333333333333,0];
B=[0.15,0,0];
C=[0.2,0.05,0];%%%�����ֵδ�õ�
Obc=[0.2,0,0];
error=0.1;
circle_clockwise=1;
[Ot r startPoint endPoint]=Solvelinecircle11(A,B,C,Obc,error,circle_clockwise)

x=[A(1,1) B(1,1)];
y=[A(1,2) B(1,2)];
plot(x,y);
hold on
x0 = Ot(1), y0 = Ot(2); %ԭ��
theta=0:pi/10000:2*pi; %�Ƕ�[0,2*pi]
R=r; %�뾶
x=R*cos(theta)+x0;
y=R*sin(theta)+y0;
plot(x,y,'-r')
axis equal
hold on
x0 = Obc(1), y0 = Obc(2); %ԭ��
theta=0:pi/100000:2*pi; %�Ƕ�[0,2*pi]
R=norm(B-Obc); %�뾶
x=R*cos(theta)+x0;
y=R*sin(theta)+y0;
plot(x,y,'-')
axis equal
grid on
x0 = B(1), y0 = B(2); %ԭ��
%theta=0:pi/1000000:2*pi; %�Ƕ�[0,2*pi]
R=error; %�뾶
x=R*cos(theta)+x0;
y=R*sin(theta)+y0;
%plot(x,y,'-r')
axis equal
hold on
plot(startPoint(1),startPoint(2),'*');
hold on
plot(endPoint(1),endPoint(2),'*');