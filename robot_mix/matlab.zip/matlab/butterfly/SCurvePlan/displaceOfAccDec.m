function Sparam = displaceOfAccDec(Amax,Dec,Jamax,Jdmax,F,vs,ve)
% �滮���ٽ׶κͼ��ٽ׶Σ�����������λ��
% �����ٶȺ������ٶȲ�ͬ
Sparam = initSparam;

six_d_Jamax = (1/6)*Jamax;
six_d_Jdmax = (1/6)*Jdmax;
half_Jamax = (1/2)*Jamax;
half_Jdmax = (1/2)*Jdmax;
squa_Amax = Amax^2;
squa_Dec = Dec^2;

% ���ٶ��Ƿ����ȼ���
if (abs(F-vs) > squa_Amax/Jamax)
    T(1) = Amax/Jamax;
    T(2) = abs(F-vs)/Amax - T(1);
    T(3) = T(1);
else
    T(1) = sqrt(abs(F-vs)/Jamax);
    T(2) = 0;
    T(3) = T(1);
    Amax = sqrt(abs(F-vs)*Jamax);
end

half_Amax = (1/2)*Amax;

% ÿ���׶ε�ĩ�ٶ�
v(1) = vs + half_Jamax*T(1)^2;
v(2) = v(1) + Amax*T(2);
v(3) = v(2) + half_Jamax*T(1)^2;
% ÿ���׶ε���ĩλ��
sa(1) = vs*T(1) + six_d_Jamax*T(1)^3;
sa(2) = sa(1) + v(1)*T(2) + half_Amax*T(2)^2;
sa(3) = sa(2) + v(2)*T(3) + half_Amax*T(3)^2 - six_d_Jamax*T(3)^3;
% ���ٽ׶�λ��
Sa = sa(3);
% ���ٶ��Ƿ����ȼ���
if (abs(F-ve) > squa_Dec/Jdmax)
    T(5) = Dec/Jdmax;
    T(6) = abs(F-ve)/Dec - T(5);
    T(7) = T(5);
else
    T(5) = sqrt((abs(F-ve))/Jdmax);
    T(6) = 0;
    T(7) = T(5);
    Dec = sqrt(abs(F-ve)*Jdmax);
end

half_Dec = (1/2)*Dec;

v(5) = F - half_Jdmax*T(5)^2;
v(6) = v(5) - Dec*T(6);
v(7) = v(6) - half_Jdmax*T(7)^2;
% ���ٶ�λ��
sd(1) = ve*T(7) + six_d_Jdmax*T(7)^3;
sd(2) = sd(1) + v(6)*T(6) + half_Dec*T(6)^2;
sd(3) = sd(2) + v(5)*T(5) + half_Dec*T(5)^2 - six_d_Jdmax*T(5)^3;
Sd = sd(3);

% if T(1) == 0 && T(5)~= 0
%     if Sd > S
%         if (abs(F-ve) > squa_Dec/Jmax)
%             T(5) = Dec/Jmax;
%             T(7) = T(5);
%             s_dec = S-(1/3)*Jmax*T(5)^3;
%             v1 = Dec*T(5);
%             T(6) = (sqrt(v1^2+2*Dec*s_dec) - v1)/Dec;
%             % ���¼����ٶȽڵ�
%             v(5) = F - half_Jmax*T(5)^2;
%             v(6) = v(5) - Dec*T(6);
%             v(7) = v(6) - half_Jmax*T(7)^2;
%             % ���¼�����ٶ�λ��
%             sd(1) = ve*T(7) + six_d_Jmax*T(7)^3;
%             sd(2) = sd(1) + v(6)*T(6) + half_Dec*T(6)^2;
%             sd(3) = sd(2) + v(5)*T(5) + half_Dec*T(5)^2 - six_d_Jmax*T(5)^3;
%             Sd = sd(3);
%         else
%             error('S curve plan error');
%         end
%     end
% elseif T(1)~=0 && T(5) == 0
%     if Sa > S
%         if (abs(F-vs) > squa_Amax/Jmax)
%             T(1) = Amax/Jmax;
%             T(3) = T(1);
%             s_acc = S-(1/3)*Jmax*T(1)^3;
%             v1 = Amax*T(1);
%             T(2) = (sqrt(v1^2+2*Amax*s_acc) - v1)/Amax;
%             % ���¼����ٶȽڵ�
%             v(1) = vs + half_Jmax*T(1)^2;
%             v(2) = v(1) + Amax*T(2);
%             v(3) = v(2) + half_Jmax*T(1)^2;
%             % ���¼�����ٶ�λ��
%             sa(1) = vs*T(1) + six_d_Jmax*T(1)^3;
%             sa(2) = sa(1) + v(1)*T(2) + half_Amax*T(2)^2;
%             sa(3) = sa(2) + v(2)*T(3) + half_Amax*T(3)^2 - six_d_Jmax*T(3)^3;
%             Sa = sa(3);
%         else
%             error('S curve plan error');
%         end    
%     end
% end

Sad = Sa+Sd;

Sparam.vs = vs;
Sparam.ve = ve;
Sparam.T = T;
Sparam.vknot = v;
Sparam.sknot = sa;
Sparam.Amax = Amax;
Sparam.Dec = Dec;
Sparam.Jamax = Jamax;
Sparam.Jdmax = Jdmax;
Sparam.Vmax = F;
Sparam.displacementOfAD = Sad;

    function sp = initSparam
        sp.Amax = [];
        sp.Dec = [];
        sp.Jamax = [];
        sp.Jdmax = [];
        sp.Vmax = [];
        sp.T = [];
        sp.t = [];
        sp.vknot = [];
        sp.sknot = [];
        sp.vs = [];
        sp.ve = [];
        sp.Stol = [];
    end
end