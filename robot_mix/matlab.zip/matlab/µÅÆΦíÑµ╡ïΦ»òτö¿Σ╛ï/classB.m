classdef classB<classA
    properties
        e
    end
    
    methods
        function obj = classB(structx,e)
            obj = obj@classA(structx);
            obj.e = e;
        end
    end
end