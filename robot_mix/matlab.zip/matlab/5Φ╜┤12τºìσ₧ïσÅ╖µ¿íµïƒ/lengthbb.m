clc;clear ;close all;
controls_points = [ -19    -5
   -16     0
   -12     5
    -4     6
     6     3
    10     9
    20     5
    17    -7
     6    -7
     3   -13
    -5   -11
   -13    -8
   -19    -5
   -16     0
   -12     5];

kv = -3:15;

num_cpts = 15;
degree = 3;
ploy_n = 500;
index = 1;
% for u = 0:1/ploy_n:1
%     span = findspan(num_cpts -1 , degree , u ,kv );
%     N  = basisfun( span , u ,degree ,kv );
% %     new_point(index,:) = controls_points(span + 1 : span + 2 , :) * N';
% %     index = index + 1;
% end

matrix_n = [];
for u = 0: 1/200: 12
    
    if u == 12;
        u
    end
    m_temp = zeros(1, num_cpts);
    span = findspan(14 , degree , u ,kv );
    N  = basisfun( span , u ,degree ,kv );
    m_temp(span - degree + 1: span + 1) = N;
    new_point(index,:) = N * controls_points(span - degree + 1 : span + 1 , :);
    index = index + 1;
    matrix_n = [matrix_n; m_temp];
end 

plot(new_point(:,1),new_point(:,2),'-k'); 
hold on
plot(controls_points(:,1), controls_points(:,2),'-r');




