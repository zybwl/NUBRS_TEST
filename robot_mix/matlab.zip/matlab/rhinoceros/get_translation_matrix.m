function matrix = get_translation_matrix(point)
     matrix = [1 0 0 point(1)
               0 1 0 point(2)
               0 0 1 point(3)
               0 0 0 1];