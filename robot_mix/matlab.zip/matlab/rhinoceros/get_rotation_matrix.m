function matrix = get_rotation_matrix(rot_type , angle)
    cost = cos( angle/180*pi );
    sint = sin( angle/180*pi );
    if rot_type == 1
        matrix = [1 0 0 0;0 cost -sint 0;0 sint cost 0; 0 0 0 1];
    elseif rot_type == 2
        matrix = [cost 0 sint 0;0 1 0 0;-sint 0 cost 0;0 0 0 1];
    else
        matrix = [cost -sint 0 0;sint cost 0 0;0 0 1 0;0 0 0 1];
    end