clc;clear all;
%ԭʼ����
r = 10 ;
u = [15,30,45];
v = [45,30,15];
x = sin(u) .* cos(v);
y = sin(u) .* sin(v);
z = cos(u);
points = r * [x ;y ;z];
points_for_4 = [points;ones(1,3)];

rot_a = get_rotation_matrix(1,15);
rot_b = get_rotation_matrix(2,20);
rot_c = get_rotation_matrix(3,25);
rot_matrix = rot_a * rot_b * rot_c ;
transfer_matrix = get_translation_matrix([1050,1324,2018]);
transfer_points = transfer_matrix * rot_matrix * points_for_4;
transfer_points = transfer_points(1:3,:);
result = [1050,1324,2018, rot_matrix(1,1:3),rot_matrix(2,1:3),rot_matrix(3,1:3)]';

%���ݷ���
%����1 �������3����ķ�����
pv = points(:, 2:end) - points(:,1:end-1);
tv = transfer_points(:,2:end) - transfer_points(:,1:end-1);

d_p = cross(pv(:,1) , pv(:,2));
d_p_l = norm(d_p);
new_org_one = points(:,1) + d_p/d_p_l ;
d_t = cross(tv(:,1) , tv(:,2));
d_t_l = norm(d_t);
new_rot_one = transfer_points(:,1) + d_t/d_t_l ;

origin_points = [points, new_org_one];
rot_points = [transfer_points, new_rot_one];

a_4_12 = [1 0 0 origin_points(:,1)' zeros(1,6)
          1 0 0 origin_points(:,2)' zeros(1,6)
          1 0 0 origin_points(:,3)' zeros(1,6)
          1 0 0 origin_points(:,4)' zeros(1,6)
          0 1 0 zeros(1,3) origin_points(:,1)' zeros(1,3)
          0 1 0 zeros(1,3) origin_points(:,2)' zeros(1,3)
          0 1 0 zeros(1,3) origin_points(:,3)' zeros(1,3)
          0 1 0 zeros(1,3) origin_points(:,4)' zeros(1,3)
          0 0 1 zeros(1,6) origin_points(:,1)' 
          0 0 1 zeros(1,6) origin_points(:,2)'
          0 0 1 zeros(1,6) origin_points(:,3)' 
          0 0 1 zeros(1,6) origin_points(:,4)'];
 b_12_1 = [rot_points(1,:)';rot_points(2,:)';rot_points(3,:)'];
 
%  c = a_4_12 * result
 
  c = a_4_12\b_12_1;
  k = [c, result]
  k







