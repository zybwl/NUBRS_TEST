#include "algorithm.h"
#define pi 3.14159265
//bool isPieceContainsPoint(QVector<cutImagePoint> &Piece, cutImagePoint clickPoint);
void getMaxMinPoint(QVector<cutImagePoint> &Piece, cutImagePoint &MaxPoint, cutImagePoint &MinPoint)
{
     for (int i = 0; i < Piece.count(); i++)
     {
          if (Piece[i].x > MaxPoint.x)
          {
              MaxPoint.x = Piece[i].x;
          }
          if (Piece[i].y > MaxPoint.y)
          {
              MaxPoint.y = Piece[i].y;
          }
          if (Piece[i].x < MinPoint.x)
          {
              MinPoint.x = Piece[i].x;
          }
          if (Piece[i].y < MinPoint.y)
          {
              MinPoint.y = Piece[i].y;
          }
     }
}

double getMaxValue(double x1,double x2)
{
    return x1 > x2 ? x1:x2;
}

double getMinValue(double x1,double x2)
{
    return x1 < x2 ? x1:x2;
}

bool isPieceContainsPoint(QList<cutImagePoint> &Piece, cutImagePoint MaxPoint,cutImagePoint MinPoint,
                          cutImagePoint clickPoint)
{
//    function result = isPolygonContainsPoint(figure_point_array , choose_point)


//        x = figure_point_array.x;
//        y = figure_point_array.y;
//        n = length(x);
//        if choose_point.y > figure_point_array.y_range(2) || choose_point.y < figure_point_array.y_range(1)
//            result = 0;
//            return ;
//        end
//        n_cross = 0;

//       % figure(2)
//       % plot(figure_point_array

//        for i = 1:n
//            next_index =  1+ mod(i,n);
//            if (y(i) == y(next_index)) continue ; end;
//            if choose_point.y <= min(y(i) , y(next_index))  continue ;  end;
//            if choose_point.y >= max(y(i) , y(next_index))  continue ;  end;
//            new_x = (choose_point.y - y(i)) * (x(next_index) - x(i))/(y(next_index) - y(i)) + x(i);
//            if (new_x > choose_point.x)
//                n_cross = n_cross + 1;
//            end
//        end
//        result = mod(n_cross,2);
    bool result;
    int n = Piece.count();
    //MaxPoint = Piece[0];
    //MinPoint = Piece[0];
    //getMaxMinPoint(Piece, MaxPoint, MinPoint);
    if (clickPoint.y > MaxPoint.y || clickPoint.y < MinPoint.y ||
            clickPoint.x > MaxPoint.x || clickPoint.x < MinPoint.x)
    {
        //qDebug()<<"return false hit";
        return false;
    }

    //return true;
    //qDebug()<<"lkknew:0";
    int n_cross = 0;
    int next_index = 0;
    double minY;
    double maxY;
    double new_x;
    for (int i = 0; i < Piece.count();i++)
    {
       next_index = (1+i)%n;
       if (Piece[i].y == Piece[next_index].y)
       {
           continue;
       }
       minY = Piece[i].y < Piece[next_index].y ? Piece[i].y : Piece[next_index].y;
       maxY = Piece[i].y > Piece[next_index].y ? Piece[i].y : Piece[next_index].y;
       if (clickPoint.y < minY || clickPoint.y > maxY)
       {
           continue;
       }
       new_x = (clickPoint.y - Piece[i].y)*(Piece[next_index].x - Piece[i].x)/(Piece[next_index].y - Piece[i].y) + Piece[i].x;
       //2019-08-10 谭长合 增加如果刚好在直线上，则返回在外部
       if(qAbs(new_x - clickPoint.x) < 1e-3)
       {
           return false;
       }
       if (new_x > clickPoint.x)
       {
          n_cross = n_cross + 1;
       }
    }

    result = n_cross%2 == 0 ? false:true;
    return result;
}



int getPieceContainsPoint(QList<PieceData> &Piecelist, cutImagePoint clickPoint)
{
//    cloth_index = 0;
//    cloth_index_array = [];

//    for i = 1:length(x)
//        choose_point.x = x(i);//鼠标点击点
//        choose_point.y = 550 - y(i);
//        for j = 1:length(figure_array); //衣片数组
//            result = isPolygonContainsPoint(figure_array(j), choose_point);
//            if result == 1//鼠标点击点在第j个衣片内
//                 cloth_index_array = [cloth_index_array j];
//            end
//        end
//    end

//    % 保证图元有且仅有一个，这个图元是所有图形里面最小的
//    % 找出被包含的最小集合，check_no为其余图元，choose_no为被选中要检查的图元
//    % 只检查一个点，这个点需要被其他所有的图元包围（其余情况不考虑）
//    n = length(cloth_index_array);
//    satisfy_figure_num = 0;
//    if n > 1
//        for i = 1:n
//            choose_no = cloth_index_array(i);
//            choose_point.x = figure_array(choose_no).x(1);
//            choose_point.y = figure_array(choose_no).y(1);
//            for j = 1:n
//                if i == j
//                    %自己包含自己不用检查
//                    continue;
//                else

//                    check_no = cloth_index_array(j);
//                    result = isPolygonContainsPoint(figure_array(check_no), choose_point);
//                    if result ~= 1
//                        break;
//                    else
//                        satisfy_figure_num = satisfy_figure_num + 1;
//                        if satisfy_figure_num == n - 1
//                            cloth_index = choose_no;
//                        end
//                    end
//                end

//            end
//        end
//    else
//        cloth_index = cloth_index_array(1);
//    end
    int n = Piecelist.count();
    QVector<int> indexVec;
    double result;
    int selectpiece_index = 0;
    for (int i = 0; i < Piecelist.count(); i++)
    {
        result = isPieceContainsPoint(Piecelist[i].Piece, Piecelist[i].maxPoint,Piecelist[i].minPoint,
                                      clickPoint);
        if (result)
        {
           indexVec.push_back(i);
           //qDebug()<<"lk-index:"<<i;
        }
    }


    n = indexVec.count();
    if (n==0)
    {
        return -1;
    }
    if (n == 1)
    {
        return indexVec[0];
    }
    int choose_no,check_no;
    cutImagePoint choosePoint;
    int satisfy_figure_num = 0;
    selectpiece_index = 0;
    n = indexVec.count();
    for (int i = 0; i < indexVec.count();i++)
    {
        choose_no = indexVec[i];
        choosePoint = Piecelist[choose_no].Piece[1];
        satisfy_figure_num = 0;
        for (int j = 0; j < indexVec.count();j++)
        {
            if (choose_no == indexVec[j])
            {
                continue;
            }
            check_no = indexVec[j];
            //qDebug()<<QString("check_no:%1,choose_no:%2").arg(check_no).arg(choose_no);

            result = isPieceContainsPoint(Piecelist[check_no].Piece, Piecelist[check_no].maxPoint,
                                         Piecelist[check_no].minPoint,Piecelist[choose_no].minPoint);
            if (!result)
            {
                //qDebug()<<"!result";
                break;
            }
            else
            {
                //qDebug()<<"lktest-satisfy_figure_num:"<<satisfy_figure_num;
                satisfy_figure_num = satisfy_figure_num +1;
                //qDebug()<<"lktest-satisfy_figure_num:"<<satisfy_figure_num;
            }
            if (satisfy_figure_num == n-1)
            {
                //qDebug()<<"satisfy_figure_num == n-1";
                selectpiece_index = choose_no;
            }
        }
    }
    qDebug()<<"lkselectpiece_index:"<<selectpiece_index;
    return selectpiece_index;
}

void getcutPointfromPiece(QList<cutImagePoint> &piecepointList, double xy_value, bool isYaxisCut,
                                 cutImagePoint MaxPoint, cutImagePoint MinPoint, QList<cutImagePoint> &res)
{
//    %flag = 1 代表延Y轴方向切
//    %flag = 0 代表延X轴方向切

//    function result = cutClothWithXY(figure_point_array , xy_value , flag)

//        x = figure_point_array.x;
//        y = figure_point_array.y;
//        n = length(x);
//        result = [];

//        if flag == 0
//            if xy_value > figure_point_array.y_range(2) || xy_value < figure_point_array.y_range(1)
//                return ;
//            end

//            for i = 1:n
//                next_index =  1+ mod(i,n);
//                if (y(i) == y(next_index)) continue ; end;
//                if xy_value <= min(y(i) , y(next_index))  continue ;  end;
//                if xy_value >= max(y(i) , y(next_index))  continue ;  end;
//                new_x = (xy_value - y(i)) * (x(next_index) - x(i))/(y(next_index) - y(i)) + x(i);
//                result = [result , new_x];
//            end

//        else
//             if xy_value > figure_point_array.x_range(2) || xy_value < figure_point_array.x_range(1)
//                return ;
//            end

//            for i = 1:n
//                next_index =  1+ mod(i,n);
//                if (x(i) == x(next_index)) continue ; end;
//                if xy_value <= min(x(i) , x(next_index))  continue ;  end;
//                if xy_value >= max(x(i) , x(next_index))  continue ;  end;
//                new_y = (xy_value- x(i)) * (y(next_index) - y(i))/(x(next_index) - x(i)) + y(i);
//                result = [result , new_y];
//            end

//        end
    int next_index;
    double minXYtmp;
    double maxXYtmp;
    double new_xy;
    cutImagePoint pointtmp;
    int n = piecepointList.count();
    if (isYaxisCut)
    {
//        if (xy_value > MaxPoint.x || xy_value < MinPoint.x)
//        {
//            return;
//        }
        //qDebug()<<QString("xy_value:%1,MaxPoint.x:%2,MinPoint.x:%3").arg(xy_value).arg(MaxPoint.x).arg(MinPoint.x);
        //qDebug()<<"isYaxisCut";
        for (int i = 0; i < piecepointList.count();i++)
        {
            next_index = (1+i)%n;
            //qDebug()<<"isYaxisCut";
            minXYtmp = getMinValue(piecepointList[i].x, piecepointList[next_index].x);
            maxXYtmp = getMaxValue(piecepointList[i].x, piecepointList[next_index].x);
            //qDebug()<<"xy_value:"<<xy_value;
            //qDebug()<<QString("minXYtmp:%1,maxXYtmp:%2,xi:%3,xnext:%4").arg(minXYtmp).
                      //arg(maxXYtmp).arg(piecepointList[i].x).arg(piecepointList[next_index].x);
            if (piecepointList[i].x == piecepointList[next_index].x)
            {
                //qDebug()<<"piecepointList[i].x == piecepointList[next_index].x";
                continue;
            }

            if (xy_value > maxXYtmp || xy_value < minXYtmp)
            {
                //qDebug()<<"xy_value > maxXYtmp || xy_value < minXYtmp";
                continue;
            }

            new_xy = (xy_value - piecepointList[i].x)*(piecepointList[next_index].y - piecepointList[i].y)/
                    (piecepointList[next_index].x - piecepointList[i].x)+piecepointList[i].y;
            //qDebug()<<"Y-new_xy:"<<new_xy;
            pointtmp.x = xy_value;
            pointtmp.y = new_xy;
            res.push_back(pointtmp);
        }
    }
    else
    {
//        if (xy_value > MaxPoint.y || xy_value < MinPoint.y)
//        {
//            return;
//        }

        for (int i = 0; i < piecepointList.count();i++)
        {
            next_index = (1+i)%n;
            minXYtmp = getMinValue(piecepointList[i].y, piecepointList[next_index].y);
            maxXYtmp = getMaxValue(piecepointList[i].y, piecepointList[next_index].y);
            if (piecepointList[i].y == piecepointList[next_index].y)
            {
                continue;
            }
            if (xy_value > maxXYtmp || xy_value < minXYtmp)
            {
                continue;
            }
            new_xy = (xy_value - piecepointList[i].y)*(piecepointList[next_index].x - piecepointList[i].x)/
                    (piecepointList[next_index].y - piecepointList[i].y)+piecepointList[i].x;
            //qDebug()<<"X-new_xy:"<<new_xy;
            pointtmp.x = new_xy;
            pointtmp.y = xy_value;
            res.push_back(pointtmp);
        }
    }
//    cut_axis_array = [0];
//    cut_flag = 1;
//    cut_axis_value = 200;

//    for i = 1:length(figure_array);
//       one_axis_array  = cutClothWithXY(figure_array(i), cut_axis_value, cut_flag);
//        if isempty(one_axis_array) == 0
//             cut_axis_array = [cut_axis_array ,one_axis_array];
//        end
//    end
//    cut_axis_array = [cut_axis_array 600];

//    cut_axis_array = sort(cut_axis_array);
//    for i = 1:2:length(cut_axis_array)-1
//        if cut_flag == 0
//             plot([cut_axis_array(i) cut_axis_array(i+1)] ,[cut_axis_value cut_axis_value],'r');
//        else
//            plot([cut_axis_value cut_axis_value],[cut_axis_array(i) cut_axis_array(i+1)] ,'r');
//        end
//    end

}

void pointsort(QList<cutImagePoint> &pointlist,bool isbigtoSmall,bool isX)
{
    cutImagePoint Pointtmp;
    for (int i = 0; i < pointlist.count();i++)
    {
       for (int j = 0; j < pointlist.count()-1-i; j++)
       {
           if (isbigtoSmall)
           {
               if (isX)
               {
                   if (pointlist[j].x < pointlist[j+1].x)
                   {
                       Pointtmp = pointlist[j];
                       pointlist[j] = pointlist[j+1];
                       pointlist[j+1] = Pointtmp;
                   }
               }
               else
               {
                   if (pointlist[j].y < pointlist[j+1].y)
                   {
                       Pointtmp = pointlist[j];
                       pointlist[j] = pointlist[j+1];
                       pointlist[j+1] = Pointtmp;
                   }
               }
           }
           else
           {
               if (isX)
               {
                   if (pointlist[j].x > pointlist[j+1].x)
                   {
                       Pointtmp = pointlist[j];
                       pointlist[j] = pointlist[j+1];
                       pointlist[j+1] = Pointtmp;
                   }
               }
               else
               {
                   if (pointlist[j].y > pointlist[j+1].y)
                   {
                       Pointtmp = pointlist[j];
                       pointlist[j] = pointlist[j+1];
                       pointlist[j+1] = Pointtmp;
                   }
               }
           }

       }
    }
}

void sonclothfiler(QList<PieceData> &Piecelist)
{
    //int testcount = 0;
    QList<int> indexList;
    for (int i = 0; i < Piecelist.count(); i++)
    {
        for (int j = 0; j < Piecelist.count();j++)
        {
            if (i == j)
            {
                continue;
            }
            if (isPieceContainsPoint(Piecelist[j].Piece, Piecelist[j].maxPoint,Piecelist[j].minPoint,
                                                  Piecelist[i].Piece[0]))
            {
                indexList.push_back(i);
                break;
            }
        }
    }
    //int count = Piecelist.count();
    int k = 0;
    for (int i = 0; i < indexList.count(); i++)
    {
        Piecelist.removeAt(indexList[i]-k);
        k++;
    }
}

void getcutPointfromcloth(QList<PieceData> &pieceList, cutImagePoint maxPoint, cutImagePoint minPoint,
                          bool isYaxisCut, QList<QList<cutImagePoint>> &res, const cutRemainClothPara &para)
{
    double xycut_axis_value;
    int cutlinecount = 10;
    double gap;
    double gaptmp;
    double counttmp;
    QList<cutImagePoint> sonres;
    int count = 0;
    int k = 0;
    sonclothfiler(pieceList);

    gap = -para.remain_sep;
    if (isYaxisCut)
    {
        counttmp = (maxPoint.x - minPoint.x)/para.remain_sep;
        gaptmp = (counttmp-floor(counttmp))*para.remain_sep+para.remain_sep;
        if (gaptmp <= para.remain_last_max_sep)
        {
            cutlinecount = (maxPoint.x - minPoint.x)/fabs(gap)-1;
        }
        else
        {
            cutlinecount = (maxPoint.x - minPoint.x)/fabs(gap);
        }

        xycut_axis_value = maxPoint.x;
    }
    else
    {
        counttmp = (maxPoint.y - minPoint.y)/para.remain_sep;
        gaptmp = (counttmp-floor(counttmp))*para.remain_sep+para.remain_sep;
        if (gaptmp <= para.remain_last_max_sep)
        {
            cutlinecount = (maxPoint.y - minPoint.y)/fabs(gap)-1;
        }
        else
        {
            cutlinecount = (maxPoint.y - minPoint.y)/fabs(gap);
        }
        xycut_axis_value = maxPoint.y;
    }
    qDebug()<<"gap:"<<gap;
    qDebug()<<"cutlinecount:"<<cutlinecount;
    cutImagePoint Pointtmp;
    QList<cutImagePoint> sonrestmp;


    for (int i = 0;i <= cutlinecount+1;i++)
    {
        sonres.clear();

        if (isYaxisCut)
        {
            sonres.push_back(cutImagePoint(xycut_axis_value,maxPoint.y,0));
        }
        else
        {
            sonres.push_back(cutImagePoint(maxPoint.x,xycut_axis_value,0));
        }
        for (int j = 0; j < pieceList.count();j++)
        {
            getcutPointfromPiece(pieceList[j].Piece, xycut_axis_value, isYaxisCut,
                                             pieceList[j].maxPoint, pieceList[j].minPoint, sonres);
        }
        //sonres.push_back(cutImagePoint(xycut_axis_value,maxPoint.y+5,0));
        if (isYaxisCut)
        {
            sonres.push_back(cutImagePoint(xycut_axis_value,minPoint.y,0));
            pointsort(sonres,true,false);
            if (i < cutlinecount)
            {
                xycut_axis_value += gap;
            }
            else
            {
                xycut_axis_value = minPoint.x;
            }
        }
        else
        {
            sonres.push_back(cutImagePoint(minPoint.x,xycut_axis_value,0));
            pointsort(sonres,true,true);
            if (i < cutlinecount)
            {
                xycut_axis_value += gap;
            }
            else
            {
                xycut_axis_value = minPoint.y;
            }
        }
        count = sonres.count();
        res.push_back(sonres);
    }
}

bool isDotInline(cutImagePoint startPoint, cutImagePoint endPoint, cutImagePoint currentPoint)
{
//    %判断点是否在线上
//    function result = isDotInline(pointA,pointB,pointC)
//        vect1 = pointB - pointA;
//        vect2 = pointC - pointB ;
//        mulsum = sum(vect1.*vect2);

//        if mulsum < 0
//            result = 0;
//        else
//            result = 1;
//        end
   double mulsum = (endPoint.x - startPoint.x)*(currentPoint.x - endPoint.x)
           + (endPoint.y - startPoint.y)*(currentPoint.y - endPoint.y);
   if (mulsum < 0)
   {
      return false;
   }
   else
   {
      return true;
   }

}

void circleCross(QList<cutImagePoint> &pointlist, CircleType circle, cutImagePoint maxPoint,
                                 cutImagePoint minPoint, QList<cutImagePoint> &cross_point)
{
    QList<double> anglelist;
    anglelist.push_back(circle.ange1);
    anglelist.push_back(circle.ange2);
    int ang1_index = floor(circle.ange1/90);
    int ang2_index = floor(circle.ange2/90);
    if (ang2_index > ang1_index)
    {
        for (int i = ang1_index+1; i <= ang2_index; i++)
        {
           anglelist.push_back(90*i);
        }
    }
    else
    {
        for (int i = ang2_index+1; i <= ang1_index; i++)
        {
           anglelist.push_back(90*i);
        }
    }
    rectangle r1,r2,r3;
    r1.left = 9999999;
    r1.right = -9999999;
    r1.bottom = 9999999;
    r1.top = -9999999;
    for (int i = 0; i < anglelist.count(); i++)
    {
       r1.left = getMinValue(circle.cp.x + circle.r*cos(pi*anglelist[i]/180),r1.left);
       r1.right = getMaxValue(circle.cp.x + circle.r*cos(pi*anglelist[i]/180),r1.right);
       r1.bottom = getMinValue(circle.cp.y + circle.r*sin(pi*anglelist[i]/180),r1.bottom);
       r1.top = getMaxValue(circle.cp.y + circle.r*sin(pi*anglelist[i]/180),r1.top);
    }
    r2.left = minPoint.x;
    r2.right = maxPoint.x;
    r2.bottom = minPoint.y;
    r2.top = maxPoint.y;
    bool is_figure_cross = !((r1.bottom > r2.top) || (r2.bottom > r1.top) || (r1.right < r2.left) || (r2.right < r1.left));
    //QList<cutImagePoint> cross_point;
    int next_index = 0;
    bool linevect_have_no_cross;
    double vect_x1,vect_y1,vect_x2,vect_y2,vect_x0,vect_y0;
    double L0,cosx,siny,S,h;
    double cross_point_x,cross_point_y;
    double vertical_l;
    //%垂点x和y
    double vertical_x,vertical_y,cross_point1_x,cross_point1_y,cross_point2_x,cross_point2_y;
    cutImagePoint pointtmp1,pointtmp2,pointtmp3;
    qDebug()<<"is_figure_cross:"<<is_figure_cross;
    if (is_figure_cross)
    {
       qDebug()<<"is_figure_cross1";
       for (int i = 0; i < pointlist.count();i++)
       {
           if (i == pointlist.count()-1)
           {
              next_index = 0;
           }
           else
           {
              next_index = 1+i;
           }
           r3.left = getMinValue(pointlist[i].x, pointlist[next_index].x);
           r3.right = getMaxValue(pointlist[i].x, pointlist[next_index].x);
           r3.bottom = getMinValue(pointlist[i].y, pointlist[next_index].y);
           r3.top = getMaxValue(pointlist[i].y, pointlist[next_index].y);
           linevect_have_no_cross = (r3.bottom > r1.top) || (r1.bottom > r3.top) || (r3.right < r1.left) || (r1.right < r3.left);
           if (linevect_have_no_cross)
           {
               continue;
           }
           if ((pointlist[i].y == pointlist[next_index].y)&&
                   (pointlist[i].x == pointlist[next_index].x))
           {
               continue;
           }
           vect_x1 = pointlist[i].x - circle.cp.x;
           vect_y1 = pointlist[i].y - circle.cp.y;
           vect_x2 = pointlist[next_index].x - circle.cp.x;
           vect_y2 = pointlist[next_index].y - circle.cp.y;
           vect_x0 = pointlist[next_index].x - pointlist[i].x;
           vect_y0 = pointlist[next_index].y - pointlist[i].y;
           L0 = sqrt(pow(vect_y0,2) + pow(vect_x0,2));
           cosx = vect_x0 / L0;
           siny = vect_y0 / L0;
           //% 求面积
           S = vect_x2 * vect_y1 - vect_x1 * vect_y2;
           h = S/L0;
           //%垂线长度超过半径，肯定不会相交
           if (fabs(h) > circle.r)
           {
               continue;
           }
           else if (fabs(h) == circle.r)
           {
               //%只有1个交点
               cross_point_x = circle.cp.x - siny * h;
               cross_point_y = circle.cp.y + cosx * h;
               //%线上的点是否在两个端点之间
               pointtmp1.x = cross_point_x;
               pointtmp1.y = cross_point_y;
               qDebug()<<"判断点是否在线段内1";
               if (isDotInline(pointlist[i],pointtmp1,pointlist[next_index]))
               {
                   qDebug()<<"判断点是否在线段内11";
                   cross_point.push_back(pointtmp1);
               }
           }
           else
           {
               vertical_l = sqrt(pow(circle.r,2) - pow(h,2));
               //%垂点x和y
               vertical_x = circle.cp.x - siny * h;
               vertical_y = circle.cp.y + cosx * h;
               //%跟圆的交点
               cross_point1_x = vertical_x -  cosx * vertical_l;
               cross_point1_y = vertical_y -  siny * vertical_l;
               cross_point2_x = vertical_x +  cosx * vertical_l;
               cross_point2_y = vertical_y +  siny * vertical_l;
               pointtmp1.x = cross_point1_x;
               pointtmp1.y = cross_point1_y;
               pointtmp2.x = cross_point2_x;
               pointtmp2.y = cross_point2_y;
               //%判断点是否在线段内
               qDebug()<<"判断点是否在线段内";
                if (isDotInline(pointlist[i],pointtmp1,pointlist[next_index]))
                {
                    qDebug()<<"点在线段内1";
                    cross_point.push_back(pointtmp1);
                }
                if (isDotInline(pointlist[i],pointtmp2,pointlist[next_index]))
                {
                    qDebug()<<"点在线段内2";
                    cross_point.push_back(pointtmp2);
                }
           }
       }
    }
}

void getCircleCrossPointfromCloth(QList<PieceData> &Piecelist, CircleType circle,
                                  QList<cutImagePoint> &reCroPointList)
{
    double abs_angle = fabs(circle.ange1 - circle.ange2);
    if (abs_angle > 360)
    {
       return;
    }
    QList<cutImagePoint> CrossPointList;
    for (int i = 0;i < Piecelist.count();i++)
    {
        circleCross(Piecelist[i].Piece, circle, Piecelist[i].maxPoint,
                                         Piecelist[i].minPoint, CrossPointList);
    }
    if (CrossPointList.isEmpty())
    {
        qDebug()<<"CrossPointList.isEmpty()";
        return;
    }
    //%去掉多余的点，并对满足条件的点进行排序
    //%角度重小到大排序
    QList<double> relative_angle;
    double zero_vect_x, zero_vect_y;
    if (circle.ange2 > circle.ange1)
    {
        zero_vect_x =  circle.r * cos(pi*circle.ange1/180);
        zero_vect_y =  circle.r * sin(pi*circle.ange1/180);
    }
    else
    {
        zero_vect_x = circle.r * cos(pi*circle.ange2/180);
        zero_vect_y = circle.r * sin(pi*circle.ange2/180);
    }
    double new_coodinate_x,new_coodinate_y,new_x,new_y,costheta;
    for (int i = 0;i < CrossPointList.count();i++)
    {
        new_coodinate_x = CrossPointList[i].x - circle.cp.x;
        new_coodinate_y = CrossPointList[i].y - circle.cp.y;

        //%新坐标系下的x、y坐标
        new_x = (new_coodinate_x * zero_vect_x + new_coodinate_y * zero_vect_y);
        new_y = (new_coodinate_y * zero_vect_x - new_coodinate_x * zero_vect_y);
        //%用反余弦把相对角度框定在0-360之间
        costheta = acos(new_x / sqrt(pow(new_x,2) + pow(new_y,2)))*180/pi;
        if (new_y < 0)
        {
            costheta = 360 - costheta;
        }

        //%满足范围的角度
        if (costheta <= abs_angle)
        {
            relative_angle.push_back(costheta);
        }
    }

    if (circle.ange2 < circle.ange1)
    {
        //%angle = fliplr(angle) ;
        //%角度按从大到小排序
        sort<double>(relative_angle,true);
        for (int i = 0; i < relative_angle.count();i++)
        {
            relative_angle[i] += circle.ange2;
        }
    }
    else
    {
        sort<double>(relative_angle,false);
        for (int i = 0; i < relative_angle.count();i++)
        {
            relative_angle[i] += circle.ange1;
        }
    }
    //double circle_x,circle_y;
    cutImagePoint pointtmp;
    for (int i = 0; i < relative_angle.count();i++)
    {
        pointtmp.x = circle.cp.x + circle.r * cos(pi*relative_angle[i]/180);
        pointtmp.y = circle.cp.y + circle.r * sin(pi*relative_angle[i]/180);
        reCroPointList.push_back(pointtmp);
        //plot(circle_x,circle_y ,'*r');
        //hold on
        //pause(1)
    }
}

//%对于完全重叠的直线我们不做处理
double isTwoLineAcross(cutImagePoint p1, cutImagePoint p2,cutImagePoint p3, cutImagePoint p4)
{
    double a1 = p4.x - p3.x;
    double b1 = p1.x - p2.x;
    double c1 = p1.x - p3.x;
    double a2 = p4.y - p3.y;
    double b2 = p1.y - p2.y;
    double c2 = p1.y - p3.y;
    double det_ab = a1*b2 - a2*b1;

    double lamda = -1;
    double lamda_temp;
    double beta;
    if (det_ab != 0)
    {
        lamda_temp = (c1*b2 - c2*b1)/det_ab;
        beta = (a1*c2 - c1*a2)/det_ab;
        if (lamda_temp >=0 && lamda_temp <= 1 && beta >=0 && beta <= 1)
        {
            lamda = lamda_temp;
        }
    }
    return lamda;
}

void lineCross(QList<cutImagePoint> &pointlist, cutImagePoint point_a, cutImagePoint point_b,
               cutImagePoint MaxPoint, cutImagePoint MinPoint,QList<double> &cross_lamda)
{

    //%框定直线的最小矩形，减少计算量
    rectangle r1,r2;
    r1.left = getMinValue(point_a.x , point_b.x);
    r1.right = getMaxValue(point_a.x , point_b.x);
    r1.bottom =getMinValue(point_a.y , point_b.y);
    r1.top = getMaxValue(point_a.y , point_b.y);

    //%图元框
    r2.left = MinPoint.x;//figure_point_array.x_range(1);
    r2.right = MaxPoint.x;//figure_point_array.x_range(2);
    r2.bottom = MinPoint.y;//figure_point_array.y_range(1);
    r2.top = MaxPoint.y;//figure_point_array.y_range(2);

//    % 判断两矩阵不相交比相交容易
//    % 分4种情况，图一分别在图二的上、下、左、右
//    % r1为circle本身，r2代表图元
//    % 最后结果需要取反哦
    bool is_figure_cross = !((r1.bottom > r2.top) || (r2.bottom > r1.top) || (r1.right < r2.left) || (r2.right < r1.left)) ;

//    %两个矩阵相交，代表有可能存在交点
//    %线段跟圆弧是否相交，先用垂线长判断，后用切割点是否在线段上判断
    //cross_point = [];
    if (is_figure_cross)
    {
        //double x = figure_point_array.x;
        //y = figure_point_array.y;
        //n = length(x);
        int next_index;
        double lamda;
        for (int i  = 0; i < pointlist.count();i++)//i = 1:n
        {
//            %next_index =  1+ mod(i,n);
//            %确保最后一条线段不会遗漏
            if (i == pointlist.count()-1)
            {
                //%在C++中，下面的数为0
                next_index = 0;
            }
            else
            {
                next_index = 1 + i;
            }
//            p1.x = x(i);
//            p1.y = y(i);
//            p2.x = x(next_index);
//            p2.y = y(next_index);
           lamda = isTwoLineAcross(pointlist[i],pointlist[next_index],point_a, point_b);
           if (lamda != -1)
           {
               //cross_point = [cross_point;lamda];
               cross_lamda.push_back(lamda);
           }
        }
    }
}

void getLineCrossfromcloth(QList<PieceData> &piecelist, cutImagePoint point_a, cutImagePoint point_b,
                            QList<cutImagePoint> &crosspointlist)
{
    QList<double> cross_lamda;
    for (int i = 0; i< piecelist.count();i++)
    {
       lineCross(piecelist[i].Piece, point_a, point_b, piecelist[i].maxPoint,
                 piecelist[i].minPoint,cross_lamda);
    }
    //% 如果为空就不需要排序了
    if (cross_lamda.isEmpty())
    {
        return;
    }
    //%长度按从小到大排序
    sort<double>(cross_lamda,false) ;
    cutImagePoint pointtmp;
    for (int i = 0; i< cross_lamda.count();i++)//i = 1:length(lamda)
    {
        pointtmp.x = point_a.x + cross_lamda[i]*(point_b.x - point_a.x);
        pointtmp.y = point_a.y + cross_lamda[i]*(point_b.y - point_a.y);
        crosspointlist.push_back(pointtmp);
    }
}

void basisfun(int i, double u, int p, QList<double> &U, QList<double> &N)
{
  int j,r;
  double saved, temp;

  //double *left  = (double*) mxMalloc((p+1)*sizeof(double));
  //double *right = (double*) mxMalloc((p+1)*sizeof(double));
  QList<double> left;
  QList<double> right;
  left.reserve(p+1);
  right.reserve(p+1);

  N[0] = 1.0;
  for (j = 1; j <= p; j++)
  {
    left[j]  = u - U[i+1-j];
    right[j] = U[i+j] - u;
    saved = 0.0;

    for (r = 0; r < j; r++)
    {
        temp = N[r] / (right[r+1] + left[j-r]);
        N[r] = saved + right[r+1] * temp;
        saved = left[j-r] * temp;
    }

    N[j] = saved;
  }

  //mxFree(left);
  //mxFree(right);
}


int findspan(int n, int p, double u, QList<double> &U)
{
    int low, high, mid;
    // special case
    if (u == U[n+1]) return(n);

    // do binary search
    low = p;
    high = n + 1;
    mid = (low + high) / 2;
    while (u < U[mid] || u >= U[mid+1])
    {
      if (u < U[mid])
        high = mid;
      else
        low = mid;

      mid = (low + high) / 2;
    }

    return(mid);
}


void getnewcontour(QList<cutImagePoint> &pointlist,QList<cutImagePoint> &newcontour)
{
//    % 第二步点忽略和细化
//    % 下一个点与上一个点距离小于0.5毫米忽略
//    % 小于0.5毫米的线段随意跳动会对性能影响很大
//    % 截断段数为3毫米的倍数
    QList<cutImagePoint> newpointlist;
    int index = 0;
    int n = pointlist.size();
    cutImagePoint pointtmp,vect;
    double vect_l,l_n;
    for (int k = 0;k < n;k++)
    {
         if (k == 0)
         {
                //point(:,index) = [X(k);Y(k)];
                //pointtmp = po
                newpointlist.push_back(pointlist[k]);
                //U(1) = 0;
                index = index + 1;
         }
         else
         {
                //vect = [X(k);Y(k)] - point(:,index-1);
                vect.x = pointlist[k].x - newpointlist[index-1].x;
                vect.y = pointlist[k].y - newpointlist[index-1].y;
                vect_l = pointlist[k].distanceTo(newpointlist[index-1]);
                //vect_l = sqrt(vect'* vect);
                l_n = ceil(vect_l/3);
                if (vect_l > 0.5)
                {
                    for (int i = 0;i < l_n-1;i++)
                    {
                        pointtmp.x = newpointlist[index-1].x + 1/l_n * vect.x;
                        pointtmp.y = newpointlist[index-1].y + 1/l_n * vect.y;
                        newpointlist.push_back(pointtmp);
                        index = index + 1;
                    }
                }
                else
                {
                    continue;
                }
         }
    }

    //%第三步所有线段向心参数化，拟合后的个数是长度的2.5倍左右，不能太多多了震荡严重
//    n = size(point,2);
//    U = zeros(1, n);
    n = newpointlist.size();
    QList<double> U;
    U.reserve(n);
    for (int i=0; i < n;i++)
    {
        U[i]= 0;
    }
    for (int k = 1;k < n;k++)
    {
//            vect = point(:,k) - point(:,k-1);
//            U(1,k) = U(1,k -1) + sqrt(vect'* vect);
//        vect.x = newpointlist[k].x - newpointlist[k-1].x;
//        vect.y = newpointlist[k].y - newpointlist[k-1].y;

        U[k] = U[k-1] + newpointlist[k].distanceTo(newpointlist[k-1]);
    }
    double ploy_n = ceil(U[n-1] * 2.5);
    double Un = U[n-1];
    for (int i=0;i < U.size();i++)
    {
        //U  = U / U(1,n);
        U[i] = U[i]/Un;
    }

    //%第四步按输入阶数p形成新的节点矢量
    //U_ploy = zeros(1, n+p+1);
    QList<double> U_ploy;
    U_ploy.reserve(n+p);
    for (int i = 0; i < U_ploy.size();i++)
    {
        U_ploy[i] = 0;
    }
//    for k = 2: n-p
//        U_ploy(1,k+p) = sum(U(1, k : k + p - 1))/p;
//    end
    double sumtmp;
    for (int k = 1;k < n-p;k++)
    {
        sumtmp = 0;
        for (int j = k; j <= k+p-1;k++)
        {
           sumtmp += U[k + p - 1];
        }
        U_ploy[k+p] = sumtmp/p;
    }

    //U_ploy(1,n+1:end) = 1;
    for (int i = n;i < U_ploy.size();i++)
    {
        U_ploy[i] = 1;
    }

//    plot(point(1,:),point(2,:),'b');
//    hold on

//    %第五步生成新的点
//    index = 1;
//    for u = 0:1/ploy_n:1
//        span = findspan(n-1 , p , u ,U_ploy );
//        N = basisfun(span,u,p,U_ploy);
//        new_point(index,:) = N * point(:,span - p + 1 : span + 1)';
//        index = index + 1;
//    end
    int span;
    QList<double> N;
    N.reserve(4);
    for (int u = 0;u <= 1; u += 1/ploy_n)
    {
        span = findspan(n-1 , p , u ,U_ploy);
        basisfun(span,u,p,U_ploy,N);
        pointtmp.x = 0;
        pointtmp.y = 0;
        for (int i =0; i <= p;i++)
        {
           pointtmp.x += N[i]*newpointlist[span- p + i].x;
           pointtmp.y += N[i]*newpointlist[span- p + i].y;
        }
        //new_point(index,:) = N * point(:,span - p + 1 : span + 1)';
        newcontour.push_back(pointtmp);
        //index = index + 1;
    }
    //plot(new_point(:,1),new_point(:,2),'-r');
}







