A=[0,0,0];%%%�����ֵδ�õ�
B=[100,0,0];%B=[1,sqrt(3),0];
C=[100,100,0]%[1-sqrt(2),0,0];%%%�����ֵδ�õ�
Oab=[50,0,0];
Obc=[100,50,0];
%Oab=[-1,-1,0];
%Obc=[1,1,0];
error=2000;
circle_clockwiseAB=1;
circle_clockwiseBC=0;
[Ot r error startPoint endPoint]=Solvecircle2circle(A,B,C,Oab,Obc,error,circle_clockwiseAB,circle_clockwiseBC)

error=norm(Ot-B)-r;
x0 = Ot(1), y0 = Ot(2); %ԭ��
plot(x0,y0,'*');
hold on
theta=0:pi/10000:2*pi; %�Ƕ�[0,2*pi]
R=r; %�뾶
x=R*cos(theta)+x0;
y=R*sin(theta)+y0;
plot(x,y,'-r')
axis equal
hold on
x0 = Obc(1), y0 = Obc(2); %ԭ��
theta=0:pi/10000:2*pi; %�Ƕ�[0,2*pi]
R=norm(B-Obc); %�뾶
x=R*cos(theta)+x0;
y=R*sin(theta)+y0;
plot(x,y,'-')
axis equal
hold on
x0 = Oab(1), y0 = Oab(2); %ԭ��
theta=0:pi/10000:2*pi; %�Ƕ�[0,2*pi]
R=norm(B-Oab); %�뾶
x=R*cos(theta)+x0;
y=R*sin(theta)+y0;
plot(x,y,'-')
axis equal
hold on
x0 = B(1), y0 = B(2); %ԭ��
theta=0:pi/10000:2*pi; %�Ƕ�[0,2*pi]
R=error; %�뾶
x=R*cos(theta)+x0;
y=R*sin(theta)+y0;
plot(x,y,'-g')
axis equal
grid on
hold on
plot(startPoint(1),startPoint(2),'*');
hold on
plot(endPoint(1),endPoint(2),'*');
hold on
plot(A(1),A(2),'r*');
hold on
plot(C(1),C(2),'r*');