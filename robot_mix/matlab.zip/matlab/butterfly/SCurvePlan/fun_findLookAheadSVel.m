function v = fun_findLookAheadSVel(vs,ve,F,S)

% global MAXACC;
% global MAXDEC;
% global MAXJERK;
% Amax = MAXACC;
% Dec = MAXDEC;
% Jmax = MAXJERK;
% output��������ɴﵽ���ٶ�(9/29�޸ģ�ɾ�����������ʱ�ɴﵽ������/���ٶȡ��������S�滮�л�Լ��ٶȵ���)

eps = 1e-8;
if F == vs && F > ve
    vlow = ve;
    vhigh = F;
    vmax = (vlow+vhigh)/2;
    vs = vmax;
    s = fun_displaceOfAccDec(vs,ve,vmax);
    while abs(s-S) > eps
        if s<S
            vlow = vmax;
            vmax = (vlow+vhigh)/2;
            vs = vmax;
        elseif s>S
            vhigh = vmax;
            vmax = (vlow+vhigh)/2;
            vs = vmax;
        end
        s = fun_displaceOfAccDec(vs,ve,vmax);
    end
    v = vmax;
elseif F == ve && F > vs
    vlow = vs;
    vhigh = F;
    vmax = (vlow+vhigh)/2;
    ve = vmax;
    s = fun_displaceOfAccDec(vs,ve,vmax);
    while abs(s-S) > eps
        if s<S
            vlow = vmax;
            vmax = (vlow+vhigh)/2;
            ve = vmax;
        elseif s>S
            vhigh = vmax;
            vmax = (vlow+vhigh)/2;
            ve = vmax;
        end
        s = fun_displaceOfAccDec(vs,ve,vmax);
    end
    v = vmax;
end
