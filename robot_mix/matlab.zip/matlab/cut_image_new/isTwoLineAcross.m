%������ȫ�ص���ֱ�����ǲ�������
function lamda = isTwoLineAcross(p1,p2,p3,p4)
    

    a1 = p4.x - p3.x;    b1 = p1.x - p2.x;    c1 = p1.x - p3.x;
    a2 = p4.y - p3.y;    b2 = p1.y - p2.y;    c2 = p1.y - p3.y;
    det_ab = a1*b2 - a2*b1;

    lamda = -1;
    if det_ab ~= 0
        lamda_temp = (c1*b2 - c2*b1)/det_ab;
        beta = (a1*c2 - c1*a2)/det_ab;
        if lamda_temp >=0 && lamda_temp <= 1 && beta >=0 && beta <= 1
            lamda = lamda_temp;
        end             
    end
    

    