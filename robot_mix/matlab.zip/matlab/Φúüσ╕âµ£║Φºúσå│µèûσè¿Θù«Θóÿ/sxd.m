clc;clear all;
file_name = 'new1.NC';

start_line_no = 5;
end_line_no = 10000;
[line_before, point_struct_array ,line_end] = get_nc_data1(file_name,start_line_no,end_line_no);
n = size(point_struct_array,2);
X = zeros(1,n);
Y = zeros(1,n);
for k = 1:n
    X(k) = point_struct_array(k).X;
    Y(k) = point_struct_array(k).Y;
end