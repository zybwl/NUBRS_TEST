function draw_knife(knife_point,h,r)

knife_l = 2;
h = h - knife_l;
[x, y, z]=cylinder(r); 
z = h * z - h/2;  
n = size(x,2);
center_point = knife_point;
center_point(3) = knife_point(3) + knife_l + h/2;
new_down = [x(1,:);y(1,:);z(1,:);ones(1,n)];
new_top = [x(2,:);y(2,:);z(2,:);ones(1,n)];
knife_down = [zeros(2,n);z(1,:) - knife_l;ones(1,n)];

new_x = [new_top(1,:);new_down(1,:)] + center_point(1);
new_y = [new_top(2,:);new_down(2,:)] + center_point(2);
new_z = [new_top(3,:);new_down(3,:)] + center_point(3);

surf(new_x,new_y,new_z,'FaceColor',[1,0,0]); 
fill3(new_x',new_y',new_z',[0 1 0]);   
     
knife_x = [new_down(1,:);knife_down(1,:)] + center_point(1);
knife_y = [new_down(2,:);knife_down(2,:)] + center_point(2);
knife_z = [new_down(3,:);knife_down(3,:)] + center_point(3);
surf(knife_x,knife_y,knife_z,'FaceColor',[0,1,0]);

