function [Ot radius error1 pnt_start pnt_end]=Solvecircle2circle(A,B,C,Oab,Obc,error,circle_clockwiseAB,circle_clockwiseBC)
 %%%%
Ot=[];

%%ԲAB�İ뾶
 Rab=norm(B(1,:)-Oab(1,:));
 Vector_oabB=(B-Oab)/ Rab; 
 %%ԲBC�İ뾶
 Rbc=norm(B(1,:)-Obc(1,:)); 
 Vector_obcB=(B-Obc)/ Rbc; 
 %%%%%%����AB��B�������
 if circle_clockwiseAB==1 %%1Ϊ˳ʱ�룬0Ϊ��ʱ�� 
     VectorplaneAB=[0,0,-1];
 else
     VectorplaneAB=[0,0,1];
 end
  %%��˼���  ע����˳�򣬲�˽�����Ҫ�����
 Vector_tanoabB=[Vector_oabB(3)*VectorplaneAB(2)-Vector_oabB(2)*VectorplaneAB(3),-(Vector_oabB(3)*VectorplaneAB(1)-Vector_oabB(1)*VectorplaneAB(3)),Vector_oabB(2)*VectorplaneAB(1)-Vector_oabB(1)*VectorplaneAB(2)];
 Vector_tanoabB=Vector_tanoabB/norm(Vector_tanoabB(1,:));
%%%%%%%%����BC��B�������
if circle_clockwiseBC==1 %%1Ϊ˳ʱ�룬0Ϊ��ʱ�� 
     VectorplaneBC=[0,0,-1];
 else
     VectorplaneBC=[0,0,1];
 end
  %%��˼���  ע����˳�򣬲�˽�����Ҫ�����
 Vector_tanobcB=[Vector_obcB(3)*VectorplaneBC(2)-Vector_obcB(2)*VectorplaneBC(3),-(Vector_obcB(3)*VectorplaneBC(1)-Vector_obcB(1)*VectorplaneBC(3)),Vector_obcB(2)*VectorplaneBC(1)-Vector_obcB(1)*VectorplaneBC(2)];
 Vector_tanobcB=Vector_tanobcB/norm(Vector_tanobcB(1,:));
%%%%
%%%%����Vector_tanobcB��ObcB�ļн��ж��ڽӺ�����
cos_theat=(Vector_tanoabB(1)*Vector_obcB(1)+Vector_tanoabB(2)*Vector_obcB(2)+Vector_tanoabB(3)*Vector_obcB(3));
theta=acos(cos_theat);
%%%%%%%  theta ��0������180�ȸ���  ʱ�򣬲������������ݲ�����
%%%%%�ж� Oab��B��Obc������   �ò�ˡ�
crosso2o=[Vector_oabB(2)*Vector_obcB(3)-Vector_oabB(3)*Vector_obcB(2),-(Vector_oabB(1)*Vector_obcB(3)-Vector_oabB(3)*Vector_obcB(1)),Vector_oabB(1)*Vector_obcB(2)-Vector_oabB(2)*Vector_obcB(1)];

%%%�ж� crosso2o��������С����Ϊ��0,0,1����1,0,0����Ϊ�ռ�Բ�� return��
%%%С��0��˳ʱ�룬����0����ʱ�룬����0���������ۡ�
if crosso2o(1)*crosso2o(2)+crosso2o(2)*crosso2o(3)+crosso2o(3)*crosso2o(1)~=0
    return;
end
if crosso2o(1)+crosso2o(2)+crosso2o(3)<0
    clock_wiseABC=1;%%%˳ʱ��
elseif crosso2o(1)+crosso2o(2)+crosso2o(3)>0
    clock_wiseABC=0;%%%��ʱ��
else  %%%����0,����
    %%%B��������ͬ��ȡ������
    clock_wiseABC=-1;
    dot=0;
    if Vector_tanoabB(1)*Vector_tanobcB(1)+Vector_tanoabB(2)*Vector_tanobcB(2)+Vector_tanoabB(3)*Vector_tanobcB(3)>0
        return;
    end
    %%%%%%%% ��������ͬ�� 
     dot=Vector_oabB(1)*Vector_obcB(1)+Vector_oabB(2)*Vector_obcB(2)+Vector_oabB(3)*Vector_obcB(3);
     if dot>0
         %%����
     end  
     if dot<0
         %%%���
     end
end
Rflag1=0; %%%% Rflag1  1Ϊ��ӣ�-1Ϊ����
Rflag2=0;
Oabbc=norm(Oab(1,:)-Obc(1,:));
%%%%%%�ж�Բ������
if clock_wiseABC~=-1
    %%%%%������ͬ��ʱ��
    if (circle_clockwiseAB==circle_clockwiseBC)
        transition_type=1; %%%%������ͬ 
        if  clock_wiseABC~=circle_clockwiseAB
            Rflag1=1;
            Rflag2=1;
            %%%%%�ж�����С%%%           
            if Oabbc^2-(Rab-Rbc)^2<=0
               return;
            end
            F2=(Oabbc^2-(Rab-Rbc)^2); %F��ƽ��
            a=Oabbc^2;
            b=-1*F2*(Rab+Rbc);
            c= F2^2/4;
            del=b^2-4*a*c;
            if del<0
                return;
            end
            XX1=(-b+sqrt(del))/(2*a);
            XX2=(-b-sqrt(del))/(2*a);
            if XX2>0
                if error>XX2
                    error=XX2/2;
                end
            else
                return;
            end
            
        else
            Rflag1=-1;
            Rflag2=-1;
            %%%����ת��Բֱ�����Ϊ  r1+r2-Oabcd
            d=Rab+Rbc-Oabbc;
            if Rab>Rbc
                R=Rab;
            else
                R=Rbc;
            end
            x1=sqrt(( Rab+Rbc+Oabbc)*d*( Rab-Rbc+Oabbc)*( Rbc+Oabbc-Rab))/ (2*Oabbc);%%%�ҳ���һ��
            L=R-sqrt(R^2-x1^2);
            L12=(d/2-L)^2;
            error1=sqrt(x1^2+L12)-d/2;
            if error>error1
                error=error1/2;
            end       
            
        end
    %%%%%�����෴��ʱ��
    else
        transition_type=0;%%%%ͬ��
         if  clock_wiseABC==circle_clockwiseAB
             Rflag1=1;
             Rflag2=-1;
         else
             Rflag1=-1;
             Rflag2=1;
         end
         %%%����ת��Բֱ�����Ϊ  r1+r2-Oabcd
          if Rab>Rbc
                R=Rab;
            else
                R=Rbc;
           end
         if Rflag1<0 
             
             d1=Rab+Rbc-Oabbc;
             d=2*Rab-d1;
             x1=sqrt(( Rab+Rbc+Oabbc)*(Rab+Rbc-Oabbc)*( Rab-Rbc+Oabbc)*( Rbc+Oabbc-Rab))/ (2*Oabbc);%%%�ҳ���һ��
             L=R-sqrt(R^2-x1^2);
             if Rbc<Rab  %%%��ù�����Rab�ģ���ʱ��Ҫ�� rbc �Ĺ��ߡ�
                L12=(d/2+d1-L)^2;
             else
                L12=(d/2+L)^2;
             end
             error1=sqrt(x1^2+L12)-d/2;
             if error>error1
                error=error1/2;
             end     
         else %Rflag1<0 
             d1=Rab+Rbc-Oabbc;
             d=2*Rbc-d1;
             x1=sqrt(( Rab+Rbc+Oabbc)*(Rab+Rbc-Oabbc)*( Rab-Rbc+Oabbc)*( Rbc+Oabbc-Rab))/ (2*Oabbc);%%%�ҳ���һ��
             L=R-sqrt(R^2-x1^2);
             if Rab<Rbc
                L12=(d/2+d1-L)^2;
             else
                L12=(d/2+L)^2;
             end
            % L12=(d/2+L)^2;
             error1=sqrt(x1^2+L12)-d/2;
             if error>error1
                error=error1/2;
             end 
             
             
         end
    end
else
    if dot>0 %%%ͬ������
       if Rab>Rbc
           Rflag1=-1;
           Rflag2=1;
           error1=2*Rbc;
             if error>error1
                error=error1/2;
             end 
       elseif  Rab<Rbc
           Rflag1=1;
           Rflag2=-1;
           error1=2*Rab;
             if error>error1
                error=error1/2;
             end 
       else 
           return;
       end           
    elseif dot<0
        Rflag1=1;
        Rflag2=1;  
        error1=2*Rab*Rbc/(Rab+Rbc);  %%%%�������
             if error>error1
                error=error1/2;
             end 
    end    
end
%%%%%%�ⷽ����
%%%%%%(x-Oab(1,1))^2+(y-Oab(1,2))^2=(Rab+Rflag1*r)^2
%%%%%%(x-Obc(1,1))^2+(y-Obc(1,2))^2=(Rbc+Rflag2*r)^2
%%%%%%(x-x2)^2+(y-y2)^2=(r+error)^2;  ����ax +by +c=dr
a0=Oab(1,1)-Obc(1,1);
b0=Oab(1,2)-Obc(1,2);
c0=0.5*(Obc(1,1)^2+Obc(1,2)^2-Oab(1,1)^2-Oab(1,2)^2+Rab^2-Rbc^2);
d0=Rbc*Rflag2-Rab*Rflag1;

a1=Oab(1,1)-B(1,1);
b1=Oab(1,2)-B(1,2);
c1=0.5*(B(1,1)^2+B(1,2)^2-Oab(1,1)^2-Oab(1,2)^2+Rab^2-error^2);
d1=error-Rab*Rflag1;

W=B;
Z=error;

%%%�Ƚⷽ��  a0*x+b0*y+c0=d0*r
%%%%%%%%%%%%a1*x+b1*y+c1=d1*r
[x y r]=solvefunction(a0,b0,c0,d0,a1,b1,c1,d1,W,Z)

  %%%%%%ȡ��ֵr;
    if r(1)<=0&&r(2)>0
        radius=r(2);
        %%%%%%%%%%
        Ot(1)=x(2);
        Ot(2)=y(2);
    elseif r(1)>0&&r(2)<=0
        radius=r(1);
         %%%%%%%%%%
        Ot(1)=x(1);
        Ot(2)=y(1);
    elseif r(1)>0&&r(2)>0
         %%%%ֱ��Oab��Obc����Ϊ
       P1=B-Vector_tanoabB;
       Pflag=(Obc(1,2)-Oab(1,2))*(P1(1,1)-Oab(1,1))-(Obc(1,1)-Oab(1,1))*(P1(1,2)-Oab(1,2));
       Pflag1=(Obc(1,2)-Oab(1,2))*(x(1)-Oab(1,1))-(Obc(1,1)-Oab(1,1))*(y(1)-Oab(1,2));
       Pflag2=(Obc(1,2)-Oab(1,2))*(x(2)-Oab(1,1))-(Obc(1,1)-Oab(1,1))*(y(2)-Oab(1,2));
       if Pflag1*Pflag>0
           radius=r(1);
           Ot(1)=x(1);
           Ot(2)=y(1);
       else
           radius=r(2);
           Ot(1)=x(2);
           Ot(2)=y(2);
       end
    else
        return;
    end  
    pnt_start=[];
    pnt_end=[];
    Ot(3)=0;
    %Բ���������
    OOab=norm(Ot(1,:)-Oab(1,:));
    lamda = Rab / OOab;
    pnt_start(1) = (1-lamda)*Oab(1) + lamda*Ot(1);
    pnt_start(2) = (1-lamda)*Oab(2) + lamda*Ot(2);
    pnt_start(3) = (1-lamda)*Oab(3) + lamda*Ot(3);   
   

    %%//Բ���յ�����
    OObc=norm(Ot(1,:)-Obc(1,:));
    lamda = Rbc / OObc;
    pnt_end(1) = (1-lamda)*Obc(1) + lamda*Ot(1);
    pnt_end(2) = (1-lamda)*Obc(2) + lamda*Ot(2);
    pnt_end(3) = (1-lamda)*Obc(3) + lamda*Ot(3);
    
    
    %%Բ�Ľ��ж�  
       %%%%%��Բ�Ľ�
       vec_start(1)= A(1)-Oab(1);
       vec_start(2)= A(2)-Oab(2);
       vec_start(3)= A(3)-Oab(3);
       norm_start=norm(vec_start);
       vec_start(1)=vec_start(1)/ norm_start;
       vec_start(2)=vec_start(2)/norm_start;
       vec_start(3)=vec_start(3)/ norm_start;
       vec_end(1)= B(1)-Oab(1);
       vec_end(2)= B(2)-Oab(2); 
       vec_end(3)= B(3)-Oab(3); 
       norm_end=norm(vec_end);
       vec_end(1)= vec_end(1)/ norm_end;
       vec_end(2)= vec_end(2)/ norm_end;
       vec_end(3)= vec_end(3)/ norm_end;
   %%%%%%%
       Crossprod(1)= vec_start(2)*vec_end(3)-vec_start(3)*vec_end(2);
       Crossprod(2)= -vec_start(1)*vec_end(3)+vec_start(3)*vec_end(1);
       Crossprod(3)= vec_start(1)*vec_end(2)-vec_start(2)*vec_end(1); 
       sum=Crossprod(1)+Crossprod(2)+Crossprod(3);
       %%%%�нǶ���  0~180
       dot=vec_start(1)*vec_end(1)+vec_start(2)*vec_end(2)
       theta=acos(dot);
       if sum==0
           if theta>0
               res=0;
           else
               res=pi;
           end
       elseif sum>0
           if circle_clockwiseAB==0
               res=theta;
           else
               res=2*pi-theta;
           end
       elseif sum<0
           if circle_clockwiseAB==1
               res=theta;
           else
               res=2*pi-theta;
           end
       end
       %%%%%%%%%%%%%%%%%%%%%%%%
       theta1=res; %%%��AB�Ƕ� 
       
      %%%%%%%%%%%%%%%%%%%%%%%%
   %%%%%��Բ�Ľ�
       vec_start(1)= pnt_start(1)-Oab(1);
       vec_start(2)= pnt_start(2)-Oab(2);
       vec_start(3)= pnt_start(3)-Oab(3);
       norm_start=norm(vec_start);
       vec_start(1)=vec_start(1)/ norm_start;
       vec_start(2)=vec_start(2)/norm_start;
       vec_start(3)=vec_start(3)/ norm_start;
       vec_end(1)= B(1)-Oab(1);
       vec_end(2)= B(2)-Oab(2); 
       vec_end(3)= B(3)-Oab(3); 
       norm_end=norm(vec_end);
       vec_end(1)= vec_end(1)/ norm_end;
       vec_end(2)= vec_end(2)/ norm_end;
       vec_end(3)= vec_end(3)/ norm_end;
   %%%%%%%
       Crossprod(1)= vec_start(2)*vec_end(3)-vec_start(3)*vec_end(2);
       Crossprod(2)= -vec_start(1)*vec_end(3)+vec_start(3)*vec_end(1);
       Crossprod(3)= vec_start(1)*vec_end(2)-vec_start(2)*vec_end(1); 
       sum=Crossprod(1)+Crossprod(2)+Crossprod(3);
       %%%%�нǶ���  0~180
       dot=vec_start(1)*vec_end(1)+vec_start(2)*vec_end(2)
       theta=acos(dot);
       if sum==0
           if theta>0
               res=0;
           else
               res=pi;
           end
       elseif sum>0
           if circle_clockwiseAB==0
               res=theta;
           else
               res=2*pi-theta;
           end
       elseif sum<0
           if circle_clockwiseAB==1
               res=theta;
           else
               res=2*pi-theta;
           end
       end
      %%%%%%%%%%%%%%%%%%%%%%%%
      theta2=res;%%%�е㵽B�Ļ��Ƕȴ�С
      %%%%%%%%%%%%%%%%%%%%%%%%
      if theta2>theta1
          tag1=0;
      else
          tag1=1;
      end
      
      %%%%%%%%%%%%%%%%%%%%%%%%
      
      %%%%%��Բ�Ľ�
       vec_start(1)= B(1)-Obc(1);
       vec_start(2)= B(2)-Obc(2);
       vec_start(3)= B(3)-Obc(3);
       norm_start=norm(vec_start);
       vec_start(1)=vec_start(1)/ norm_start;
       vec_start(2)=vec_start(2)/norm_start;
       vec_start(3)=vec_start(3)/ norm_start;
       vec_end(1)= C(1)-Obc(1);
       vec_end(2)= C(2)-Obc(2); 
       vec_end(3)= C(3)-Obc(3); 
       norm_end=norm(vec_end);
       vec_end(1)= vec_end(1)/ norm_end;
       vec_end(2)= vec_end(2)/ norm_end;
       vec_end(3)= vec_end(3)/ norm_end;
   %%%%%%%
       Crossprod(1)= vec_start(2)*vec_end(3)-vec_start(3)*vec_end(2);
       Crossprod(2)= -vec_start(1)*vec_end(3)+vec_start(3)*vec_end(1);
       Crossprod(3)= vec_start(1)*vec_end(2)-vec_start(2)*vec_end(1); 
       sum=Crossprod(1)+Crossprod(2)+Crossprod(3);
       %%%%�нǶ���  0~180
       dot=vec_start(1)*vec_end(1)+vec_start(2)*vec_end(2)
       theta=acos(dot);
       if sum==0
           if theta>0
               res1=0;
           else
               res1=pi;
           end
       elseif sum>0
           if circle_clockwiseBC==0
               res1=theta;
           else
               res1=2*pi-theta;
           end
       elseif sum<0
           if circle_clockwiseBC==1
               res1=theta;
           else
               res1=2*pi-theta;
           end
       end
      %%%%%%%%%%%%%%%%%%%%%%%%; 
      theta3=res1;%theta3��BC���ĽǶ� 
      %%%%%%%%%%%%%%%%%%%%%%%%%%%
      %%%%%��Բ�Ľ�
       vec_start(1)= B(1)-Obc(1);
       vec_start(2)= B(2)-Obc(2);
       vec_start(3)= B(3)-Obc(3);
       norm_start=norm(vec_start);
       vec_start(1)=vec_start(1)/ norm_start;
       vec_start(2)=vec_start(2)/norm_start;
       vec_start(3)=vec_start(3)/ norm_start;
       vec_end(1)= pnt_end(1)-Obc(1);
       vec_end(2)= pnt_end(2)-Obc(2); 
       vec_end(3)= pnt_end(3)-Obc(3); 
       norm_end=norm(vec_end);
       vec_end(1)= vec_end(1)/ norm_end;
       vec_end(2)= vec_end(2)/ norm_end;
       vec_end(3)= vec_end(3)/ norm_end;
   %%%%%%%
       Crossprod(1)= vec_start(2)*vec_end(3)-vec_start(3)*vec_end(2);
       Crossprod(2)= -vec_start(1)*vec_end(3)+vec_start(3)*vec_end(1);
       Crossprod(3)= vec_start(1)*vec_end(2)-vec_start(2)*vec_end(1); 
       sum=Crossprod(1)+Crossprod(2)+Crossprod(3);
       %%%%�нǶ���  0~180
       dot=vec_start(1)*vec_end(1)+vec_start(2)*vec_end(2)
       theta=acos(dot);
       if sum==0
           if theta>0
               res1=0;
           else
               res1=pi;
           end
       elseif sum>0
           if circle_clockwiseBC==0
               res1=theta;
           else
               res1=2*pi-theta;
           end
       elseif sum<0
           if circle_clockwiseBC==1
               res1=theta;
           else
               res1=2*pi-theta;
           end
       end
      %%%%%%%%%%%%%%%%%%%%%%%%; 
      theta4=res1; %%%��B���е�ĽǶ�
      %%%%%%%%%%%%%%%%%%%%%%%%%
      if theta4<=theta3/2
          tag2=1;%%%%��ǰ1/2Բ��
      else
          tag2=0;
      end 
    
      if tag1*tag2==0
         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         if tag1==0 && tag2~=0
         %%%%%%���2 ��ԲBCǰ1/2Բ��,����ԲAB��
         %%(x-x1)��Oab(2)-y1��-��y-y1��(Oab(1)-x1)=0;	 (1)
         %%(x-Ox1)^2+(y-Oy1)^2=(r+Rflag1*Rab)^2;         (2)
         %%(x-Ox2)^2+(y-Oy2)^2=(r+Rflag2*Rbc)^2;         (3)
 
        a1=(Oab(1)-Obc(1));
        b1=(Oab(2)-Obc(2));
        c1=0.5*(Obc(1)^2+Obc(2)^2-Oab(1)^2-Oab(2)^2+Rab^2-Rbc^2);
        d1=Rbc*Rflag2-Rab*Rflag1;

        a0=(Oab(2)-A(1,2));
        b0=-1*(Oab(1)-A(1,1));
        c0=A(1,2)*Oab(1)-A(1,1)*Oab(2);
        d0=0;
        
        W=Obc;
        Z=Rflag2*Rbc;
        [x y r]=solvefunction(a0,b0,c0,d0,a1,b1,c1,d1,W,Z) 
        
          %%%%%%ȡ��ֵr;
            if r(1)<=0&&r(2)>0
                radius=r(2);
                %%%%%%%%%%
                Ot(1)=x(2);
                Ot(2)=y(2);
            elseif r(1)>0&&r(2)<=0
                radius=r(1);
                 %%%%%%%%%%
                Ot(1)=x(1);
                Ot(2)=y(1);
            elseif r(1)>0&&r(2)>0
                 %%%%ֱ��Oab��Obc����Ϊ
               P1=B-Vector_tanoabB;
               Pflag=(Obc(1,2)-Oab(1,2))*(P1(1,1)-Oab(1,1))-(Obc(1,1)-Oab(1,1))*(P1(1,2)-Oab(1,2));
               Pflag1=(Obc(1,2)-Oab(1,2))*(x(1)-Oab(1,1))-(Obc(1,1)-Oab(1,1))*(y(1)-Oab(1,2));
               Pflag2=(Obc(1,2)-Oab(1,2))*(x(2)-Oab(1,1))-(Obc(1,1)-Oab(1,1))*(y(2)-Oab(1,2));
               if Pflag1*Pflag>0
                   radius=r(1);
                   Ot(1)=x(1);
                   Ot(2)=y(1);
               else
                   radius=r(2);
                   Ot(1)=x(2);
                   Ot(2)=y(2);
               end
            else
                return;
            end  
            %Բ���������
            pnt_start=A;
            pnt_end=[];
            %%//Բ���յ�����
            OObc=norm(Ot(1,:)-Obc(1,:));
            lamda = Rbc / OObc;
            pnt_end(1) = (1-lamda)*Obc(1) + lamda*Ot(1);
            pnt_end(2) = (1-lamda)*Obc(2) + lamda*Ot(2);
            pnt_end(3) = (1-lamda)*Obc(3) + lamda*Ot(3);  
            
            
         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
         elseif tag1~=0 && tag2==0
         %%%%%  ��Բ�����е�  Բ���е�   %%%%%%%%%%%%%%%%%%%%%%%%%%%
         %%%%%%���3 ����ԲBC��ǰ1/2Բ��,��Բ��AB��
         middle=[];
         %��ת����仯���е㣬Բ�Ľ���֪��res1����ObcB��ת res1/2�ĽǶȡ���
         vecOB(1)=B(1)-Obc(1);
         vecOB(2)=B(2)-Obc(2);
         vecOB(3)=B(3)-Obc(3);
         if circle_clockwiseBC==0  %%%%��ʱ��
            middle(1)=cos(theta3/2)*vecOB(1)+(-1)*sin(theta3/2)*vecOB(2)+Obc(1);
            middle(2)=sin(theta3/2)*vecOB(1)+cos(theta3/2)*vecOB(2)+Obc(2);  
         else  %%%%˳ʱ��
            res1=(-1)*res1; 
            middle(1)=cos(theta3/2)*vecOB(1)+(-1)*sin(theta3/2)*vecOB(2)+Obc(1);
            middle(2)=sin(theta3/2)*vecOB(1)+cos(theta3/2)*vecOB(2)+Obc(2); 
         end
         middle(3)= 0;
         %%(x-middle(1))��Obc(2)-middle(2)��-��y-middle(2)��(Obc(1)-middle(1))=0;   (1)
         %%(x-Ox1)^2+(y-Oy1)^2=(r+Rflag1*Rab)^2;         (2)
         %%(x-Ox2)^2+(y-Oy2)^2=(r+Rflag2*Rbc)^2;         (3)
 
         
        a1=(Oab(1)-Obc(1));
        b1=(Oab(2)-Obc(2));
        c1=0.5*(Obc(1)^2+Obc(2)^2-Oab(1)^2-Oab(2)^2+Rab^2-Rbc^2);
        d1=Rbc*Rflag2-Rab*Rflag1;

        a0=(Obc(2)-middle(2));
        b0=(middle(1)-Obc(1));
        c0=Obc(1)*middle(2)-Obc(2)*middle(1);
        d0=0;
        
        W=Obc;
        Z=Rflag2*Rbc;
        
        [x y r]=solvefunction(a0,b0,c0,d0,a1,b1,c1,d1,W,Z) 
        
         %%%%%%ȡ��ֵr;
            if r(1)<=0&&r(2)>0
                radius=r(2);
                %%%%%%%%%%
                Ot(1)=x(2);
                Ot(2)=y(2);
            elseif r(1)>0&&r(2)<=0
                radius=r(1);
                 %%%%%%%%%%
                Ot(1)=x(1);
                Ot(2)=y(1);
            elseif r(1)>0&&r(2)>0
                 %%%%ֱ��Oab��Obc����Ϊ
               P1=B-Vector_tanoabB;
               Pflag=(Obc(1,2)-Oab(1,2))*(P1(1,1)-Oab(1,1))-(Obc(1,1)-Oab(1,1))*(P1(1,2)-Oab(1,2));
               Pflag1=(Obc(1,2)-Oab(1,2))*(x(1)-Oab(1,1))-(Obc(1,1)-Oab(1,1))*(y(1)-Oab(1,2));
               Pflag2=(Obc(1,2)-Oab(1,2))*(x(2)-Oab(1,1))-(Obc(1,1)-Oab(1,1))*(y(2)-Oab(1,2));
               if Pflag1*Pflag>0
                   radius=r(1);
                   Ot(1)=x(1);
                   Ot(2)=y(1);
               else
                   radius=r(2);
                   Ot(1)=x(2);
                   Ot(2)=y(2);
               end
            else
                return;
            end  
            %Բ���������
            pnt_start=[];
            pnt_end=middle;
            %%//Բ���յ�����
            OOab=norm(Ot(1,:)-Oab(1,:));
            lamda = Rab / OOab;
            pnt_start(1) = (1-lamda)*Oab(1) + lamda*Ot(1);
            pnt_start(2) = (1-lamda)*Oab(2) + lamda*Ot(2);
            pnt_start(3) = (1-lamda)*Oab(3) + lamda*Ot(3);  
         
         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         else  tag1==0 && tag2==0
         %%%%%%���4 ����ǰ1/2Բ��,����ֱ���� 
        
        %%%%%  ��Բ�����е�  Բ���е�   %%%%%%%%%%%%%%%%%%%%%%%%%%%
         %%%%%%���3 ����ԲBC��ǰ1/2Բ��,��Բ��AB��
         middle=[];
         vecOB(1)=B(1)-Obc(1);
         vecOB(2)=B(2)-Obc(2);
         vecOB(3)=B(3)-Obc(3);
         if circle_clockwiseBC==0  %%%%��ʱ��
            middle(1)=cos(theta3/2)*vecOB(1)+(-1)*sin(theta3/2)*vecOB(2)+Obc(1);
            middle(2)=sin(theta3/2)*vecOB(1)+cos(theta3/2)*vecOB(2)+Obc(2);  
         else  %%%%˳ʱ��
            res1=(-1)*res1; 
            middle(1)=cos(theta3/2)*vecOB(1)+(-1)*sin(theta3/2)*vecOB(2)+Obc(1);
            middle(2)=sin(theta3/2)*vecOB(1)+cos(theta3/2)*vecOB(2)+Obc(2); 
         end
         middle(3)= 0;
         
         %%%%%%% �󽻵㣬Բ��Obc��middle ֱ�ߺ͹�A-Oab  crossoverPoint  
         %%%%%%%%(x-middle(1))��Oy2-middle(2)��-��y-middle(2)��(Ox2-middle(1))=0;   (1)
         %%%%%%%%(x-x1)��Oy1-y1��-��y-y1��(Ox1-x1)=0; (2)
         crossoverPoint=[];
          a1=(Oab(1,2)-A(1,2));
          b1=-1*(Oab(1,1)-A(1,1));
          c1=Oab(1,1)*A(1,2)-Oab(1,2)*A(1,1);
        
          a0=(Obc(1,2)-middle(2));
          b0=-1*(Obc(1,1)-middle(1));
          c0=-1*middle(1)*Obc(1,2)+middle(2)*Obc(1,1);
         
          if a0*b1-a1*b0==0
              return;
          end
           crossoverPoint(2)=-1*(a1*c0-a0*c1)/(a1*b0-a0*b1);
          if a0~=0
           crossoverPoint(1)=-1*(b0*crossoverPoint(2)+c0)/a0;
          elseif a1~=0
           crossoverPoint(1)=-1*(b1*crossoverPoint(2)+c1)/a1;  
          else
              return;
          end
           crossoverPoint(3)=0;
         %%%%%%%%%%%%%%%%%%%�����������  crossoverPoint  �ж�crossoverPoint-A���Ⱥ�crossoverPoint-middle����
         ll1=norm(crossoverPoint-A);
         ll2=norm(crossoverPoint-middle);
         if ll1>ll2
           %%%%���2
         %%%%%%���2 ��ԲBCǰ1/2Բ��,����ԲAB��
         %%(x-x1)��Oab(2)-y1��-��y-y1��(Oab(1)-x1)=0;	 (1)
         %%(x-Ox1)^2+(y-Oy1)^2=(r+Rflag1*Rab)^2;         (2)
         %%(x-Ox2)^2+(y-Oy2)^2=(r+Rflag2*Rbc)^2;         (3)
 
        a1=(Oab(1)-Obc(1));
        b1=(Oab(2)-Obc(2));
        c1=0.5*(Obc(1)^2+Obc(2)^2-Oab(1)^2-Oab(2)^2+Rab^2-Rbc^2);
        d1=Rbc*Rflag2-Rab*Rflag1;

        a0=(Oab(2)-A(1,2));
        b0=-1*(Oab(1)-A(1,1));
        c0=A(1,2)*Oab(1)-A(1,1)*Oab(2);
        d0=0;
        
        W=Obc;
        Z=Rflag2*Rbc;
        [x y r]=solvefunction(a0,b0,c0,d0,a1,b1,c1,d1,W,Z) 
        
          %%%%%%ȡ��ֵr;
            if r(1)<=0&&r(2)>0
                radius=r(2);
                %%%%%%%%%%
                Ot(1)=x(2);
                Ot(2)=y(2);
            elseif r(1)>0&&r(2)<=0
                radius=r(1);
                 %%%%%%%%%%
                Ot(1)=x(1);
                Ot(2)=y(1);
            elseif r(1)>0&&r(2)>0
                 %%%%ֱ��Oab��Obc����Ϊ
               P1=B-Vector_tanoabB;
               Pflag=(Obc(1,2)-Oab(1,2))*(P1(1,1)-Oab(1,1))-(Obc(1,1)-Oab(1,1))*(P1(1,2)-Oab(1,2));
               Pflag1=(Obc(1,2)-Oab(1,2))*(x(1)-Oab(1,1))-(Obc(1,1)-Oab(1,1))*(y(1)-Oab(1,2));
               Pflag2=(Obc(1,2)-Oab(1,2))*(x(2)-Oab(1,1))-(Obc(1,1)-Oab(1,1))*(y(2)-Oab(1,2));
               if Pflag1*Pflag>0
                   radius=r(1);
                   Ot(1)=x(1);
                   Ot(2)=y(1);
               else
                   radius=r(2);
                   Ot(1)=x(2);
                   Ot(2)=y(2);
               end
            else
                return;
            end  
            %Բ���������
            pnt_start=A;
            pnt_end=[];
            %%//Բ���յ�����
            OObc=norm(Ot(1,:)-Obc(1,:));
            lamda = Rbc / OObc;
            pnt_end(1) = (1-lamda)*Obc(1) + lamda*Ot(1);
            pnt_end(2) = (1-lamda)*Obc(2) + lamda*Ot(2);
            pnt_end(3) = (1-lamda)*Obc(3) + lamda*Ot(3);  
             
             
             
         else
             %%%���3
                 %%(x-middle(1))��Obc(2)-middle(2)��-��y-middle(2)��(Obc(1)-middle(1))=0;   (1)
                 %%(x-Ox1)^2+(y-Oy1)^2=(r+Rflag1*Rab)^2;         (2)
                 %%(x-Ox2)^2+(y-Oy2)^2=(r+Rflag2*Rbc)^2;         (3)         
                 a1=(Oab(1)-Obc(1));
                 b1=(Oab(2)-Obc(2));
                 c1=0.5*(Obc(1)^2+Obc(2)^2-Oab(1)^2-Oab(2)^2+Rab^2-Rbc^2);
                 d1=Rbc*Rflag2-Rab*Rflag1;

                a0=(Obc(2)-middle(2));
                b0=(middle(2)-Obc(1));
                c0=Obc(1)*middle(2)-Obc(2)*middle(1);
                d0=0;

                W=Obc;
                Z=Rflag2*Rbc;

                [x y r]=solvefunction(a0,b0,c0,d0,a1,b1,c1,d1,W,Z) 

                 %%%%%%ȡ��ֵr;
                    if r(1)<=0&&r(2)>0
                        radius=r(2);
                        %%%%%%%%%%
                        Ot(1)=x(2);
                        Ot(2)=y(2);
                    elseif r(1)>0&&r(2)<=0
                        radius=r(1);
                         %%%%%%%%%%
                        Ot(1)=x(1);
                        Ot(2)=y(1);
                    elseif r(1)>0&&r(2)>0
                         %%%%ֱ��Oab��Obc����Ϊ
                       P1=B-Vector_tanoabB;
                       Pflag=(Obc(1,2)-Oab(1,2))*(P1(1,1)-Oab(1,1))-(Obc(1,1)-Oab(1,1))*(P1(1,2)-Oab(1,2));
                       Pflag1=(Obc(1,2)-Oab(1,2))*(x(1)-Oab(1,1))-(Obc(1,1)-Oab(1,1))*(y(1)-Oab(1,2));
                       Pflag2=(Obc(1,2)-Oab(1,2))*(x(2)-Oab(1,1))-(Obc(1,1)-Oab(1,1))*(y(2)-Oab(1,2));
                       if Pflag1*Pflag>0
                           radius=r(1);
                           Ot(1)=x(1);
                           Ot(2)=y(1);
                       else
                           radius=r(2);
                           Ot(1)=x(2);
                           Ot(2)=y(2);
                       end
                    else
                        return;
                    end  
                    %Բ���������
                    pnt_start=[];
                    pnt_end=middle;
                    %%//Բ���յ�����
                    OOab=norm(Ot(1,:)-Oab(1,:));
                    lamda = Rab / OOab;
                    pnt_start(1) = (1-lamda)*Oab(1) + lamda*Ot(1);
                    pnt_start(2) = (1-lamda)*Oab(2) + lamda*Ot(2);
                    pnt_start(3) = (1-lamda)*Oab(3) + lamda*Ot(3);  
             
             
         end       
          
        end 
         
      else 
          %%%%%���1���������������%%%%%
      end
    
error1=error;
end