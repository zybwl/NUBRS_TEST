function [sys,x0,str,ts] = jiaodu2(t,x,u,flag)
switch flag,
    case 0,
        [sys,x0,str,ts]=mdlInitializeSizes;
    case 2,
        sys=mdlUpdate(t,x,u);
    case 3,
        sys=mdlOutputs(t,x,u);
    case {1,4,9},
        sys=[];
    otherwise
        error(['Unhandled flag = ',num2str(flag)]);
end

function [sys,x0,str,ts]=mdlInitializeSizes
global rotateangle Angle A1 dA;
rotateangle=0;Angle=0;A1=0; dA=0;
sizes = simsizes;
sizes.NumContStates  = 0;
sizes.NumDiscStates  = 2;
sizes.NumOutputs     = 2;
sizes.NumInputs      = 2;
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 1;   % at least one sample time is needed
sys = simsizes(sizes);
x0  = [0 0];
str = [];
ts  = [0.1 0];

function sys=mdlUpdate(t,x,u)
global rotateangle Angle A1 dA;
ZT_A=u(1);
zt_v=u(2);

dA=ZT_A-A1;
if dA>300
    dA=dA-360;
elseif dA<-300
    dA=360+dA
end
A1=ZT_A;
Angle=Angle+dA;
x(2)=u(2);
% if Angle>=360 && zt_v>0
%     Angle=360;
%     x(2)=0;
% elseif Angle<=-360 && zt_v<0
%     Angle=-360;
%     x(2)=0;
% end
x(1)=Angle;
% rotateangle=u(1);
sys =x;
% if zt_v>0      
%     if ZT_A>=0 && Angle>=0
%         x(1)=ZT_A;
%     elseif ZT_A>=0&& Angle<0
%         x(1)=ZT_A-360;
%         if x(1)==-360
%             x(1)=0;
%         end
%     elseif ZT_A<=0&& Angle>=0
%         x(1)=360+ZT_A;
%         if x(1)==360
%             x(1)=360;
%         end
%     elseif ZT_A<=0&& Angle<0
%         x(1)=ZT_A;
%     end
% elseif zt_v<0
%     if ZT_A<=0 && Angle<=0
%         x(1)=ZT_A;
%     elseif ZT_A<=0&& Angle>0
%         x(1)=360+ZT_A;
%         if x(1)==360
%             x(1)=0;
%         end
%     elseif ZT_A>=0 && Angle<=0
%         x(1)=ZT_A-360;
%         if x(1)==-360
%             x(1)=0;
%         end
%     elseif ZT_A>=0 && Angle>0
%         x(1)=ZT_A;
%     end
% end
% Angle=Angle+da;
% x(1)=Angle;
% % rotateangle=u(1);
% x(2)=u(2);
% sys =x;

function sys=mdlOutputs(t,x,u)

sys = x;
