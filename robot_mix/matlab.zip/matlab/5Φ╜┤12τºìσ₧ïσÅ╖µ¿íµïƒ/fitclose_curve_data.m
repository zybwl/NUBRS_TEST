clc;clear ;close all;
controls_points = [ -19    -5
   -16     0
   -12     5
    -4     6
     6     3
    10     9
    20     5
    17    -7
     6    -7
     3   -13
    -5   -11
   -13    -8
   -19    -5
   -16     0
   -12     5];

kv = -3:15;

num_cpts = 12;
degree = 3;
ploy_n = 500;
index = 1;

for u = 0: 1/200: 12
    span = findspan(14 , degree , u ,kv );
    N  = basisfun( span , u ,degree ,kv );
    new_point(index,:) = N * controls_points(span - degree + 1 : span + 1 , :);
    index = index + 1;
end                                                                                                                                         

new_control_points = fitting_close_curve(new_point, num_cpts, degree);
plot(new_point(:,1),new_point(:,2),'-b'); 
hold on
plot(controls_points(:,1) + 1, controls_points(:,2)+ 1,'-r');
hold on
plot(new_control_points(:,1), new_control_points(:,2),'-g');

