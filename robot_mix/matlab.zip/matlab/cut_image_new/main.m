
close all;
clear; 
clc; 

load figure_array

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%���鿴ĳ�������ĸ�����
% f = imread('source.png');
% imshow(f)
% [x , y]=ginput(1);
% 
% cloth_index = 0;
% cloth_index_array = [];
% 
% for i = 1:length(x)
%     choose_point.x = x(i);
%     choose_point.y = 550 - y(i);
%     for j = 1:length(figure_array);  
%         result = isPolygonContainsPoint(figure_array(j), choose_point);
%         if result == 1
%              cloth_index_array = [cloth_index_array j];
%         end
%     end
% end
% 
% % ��֤ͼԪ���ҽ���һ�������ͼԪ������ͼ��������С��
% % �ҳ�����������С���ϣ�check_noΪ����ͼԪ��choose_noΪ��ѡ��Ҫ����ͼԪ
% % ֻ���һ���㣬�������Ҫ���������е�ͼԪ��Χ��������������ǣ�
% n = length(cloth_index_array);
% satisfy_figure_num = 0;
% if n > 1
%     for i = 1:n
%         choose_no = cloth_index_array(i);
%         choose_point.x = figure_array(choose_no).x(1);
%         choose_point.y = figure_array(choose_no).y(1);
%         satisfy_figure_num = 0;
%         for j = 1:n
%             if i == j
%                 %�Լ������Լ����ü��
%                 continue;
%             else
%                
%                 check_no = cloth_index_array(j);
%                 result = isPolygonContainsPoint(figure_array(check_no), choose_point);
%                 if result ~= 1
%                     break; 
%                 else
%                     satisfy_figure_num = satisfy_figure_num + 1; 
%                 end
%             end         
%         end
%         if satisfy_figure_num == n - 1
%             cloth_index = choose_no;
%             break;
%         end
%     end
% elseif n == 1
%     cloth_index = cloth_index_array(1);
% else
%     cloth_index = -1;
% end
% cloth_index
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%�������ͼԪ���
% area = zeros(1,length(figure_array));
% for i = 1:length(figure_array);  
%     area(i) = countPolygonArea(figure_array(i));
% end
% area

% % �ж�ͼԪ��˳ʱ��ü�������ʱ��ü�
% %clock_wise = area > 0;
% clock_wise = zeros(1,length(area));
% for i = 1:length(area); 
%     if area(i)>0
%         clock_wise(i) = 1;
%     else
%         clock_wise(i) = 0;
%     end
% end
% % 
% % %������������ߵļн�
% % point1.x = 0;
% % point1.y = 0;
% % point2.x = 2;
% % point2.y = 0;
% % point3.x = 4;
% % point3.y = 2;
% % angle1 = twoLineAngle(point1, point2, point3);
% % angle2 = twoLineAngle(point3, point2, point1);
% % 
% % �жϹ���

% cut_axis_array = [0];
% cut_flag = 1;
% cut_axis_value = 250;
%  
% for i = 1:length(figure_array);  
%    one_axis_array  = cutClothWithXY(figure_array(i), cut_axis_value, cut_flag);
%     if isempty(one_axis_array) == 0
%          cut_axis_array = [cut_axis_array ,one_axis_array];
%     end
% end
% cut_axis_array = [cut_axis_array 600];
% cut_axis_array = sort(cut_axis_array);
% 
% for i = 1:length(figure_array)
%     plot(figure_array(i).x ,figure_array(i).y);
%     hold on
% end
% 
% for i = 1:2:length(cut_axis_array)-1   
%     if cut_flag == 0
%          plot([cut_axis_array(i) cut_axis_array(i+1)] ,[cut_axis_value cut_axis_value],'r');
%     else
%         plot([cut_axis_value cut_axis_value],[cut_axis_array(i) cut_axis_array(i+1)] ,'r');
%     end    
%     hold on
% end

%%10��	Բ����ͼԪ����

%%%
% ˵���� 
% Բ���ĽǶȲҪ����360��
% Բ���ķ�Χ��Ҫ��-360 --- 360 ֮��
%%%
circle.r = 70;
circle.x = 230;
circle.y = 350;
circle.ang1 = 110;
circle.ang2 = -220;

abs_angle = abs(circle.ang1 - circle.ang2);
if abs_angle >360
     return
end

for i = 1:length(figure_array)
    plot(figure_array(i).x ,figure_array(i).y);
    hold on
end
    
if circle.ang1 < circle.ang2
    ang = circle.ang1:circle.ang2;
else
    ang = circle.ang2:circle.ang1;
end
circle_x = circle.x + circle.r * cos(pi*ang/180);
circle_y = circle.y + circle.r * sin(pi*ang/180);    
plot(circle_x,circle_y ,'r');
hold on

plot(circle.x,circle.y ,'*g');

cross_point = [];
for i = 1:length(figure_array);  
   temp_cross_point  =  circleCross(figure_array(i), circle);
   cross_point = [cross_point; temp_cross_point]; 
end
if isempty(cross_point)
   return;        
end
 %ȥ������ĵ㣬�������������ĵ��������
%�Ƕ���С��������
relative_angle = [];
if circle.ang2 > circle.ang1
    zero_vect_x =  circle.r * cos(pi*circle.ang1/180);
    zero_vect_y =  circle.r * sin(pi*circle.ang1/180);
else
    zero_vect_x = circle.r * cos(pi*circle.ang2/180);
    zero_vect_y = circle.r * sin(pi*circle.ang2/180);
end

for i = 1:length(cross_point(:,1))
    new_coodinate_x = cross_point(i,1) - circle.x;
    new_coodinate_y = cross_point(i,2) - circle.y; 
    
    new_x = (new_coodinate_x * zero_vect_x + new_coodinate_y * zero_vect_y);
    new_y = (new_coodinate_y * zero_vect_x - new_coodinate_x * zero_vect_y);
    costheta = acos(new_x / sqrt(new_x^2 + new_y^2))*180/pi;
    if new_y < 0
        costheta = 360 - costheta;
    end
    
    if costheta <= abs_angle
        relative_angle = [relative_angle , costheta];
    end
end

angle = sort(relative_angle) ;
if circle.ang2 < circle.ang1
    %angle = fliplr(angle) ;
    %�ǶȰ���С��������
    angle = angle(end:-1:1) + circle.ang2;
else
    angle = angle + circle.ang1;
end
 
for i = 1:length(angle)
    circle_x = circle.x + circle.r * cos(pi*angle(i)/180);
    circle_y = circle.y + circle.r * sin(pi*angle(i)/180);    
    plot(circle_x,circle_y ,'*r');
    hold on
    pause(1)
end

axis equal 












    

