clc ;
clear;

DynamicInfo.t = [2,5,7,11,12,14,15];
DynamicInfo.F = [0,0,0,0,0,0,0];
DynamicInfo.L = [0,0,0,0,0,0,0];
DynamicInfo.Ja = 1;  
DynamicInfo.J = 1; 
DynamicInfo.acceleration = 2;
DynamicInfo.deceleration = 1; 
DynamicInfo.fs = 1; 
DynamicInfo.speed = 0;  
DynamicInfo.ls = 0;
DynamicInfo.l = 0;
index = 1;  
intp_time = 0.001;
%�Ƿ���Ҫ���ٶȺ;��������֤,�����ʽд��
%����΢���ֵķ�ʽ�����������߾Ͳ������غ�
DEBUG_FLAG = 1;

for current_time = 0:intp_time:15  
   DynamicInfo.current_time = current_time;
   acc(index) = Get_acc(DynamicInfo);
   
   DynamicInfo = GetSpeed(DynamicInfo);
   speed(index) = DynamicInfo.speed;
   
   DynamicInfo = GetDistance(DynamicInfo);
   l(index) = DynamicInfo.l;
   
   if(DEBUG_FLAG)
       if(index > 1)
            distance(index) = distance(index - 1) + speed(index) * intp_time;
            v(index) = v(index - 1) + acc(index) * intp_time;
       else
            distance(index) = DynamicInfo.l;
            v(index) = DynamicInfo.fs;
       end
   end
   
   index = index + 1;   
end

hold on
plot(0:intp_time:15,acc);
plot(0:intp_time:15, speed);
% plot(0:intp_time:15, l);

% if(DEBUG_FLAG)
%     plot(0:intp_time:15, distance);
%     plot(0:intp_time:15, v);
% end





    

  
    
    
    
    