clc;clear all;

%C_A����ģ�͵ĵ�һ��Բ���壬
r = 5; h = 2;
[x,y,z]=cylinder(r); 
z = h*z;    
surf(x,y,z,'FaceColor',[1,0,0]);      
daspect([1 1 1])                 
view(30,10)                   
hold on 

theta = linspace(0,2*pi,40) ;      
X=r*cos(theta);                    
Y=r*sin(theta);                     
Z=h*ones(size(X));                 
fill3(X,Y,Z,[1,0,0]);                 
fill3(X,Y,Z-h,[1,0,0]);    
hold on

%C_A����ģ�͵ĵڶ���Բ����
r = 1; h = 8;
[x,y,z]=cylinder(r); 
z = h*z;
%��y����ת90��
t = pi/2;
R=[cos(t) 0 sin(t);0 1 0;-sin(t) 0 cos(t)];

new_x = zeros(size(x));
new_y = zeros(size(y));
new_z = zeros(size(z));
for i = 1:2 
    new_coordinate = R*[x(i,:);y(i,:);z(i,:)];
    new_x(i,:) = new_coordinate(1,:);
    new_y(i,:) = new_coordinate(2,:);
    new_z(i,:) = new_coordinate(3,:);
end
surf(new_x,new_y,new_z,'FaceColor',[0,1,0]);  

theta = linspace(0,2*pi,40) ;      
X=[r*cos(theta);r*cos(theta)];                    
Y=[r*sin(theta); r*sin(theta)];                    
Z=[h*ones(size(theta));h*ones(size(theta))-h];  

for i = 1:2 
    new_coordinate = R*[X(i,:);Y(i,:);Z(i,:)];
    new_x = new_coordinate(1,:);
    new_y = new_coordinate(2,:);
    new_z = new_coordinate(3,:);
    fill3(new_x,new_y,new_z,[0,1,0]); 
end

%C_A����ģ�͵ĵ�����Բ����
r = 2.5; h = 8;
[x,y,z]=cylinder(r); 
z = h*z;
%��x����ת90��
% t = pi/2;
% R=[1 0 0;0 cos(t) -sin(t);0 sin(t) cos(t)];

new_x = zeros(size(x));
new_y = zeros(size(y));
new_z = zeros(size(z));
for i = 1:2 
    new_coordinate = R*[x(i,:);y(i,:);z(i,:)];
    new_x(i,:) = new_coordinate(1,:);
    new_y(i,:) = new_coordinate(2,:);
    new_z(i,:) = new_coordinate(3,:);
end
surf(new_x,new_y,new_z,'FaceColor',[0,1,0]);  

theta = linspace(0,2*pi,40) ;      
X=[r*cos(theta);r*cos(theta)];                    
Y=[r*sin(theta); r*sin(theta)];                    
Z=[h*ones(size(theta));h*ones(size(theta))-h];  

for i = 1:2 
    new_coordinate = R*[X(i,:);Y(i,:);Z(i,:)];
    new_x = new_coordinate(1,:);
    new_y = new_coordinate(2,:);
    new_z = new_coordinate(3,:);
    fill3(new_x,new_y,new_z,[0,1,0]); 
end                



% new_z = [zeros(size(X))- 1 ;zeros(size(X))];
% new_x = [zeros(size(X))-1 ; X];
% new_y = [zeros(size(X)) ; Y];
% surf(new_x,new_y,new_z,'FaceColor',[1,0,0]);