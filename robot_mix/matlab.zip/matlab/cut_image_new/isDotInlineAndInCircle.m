%�ж�һ��ֱ���ϵĵ��Ƿ�������
function result = isDotInline(pointA,pointB,pointC)
    vect1 = pointB - pointA;
    vect2 = pointC - pointB ;
    mulsum = sum(vect1.*vect2);
    
    if mulsum < 0      
        result = 0;
    else
        result = 1;
    end
    
%     vect2_x = pointB(1) - circle.x;
%     vect2_y = pointB(2) - circle.y;
%     costheta = vect2_x / sqrt(vect2_x^2 + vect2_y^2);
%     theta = acos( costheta ) * 180 /pi;
%     if vect2_y < 0  
%         theta = 360 - theta;
%     end       
%     
%     if (theta - circle.ang1) * (theta - circle.ang2) <=0;
%         result = 1;
%     end
    