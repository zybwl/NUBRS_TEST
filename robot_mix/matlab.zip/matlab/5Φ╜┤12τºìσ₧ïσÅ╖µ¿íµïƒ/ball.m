clc;clear all
r = 10;
x0=0;y0=0;z0=-r;
n = 20;
%�ο��Ǿ���B������2ҳ
%ֻ��һ����Բ
angleA = zeros(11,21);
angleC = zeros(11,21);
x1 = zeros(11,21);
y1 = zeros(11,21);
z1 = zeros(11,21);
for i = 1 : 11
    for j = 1: 21
        u = (i - 1) * pi / 20;
        v = (j - 1) * pi / 10;
        angleA(i,j) = u;
        angleC(i,j) = v;
        x1(i,j) = sin(u) * cos(v);
        y1(i,j) = sin(u)*sin(v);
        z1(i,j) = cos(u);
    end
end
% mesh(r*x1+x0,r*y1+y0,r*z1+z0);
% hold on
% axis equal

%�����Լ�AC���Ķ���
L = 6;
centerC = [3,2,L+1];
centerA = [0,1,L];
%���嵶�ĳ�ʼ��״
point = [centerA;0,0,L;0,0,0;0,2,L-4.5;0,2,L;centerA];
% all_point = [centerC;point];
% plot3(all_point(:,1),all_point(:,2),all_point(:,3));
% hold on

% ��ת����
% Rc = [cos(C) -sin(C) 0 0 ; sin(C) cos(C) 0 0 ; 0 0 1 0;0 0 0 1];
% Ra = [1 0 0 0 ; 0 cos(A) -sin(A) 0 ; 0 sin(A) cos(A) 0 ;0 0 0 1];
% Tm = [eye(3); T' ; zeros(1,3) 1]; 

% 
for i = 1 : 11
    for j = 1: 21
% for i = 11 : 11
%     for j = 11: 11
        A = angleA(i,j) ;
        C = angleC(i,j) + pi/2;
        ball_point = [r*x1(i,j)+x0, r*y1(i,j)+y0, r*z1(i,j)+z0];
        mesh(r*x1+x0,r*y1+y0,r*z1+z0);
        axis([-16,16,-16,16,-10,6]);
        
        hold on
%         axis equal
        for k = 1:6
            %A����任����ƽ�Ƶ�A����ϵ������ת
            T = zeros(1,3) - centerA;
            Ta = [eye(3) T' ; zeros(1,3) 1]; 
            Ra = [1 0 0 0 ; 0 cos(A) -sin(A) 0 ; 0 sin(A) cos(A) 0 ;0 0 0 1];
            %C����任
            T = centerA - centerC;
            Tc = [eye(3) T' ; zeros(1,3) 1]; 
            Rc = [cos(C) -sin(C) 0 0 ; sin(C) cos(C) 0 0 ; 0 0 1 0;0 0 0 1]; 
            %����ƽ�������ص�ԭ������ϵ
            T_end = [eye(3) centerC' ; zeros(1,3) 1];
            newpoint(k,:) = T_end * Rc * Tc * Ra * Ta * [point(k,:)';1];   
        end
        %�ѵ����ƶ���������ȥ
        T = ball_point - newpoint(3,1:3);
        T_ball = [eye(3) T' ; zeros(1,3) 1]; 
        final_point = [centerC 1;newpoint];
        final_point = T_ball * final_point';
        plot3(final_point(1,:),final_point(2,:),final_point(3,:));
        axis([-16,16,-16,16,-16,6]);
        hold off
        pause(0.1);
    end
    xlabel('ʱ��/s');
    pause(1);
end
        
        
% x0=-3;y0=-3;z0=-3;%����
% r=3;%�뾶
% [x,y,z]=sphere;
% mesh(r*x+x0,r*y+y0,r*z+z0);
% hold on
% axis equal
% 

% point = [0,0,0;0,0,-L;0,2,-L+3;0,2,0];
% all_point = [centerC;centerA;point;centerA];
% plot3(all_point(:,1),all_point(:,2),all_point(:,3));

