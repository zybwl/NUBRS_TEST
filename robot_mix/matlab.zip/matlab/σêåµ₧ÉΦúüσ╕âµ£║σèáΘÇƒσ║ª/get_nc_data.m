function [line_before, point_struct_array ,line_end] = get_nc_data(file_name , start_line_no, end_line_no)
% Full_name = 'NEW_FILE.NC.nc';
% start_line_no = 12;
% end_line_no = 92;
% start_line_no = 100;
% end_line_no = 327;

fid= fopen(file_name);
point = struct('X', 0.0, 'Y', 0.0,'Z',0.0,'A',0.0,'B',0.0,'C',0.0,'U',0.0,'V',0.0);
point_struct_array = [];
tline = fgetl(fid);
line_number = 0; 
line_before = '';
line_end = '';
while tline ~= -1
       
    line_number = line_number + 1  ;
    if line_number < start_line_no       
        %line_before = strcat(line_before , tline);    
        line_before = sprintf('%s\n%s',line_before,tline);
        tline = fgetl(fid);
        continue;
    elseif line_number > end_line_no
        %break;
        %line_end = strcat(line_end , tline);  
        line_end = sprintf('%s\n%s',line_end,tline);
        tline = fgetl(fid);
        break;
    end

    %expr = '[XYZABCUVF]-?[0-9]+\.?[0-9]*';
    %expr = '[XY]?[0-9]+\.?[0-9]*';
    %expr = '[XY][0-9]+\.?[0-9]*';
    expr = '[XYZ]-?[0-9]+.?[0-9]+';  %���ַ�ʽ����ֻҪ1�Σ�֮��ֿ�����
    %G01X0Y349.514Z239.447F10   %�㲻�ӷ�б�ܱ�ʾ����һ���ַ�   +����һ������ *����0������
    %https://blog.csdn.net/zjxiaolu/article/details/45132037
    search_result = regexp(tline,expr,'match');
    if isempty(search_result)
        tline = fgetl(fid);
        continue;
    end

    for k = 1:length(search_result)
        one_result = search_result{k};
        point.(one_result(1)) = str2double(one_result(2:end)); %��һ����ĸΪhash����key�������Ϊֵ
    end

    if end_line_no >= start_line_no && end_line_no <=end_line_no
        point_struct_array = [point_struct_array point];
    end           
    tline = fgetl(fid);
end

fclose(fid);