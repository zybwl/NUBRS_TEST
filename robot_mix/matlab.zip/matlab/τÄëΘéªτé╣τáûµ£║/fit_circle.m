clc;clear;close all;
t = 0: 2*pi/1000: 2*pi;
rand_r = 0.5;
points(:,1) = 5 + 10 * cos(t) + rand_r *rand(size(t)) - rand_r/2;
points(:,2) = 6 + 10 * sin(t) + rand_r *rand(size(t)) - rand_r/2;

% function p = fit_circle( points )
n = size(points,1);
x = points(:,1);
y = points(:,2);
sum_xxx = sum(x.^3);
sum_xxy = sum(x.^2 .* y);
sum_xyy = sum(x.* y.^2);
sum_yyy = sum(y.^3);
sum_xx = sum(x.^2);
sum_xy = sum(x.* y);
sum_yy = sum(y.^2);
sum_x = sum(x);
sum_y = sum(y);

D = n * sum_xy - sum_x * sum_y;
C = n * sum_xx- sum_x * sum_x;
E = n * sum_xxx + n * sum_xyy - (sum_xx + sum_yy)*sum_x;
G = n*sum_yy - sum_y * sum_y;
H = n*sum_yyy+n * sum_xxy-(sum_xx+sum_yy)*sum_y;

a = (H*D-E*G)/(C*G-D*D);
b = (H*C-E*D)/(D*D-G*C);
c = -((sum_xx + sum_yy)+ a * sum_x + b * sum_y)/n;

% A = [sum_xx     sum_xy   sum_x   
%      sum_xy     sum_yy   sum_y      
%      sum_x      sum_y    n  ];
% B = [ sum_xxx +  sum_xyy ;sum_xxy +  sum_yyy ;sum_xx + sum_yy];
% B = -B;
% C = inv(A)*B;

center_x = -0.5*a
center_y = -0.5*b
r = 0.5*sqrt(a*a+b*b-4*c)
   
x = center_x + r * cos(t);
y = center_y + r * sin(t);
plot(x,y, '-r' , points(:,1), points(:,2), '-b')
axis equal   
    
    