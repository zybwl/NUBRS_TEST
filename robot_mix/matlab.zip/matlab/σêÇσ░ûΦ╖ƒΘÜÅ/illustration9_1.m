% file_name = 'SIMULATION1.NC';
% start_line_no = 17;
% end_line_no = 5807;
% p = 3;
% ploy_n = 1000;
% [line_before, point_struct_array ,line_end] = get_nc_data(file_name,start_line_no,end_line_no);
% n = size(point_struct_array,2);
% U = zeros(1,n + 2*p);


% for k = 1:n
%     X = point_struct_array(k).X;
%     Y = point_struct_array(k).Y;
%     point(:,k) = [X;Y];
%     if k == 1
%         U(p + k) = 0;
%     else
%         vect = point(:,k) - point(:,k-1);
%         U(1,p + k) = U(1, p + k -1) + sqrt(vect'* vect);
%     end
% end

p = 3;
point = [0 3 -1 -4 -4;0 4 4 0 -3];
n = size(point,2);
U = zeros(1, n);
for k = 2:n
        vect = point(:,k) - point(:,k-1);
        U(1,k) = U(1,k -1) + sqrt(vect'* vect);
end
U  = U / U(1,n);

% U_ploy = zeros(1, n+p+1);
% for k = p+1: n-1
%     U_ploy(1,k+1) = sum(U(1,2:p+1))/p;
% end
% U_ploy(1,n+1:end) = 1;

U_ploy = zeros(1, n+p+1);
for k = 2: n-p
    U_ploy(1,k+p) = sum(U(1, k : k + p - 1))/p;
end
U_ploy(1,n+1:end) = 1;

A = zeros(n,n);
for k = 1:n
    span = findspan(n-1 , p , U(k) ,U_ploy);
    A(k , span - p + 1:span + 1) = basisfun(span, U(k),p,U_ploy) ;
end

P = A\point';
plot(point(1,:),point(2,:),'b');
hold on
%plot(P(:,1),P(:,2),'-ro');  

index = 1;
for u = 0:1/100:1
    span = findspan(n-1 , p , u ,U_ploy );
    N = basisfun(span,u,p,U_ploy);
    new_point(index,:) = N * P(span - p + 1 : span + 1, :);
    index = index + 1;
end
plot(new_point(:,1),new_point(:,2),'-ro'); 

% index = 1;
% for u = 0:1/ploy_n:1    
%     span = findspan(n , p , u ,U );
%     N = basisfun(span,u,p,U);   
%     new_point(:,index) = point(: , span - p + 1 : span + 1) * N';
%     if index >= ploy_n
%         break;
%     end
%     index = index + 1;
% end
%     
% plot(point(1,:),point(2,:),'b');
% hold on
% plot(new_point(1,:),new_point(2,:),'-ro');  


% for k =1: size(new_point,2)
%     plot3(new_point(1,1:k),new_point(2,1:k),new_point(3,1:k),'-ro');  
%     pause(0.5);
% end
% 
% point_n = size(new_point,2);
% for k = 1: point_n
%     if k == 1
%         line_middle = sprintf('G01X%-6.3fY%-6.3fZ%-6.3fA%-6.3fB%-6.3fC%-6.3fU%-6.3fV%-6.3fF%-5d' , ...
%                         new_point(1,1),new_point(2,1),new_point(3,1),point_struct_array(1).A,    ...
%                         point_struct_array(1).B,point_struct_array(1).C,point_struct_array(1).U,point_struct_array(1).V,point_struct_array(1).F); 
%     else
%         tline = sprintf('G01X%-6.3fY%-6.3fZ%-6.3fA%-6.3fB%-6.3fC%-6.3fU%-6.3fV%-6.3f' , ...
%                         new_point(1,k),new_point(2,k),new_point(3,k),point_struct_array(1).A,    ...
%                         point_struct_array(1).B,point_struct_array(1).C,point_struct_array(1).U,point_struct_array(1).V); 
%         line_middle = sprintf('%s\n%s',line_middle,tline);
%     end
% end        
%     
% file_head = strsplit(file_name,'.');
% new_file_name =  sprintf('%s%s%s', file_head{1,1}, num2str(randperm(1000,1)), '.nc');
% fid=fopen(new_file_name,'a');
% 
% fprintf(fid,'%s\n%s\n%s',line_before, line_middle ,line_end);
% fclose(fid);





     
     











