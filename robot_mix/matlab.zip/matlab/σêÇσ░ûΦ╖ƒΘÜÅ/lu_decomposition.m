function [matrix_l, matrix_u] = lu_decomposition(matrix_a)   

    [m,n] =size(matrix_a);
    if m~= n
        return ;
    end

    matrix_u = zeros(m,n);
    matrix_l = zeros(m,n);

    % Doolittle Method
    for i = 1:m 
        for k = i:m
            s = 0;
            for j = 1:i
                s = s + matrix_l(i,j) * matrix_u(j,k);
            end
            matrix_u(i,k) = matrix_a(i,k) - s;

            s = 0;
            if i == k
                matrix_l(i,i) = 1.0;
            else              
                for j = 1:i         
                     s  = s + matrix_l(k,j) * matrix_u(j,i);
                end
                matrix_l(k,i) = matrix_a(k,i) - s;

                if abs(matrix_u(i,i)) > 1e-5
                    matrix_l(k,i) = matrix_l(k,i)/matrix_u(i,i);
                else
                    matrix_l(k,i) = 0.0;
                end
             end
        end
    end