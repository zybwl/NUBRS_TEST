function  controls_points = fitting_close_curve1(points, num_cpts, degree)
% function  [new_point,controls_points] = fitting_close_curve(points, num_cpts, degree)

num_dpts = size(points,1);

%�ο����е�9.5-9.6ʽ��use_centripetal���������ҳ����������������Ĳ���������ڵ�ʸ��
use_centripetal = false;
uk = compute_params_curve(points, use_centripetal);
% uk = 0: num_cpts/(num_dpts - 1): num_cpts;

% kv_index_begin = -degree;
% kv_index_end = num_cpts + degree;
% kv = kv_index_begin : kv_index_end;

%������51�����ݣ�������30��������Ͽ��Ƶ�
% degree = 3;
%num_cpts = 100;
%kv = compute_knot_vector2(degree, num_dpts, 15 , uk);

%Compute matrix N
matrix_n = [];
for i = 1 : num_dpts  
    m_temp = zeros(1, num_cpts + degree);
    span = findspan(num_cpts + degree -1 , degree , uk(i) ,kv ); 
    N  = basisfun( span , uk(i) ,degree ,kv );
    for j = span - degree: span
        m_temp(j + 1) = N(j - span + degree + 1);        
    end
    matrix_n = [matrix_n ; m_temp];   
end

% Compute NT
matrix_nt = matrix_n';
% Compute NTN matrix
matrix_ntn = matrix_nt * matrix_n;

% LU-factorization
[matrix_l, matrix_u ] = lu_decomposition(matrix_ntn);

[m,n] = size(points);
vector_r = matrix_nt * points;
controls_points = zeros(num_cpts + degree , n);

for i = 1:n
    b = vector_r(:,i);
    y = forward_substitution(matrix_l, b);
    x = backward_substitution(matrix_u, y);
    controls_points(: ,i) = x;
end

% %plot3(controls_points(:,1), controls_points(:,2),controls_points(:,3),'.r');
% % hold on
% 
% %�ҳ���������λ�ã�����ǳ���
% % error = matrix_n * controls_points(2:end - 1,:) - rk ;
% % error_l = sqrt(error(:,1).^2 + error(:,2).^2 + error(:,3).^2);
% % max(error_l)
% 
% % id=find(error_l==max(error_l));
% for id = 1:(num_dpts - 2)
%     span = findspan(num_cpts -1 , degree , uk(id + 1) ,kv );
%     N  = basisfun( span , uk(id + 1) ,degree ,kv );
% %     max_error_point = N * controls_points(span - degree + 1 : span + 1 , :);
% %     plot3( [max_error_point(1)  points(id + 1,1)], [max_error_point(2)  points(id + 1,2)],[max_error_point(3)  points(id + 1,3)], 'r');
% end
% 
% index = 1;
% %ploy_n = 500;
% for u = 0:1/ploy_n:1
%     span = findspan(num_cpts -1 , degree , u ,kv );
%     N  = basisfun( span , u ,degree ,kv );
%     new_point(index,:) = N * controls_points(span - degree + 1 : span + 1 , :);
%     index = index + 1;
% end
% % plot3(new_point(:,1),new_point(:,2),new_point(:,3),'-k'); 
% % axis equal
