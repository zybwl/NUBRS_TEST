
% �����߶�֮��ļн�

function theta = twoLineAngle(point1, point2, point3)
    
    p1_x = point2.x - point1.x;
    p1_y = point2.y - point1.y; 
    p2_x = point3.x - point2.x;
    p2_y = point3.y - point2.y;
    L1 = sqrt(p1_x^2 + p1_y^2);
    L2 = sqrt(p2_x^2 + p2_y^2);
    
    %��ֹ�ߵ��㣬����Ϊ������
    if L1 < 1e-4 || L2 < 1e-4
        theta = 0;
        return
    end
    
    temp =  (p1_x * p2_y - p2_x * p1_y)/L1/L2;
    theta = asin(temp) / pi * 180;
    
    if theta < 0
        theta = 180 + theta;
    end
