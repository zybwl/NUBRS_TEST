function SParam = refreshSParam(SParam)

Amax = SParam.Amax;
Dec = SParam.Dec;
Jamax = SParam.Jamax;
Jdmax = SParam.Jdmax;
% F = SParam.Vmax;
vs = SParam.vs;
T = SParam.T;

six_d_Jamax = (1/6)*Jamax;
six_d_Jdmax = (1/6)*Jdmax;
half_Jamax = (1/2)*Jamax;
half_Jdmax = (1/2)*Jdmax;
half_Amax = (1/2)*Amax;
half_Dec = (1/2)*Dec;
% squa_Amax = Amax^2;
% squa_Dec = Dec^2;

t = cumsum(T);

vknot(1) = vs + half_Jamax*T(1)^2;    
vknot(2) = vknot(1) + Amax*T(2);
vknot(3) = vknot(2) + half_Jamax*T(1)^2;
vknot(4) = vknot(3);
vknot(5) = vknot(4) - half_Jdmax*T(5)^2;
vknot(6) = vknot(5) - Dec*T(6);
vknot(7) = vknot(6) - half_Jdmax*T(7)^2;

sknot(1) = vs*T(1) + six_d_Jamax*T(1)^3;
sknot(2) = sknot(1) + vknot(1)*T(2) + half_Amax*T(2)^2;
sknot(3) = sknot(2) + vknot(2)*T(3) + half_Amax*T(3)^2 - six_d_Jamax*T(3)^3;
sknot(4) = sknot(3) + vknot(3)*T(4);
sknot(5) = sknot(4) + vknot(4)*T(5) - six_d_Jdmax*T(5)^3;
sknot(6) = sknot(5) + vknot(5)*T(6) - half_Dec*T(6)^2;
sknot(7) = sknot(6) + vknot(6)*T(7) - half_Dec*T(7)^2 + six_d_Jdmax*T(7)^3;

SParam.t = t;
SParam.vknot = vknot;
SParam.sknot = sknot;