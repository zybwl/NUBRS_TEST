%clc;clear;close all;
t = 0: 2*pi/4: 2*pi;
rand_r = 5;
pointsA(:,1) = 1000 + rand_r *rand(size(t)) - rand_r/2;
pointsA(:,2) = 1000 + 300 * cos(t) + rand_r *rand(size(t)) - rand_r/2;
pointsA(:,3) = 0 + 300 * sin(t) + rand_r *rand(size(t)) - rand_r/2;
sa = num2str(pointsA, '%.3f')


rand_r = 5;
pointsC(:,1) = 1250 + 300 * cos(t) + rand_r *rand(size(t)) - rand_r/2;
pointsC(:,2) = 1000 + 300 * sin(t) + rand_r *rand(size(t)) - rand_r/2;
pointsC(:,3) = 35 + rand_r *rand(size(t)) - rand_r/2;
sc = num2str(pointsC, '%.3f')
% [m,n] = size(kk);
% all_line = '';
% one_line = '';
% for i = 1:m
%     for j = 1:n
%         one_line = strcat(one_line, sprintf('%.3f   ', kk(i,j)));
%     end
%     all_line = strcat(all_line, one_line, '\n');
% end
% all_line


% point_a = [0 -100 0 1]';
% point_b = [0 100 0 1]';
% new_a = [1003 900 -1.2 1]';
% new_b = [1010 1095 1.2 1]';
% 
% v1 = point_b - point_a;
% v1 = v1/norm(v1);
% 
% v2 = new_b - new_a;
% v2 = v2/norm(v2);
% 
% p1 = v1(1:3);  
% x1 = p1(1);  y1 = p1(2); z1 = p1(3);
% p2 = v2(1:3);  
% x2 = p2(1);  y2 = p2(2); z2 = p2(3);
% 
% if y2 < 0
%     t =  asin(-z2 / sqrt(y2^2 + z2^2));
%     at = asin(-z1 / sqrt(y2^2 + z2^2));
% else
%     t = asin(z2 / sqrt(y2^2 + z2^2));
%     at = asin(z1 / sqrt(y2^2 + z2^2));
% end
% rev_a_angle = (at - t)*180/pi;
% % if abs(rev_a_angle + angle_a) > 1
% %     angle_a
% % end
% 
% rev_rot_a = get_rotation_matrix(1, rev_a_angle);
% rev_v2 = rev_rot_a * v2;
% x3 = rev_v2(1); y3 = rev_v2(2); z3 = rev_v2(3);
% 
% if x3 < 0
%     t =  asin(-y3 / sqrt(x3^2 + y3^2));
%     at = asin(-y1 / sqrt(x3^2 + y3^2));
% else
%     t = asin(y3 / sqrt(x3^2 + y3^2));
%     at = asin(y1 / sqrt(x3^2 + y3^2));
% end
% rev_c_angle = (at - t)*180/pi;
% % if abs(rev_c_angle + angle_c) > 1
% %     angle_c   
% % end
% k1 = get_rotation_matrix(1, rev_a_angle);
% k2 = get_rotation_matrix(3, rev_c_angle);
% new_v1 = k2 * k1 * v2;
% if norm(new_v1 - v1) > 1e-3
%     rev_a_angle
% end
