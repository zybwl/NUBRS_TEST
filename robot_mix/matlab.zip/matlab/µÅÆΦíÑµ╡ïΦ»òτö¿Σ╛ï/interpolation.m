clc ;
clear;

DynamicInfo.t = [2,5,7,11,12,14,15];
DynamicInfo.F = [0,0,0,0,0,0,0];
DynamicInfo.L = [0,0,0,0,0,0,0];
DynamicInfo.Ja = 1;  
DynamicInfo.Jd = 1; 
DynamicInfo.acceleration = 2;
DynamicInfo.deceleration = 1; 
DynamicInfo.fs = 1; 
DynamicInfo.speed = 0;  
DynamicInfo.ls = 0;
DynamicInfo.le = 0;
index = 1;  
intp_time = 0.001;
%�Ƿ���Ҫ���ٶȺ;��������֤,�����ʽд��
%����΢���ֵķ�ʽ�����������߾Ͳ������غ�
DEBUG_FLAG = 1;

SV_class = SVelocityPlanning;

for current_time = 0:intp_time:15  
   DynamicInfo.current_time = current_time;
   acc(index) = SV_class.Get_acc(DynamicInfo);
   
   DynamicInfo = SV_class.GetSpeed(DynamicInfo);
   speed(index) = DynamicInfo.speed;
   
   DynamicInfo = SV_class.GetDistance(DynamicInfo);
   l(index) = DynamicInfo.le;
   
     
   index = index + 1;   
end

hold on
subplot(3,1,1);
plot(0:intp_time:15,acc);
subplot(3,1,2);
plot(0:intp_time:15, speed);
subplot(3,1,3);
plot(0:intp_time:15, l);






    

  
    
    
    
    