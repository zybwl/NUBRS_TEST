function [n0p , nnp, matrix_n] = compute_matrix(degree, num_dpts, num_cpts, uk, kv)

    n0p = zeros(1,num_dpts - 2);
    nnp = zeros(1,num_dpts - 2);
    matrix_n = [];
    for i = 2 : num_dpts - 1   
        m_temp = zeros(1, num_cpts - 2);
        span = findspan(num_cpts -1 , degree , uk(i) ,kv ); 
        N  = basisfun( span , uk(i) ,degree ,kv );
        for j = span - degree: span
            if j == 0
                n0p(i - 1) = N(1);
            elseif j == num_cpts - 1
                nnp(i - 1) = N(end);
            else
                m_temp(j) = N(j - span + degree + 1);       
            end                 
        end
        matrix_n = [matrix_n ; m_temp];   
    end
