% clc;clear all;
%ԭʼ����
points = [-3,0,0;0,2.243,-2.308;2,1.986,1.928];
transfer_points = [80.938,83.846,83.9091;30.579,32.785,28.261;6.454,7.291,6.802];

%���ݷ���
%����1 �������3����ķ�����
pv = points(:, 2:end) - points(:,1:end-1);
tv = transfer_points(:,2:end) - transfer_points(:,1:end-1);

d_p = cross(pv(:,1) , pv(:,2));
d_p_l = norm(d_p);
new_org_one = points(:,1) + d_p/d_p_l ;
d_t = cross(tv(:,1) , tv(:,2));
d_t_l = norm(d_t);
new_rot_one = transfer_points(:,1) + d_t/d_t_l ;

origin_points = [points, new_org_one];
rot_points = [transfer_points, new_rot_one];

a_4_12 = [1 0 0 origin_points(:,1)' zeros(1,6)
          1 0 0 origin_points(:,2)' zeros(1,6)
          1 0 0 origin_points(:,3)' zeros(1,6)
          1 0 0 origin_points(:,4)' zeros(1,6)
          0 1 0 zeros(1,3) origin_points(:,1)' zeros(1,3)
          0 1 0 zeros(1,3) origin_points(:,2)' zeros(1,3)
          0 1 0 zeros(1,3) origin_points(:,3)' zeros(1,3)
          0 1 0 zeros(1,3) origin_points(:,4)' zeros(1,3)
          0 0 1 zeros(1,6) origin_points(:,1)' 
          0 0 1 zeros(1,6) origin_points(:,2)'
          0 0 1 zeros(1,6) origin_points(:,3)' 
          0 0 1 zeros(1,6) origin_points(:,4)'];
      
 b_12_1 = [rot_points(1,:)';rot_points(2,:)';rot_points(3,:)'];
 c = a_4_12\b_12_1;
 d = reshape(c(4:12),3,3);
 new_matrix = [c(1:3),d'];
 
%  kk = [1,1,1;points];
kk = [1,1,1;0,2.520,5;-2.896,0,0;0.819,4.278,3];
 cc = new_matrix * kk;
 cc
 
%  c = a_4_12 * result
 







