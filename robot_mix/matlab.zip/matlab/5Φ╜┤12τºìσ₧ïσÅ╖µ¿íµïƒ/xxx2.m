% s = 0;
% for i = 1:1000000
%     s = s + 6/i^2;
% end
% s = sqrt(s)
 
% for i = 1:2500
%     s(i) = 1 + (i-1) * 14;
% end
% s
clc;clear;close all;
file_name = 'D:\\dxf_data.txt';
fid= fopen(file_name);

line_number = 0;
tline = fgetl(fid);
while tline ~= -1
    line_number = line_number + 1;
    k = ceil(line_number/14);
    if mod(line_number,14) == 9       
        x(k) = str2double(tline);
    end
    if mod(line_number,14) == 11
        y(k) = str2double(tline);
    end
    if mod(line_number,14) == 13
        z(k) = str2double(tline);
    end
    tline = fgetl(fid);
end
points(:,1) = x;
points(:,2) = y;
points(:,3) = z;
% points(:,1) = x(1:2:end);
% points(:,2) = y(1:2:end);
% points(:,3) = z(1:2:end);
[new_data, control_points] = fitting(points , 30 , 500);

figure(2)
plot(x,y ,'-r');
hold on
plot(new_data(:,1),new_data(:,2),'-b'); 
plot(control_points(:,1), control_points(:,2), '*')




