%%
%%��Ҫʵ��ģ��3ά����ϣ���������
clc;clear all;
%file_name = 'fitting3.NC';
file_name = 'Vpoint1.NC';
fid= fopen(file_name);
one_point_temp = zeros(1,3);
original_points = [];
points = [];
tline = fgetl(fid);

while tline ~= -1
       
    %expr = '[XYZABCUVF]-?[0-9]+\.?[0-9]*';
    expr = '\-?[0-9]+\.?[0-9]*';
    %expr = '[XYZ]-?[0-9]+.?[0-9]+';  %���ַ�ʽ����ֻҪ1�Σ�֮��ֿ�����
    %G01X0Y349.514Z239.447F10   %�㲻�ӷ�б�ܱ�ʾ����һ���ַ�   +����һ������ *����0������
    %https://blog.csdn.net/zjxiaolu/article/details/45132037
    search_result = regexp(tline,expr,'match');
    if isempty(search_result)
        tline = fgetl(fid);
        continue;
    end
     for k = 1:length(search_result)
        one_result = search_result{k};
        one_point_temp(k) = str2double(one_result(1:end));
     end
     original_points = [original_points; one_point_temp];
     tline = fgetl(fid);
end
% plot3(original_points(:,1), original_points(:,2),original_points(:,3),'b');
% hold on

%�����Ƿ�Ҫ���䣬����Ľ��
index = 2;
cut_l = 1;
points = [original_points(1,:)];
for k = 2: size(original_points,1)
        vect = original_points(k,:) - original_points(k-1,:);
        vect_l = sqrt(vect* vect');
        l_n = ceil(vect_l/cut_l);      
        for i = 1: l_n
            points(index,:) = points(index - 1,:) + 1/l_n * vect;
            index = index + 1;
        end
end
plot3(points(:,1), points(:,2),points(:,3),'b');
hold on

%%%%%%%%%%%%%%%
num_dpts = size(points,1);
dim = num_dpts;

%�ο����е�9.5-9.6ʽ��use_centripetal���������ҳ����������������Ĳ���������ڵ�ʸ��
use_centripetal = false;
uk = compute_params_curve(points, use_centripetal);

%������51�����ݣ�������30��������Ͽ��Ƶ�
degree = 3;
num_cpts = 200;
kv = compute_knot_vector2(degree, num_dpts, num_cpts, uk);

%Compute matrix N
n0p = zeros(1,num_dpts - 2);
nnp = zeros(1,num_dpts - 2);
matrix_n = [];
for i = 2 : num_dpts - 1   
    m_temp = zeros(1, num_cpts - 2);
    span = findspan(num_cpts -1 , degree , uk(i) ,kv ); 
    N  = basisfun( span , uk(i) ,degree ,kv );
    for j = span - degree: span
        if j == 0
            n0p(i - 1) = N(1);
        elseif j == num_cpts - 1
            nnp(i - 1) = N(end);
        else
            m_temp(j) = N(j - span + degree + 1);       
        end                 
    end
    matrix_n = [matrix_n ; m_temp];   
end

% Compute NT
matrix_nt = matrix_n';
% Compute NTN matrix
matrix_ntn = matrix_nt * matrix_n;
% LU-factorization
[matrix_l, matrix_u ] = lu_decomposition(matrix_ntn);

pt0 = points(1,:);
ptm = points(end,:);
[m,n] = size(points);
rk = zeros(m - 2 ,n);
for i = 2: (num_dpts - 1)
    ptk = points(i,:);   
    ptk = ptk - n0p(i - 1) * pt0 - nnp(i -1) * ptm;
    rk(i - 1,:) = ptk;
end

vector_r = matrix_nt * rk;

controls_points = zeros(num_cpts , n);
controls_points(1,:) = pt0 ;
controls_points(end,:) = ptm ;
for i = 1:n
    b = vector_r(:,i);
    y = forward_substitution(matrix_l, b);
    x = backward_substitution(matrix_u, y);
    controls_points(2:(num_cpts-1) ,i) = x;
end
plot3(controls_points(:,1), controls_points(:,2),controls_points(:,3),'.r');
% hold on

%�ҳ���������λ�ã�����ǳ���
error = matrix_n * controls_points(2:end - 1,:) - rk ;
error_l = sqrt(error(:,1).^2 + error(:,2).^2 + error(:,3).^2);
max(error_l)
id=find(error_l==max(error_l));
% for id = 1:(num_dpts - 2)
span = findspan(num_cpts -1 , degree , uk(id + 1) ,kv );
N  = basisfun( span , uk(id + 1) ,degree ,kv );
max_error_point = N * controls_points(span - degree + 1 : span + 1 , :);
plot3( [max_error_point(1)  points(id + 1,1)], [max_error_point(2)  points(id + 1,2)],[max_error_point(3)  points(id + 1,3)], '*r');
% end

index = 1;
ploy_n = 500;
for u = 0:1/ploy_n:1
    span = findspan(num_cpts -1 , degree , u ,kv );
    N  = basisfun( span , u ,degree ,kv );
    new_point(index,:) = N * controls_points(span - degree + 1 : span + 1 , :);
    index = index + 1;
end
plot3(new_point(:,1),new_point(:,2),new_point(:,3),'k'); 
axis equal














