function points = expand_points(original_points ,expand_length)
    
    index = 2;
    %cut_l = 1;
    points = original_points(1,:);
    for k = 2: size(original_points,1)
            vect = original_points(k,:) - original_points(k-1,:);
            vect_l = sqrt(vect* vect');
            l_n = ceil(vect_l/expand_length);      
            for i = 1: l_n
                points(index,:) = points(index - 1,:) + 1/l_n * vect;
                index = index + 1;
            end
    end