clc;clear all
r = 20;
x0= 0 ;y0 = 0;z0= 0;
%�ο��Ǿ���B������2ҳ
%ֻ��һ����Բ
angleA = zeros(11,21);
angleC = zeros(11,21);
for i = 1 : 11
    for j = 1: 21
        u = (i - 1) * pi / 20;
        v = (j - 1) * pi / 10;
        angleA(i,j) = u;
        angleC(i,j) = v;
        x1 = r * sin(u) * sin(v) + x0;
        y1 = r * sin(u) * cos(v) + y0;
        z1 = r * cos(u) + z0;
        ball_point{i,j} = [x1,y1,z1];
    end
end

%�����Լ�AC���Ķ���
L = 10;
center_knife = [0,0,25];
cylinder_h = 40; cylinder_r = 3;
%���嵶�ĳ�ʼ��״

% hold on

center_A = [0 ,5,0];
center_C = [5,0,0];
kkk = 1;

% ball_point = {};
new_knife_center = [0,0,50 ];
for k = 1:11
    for f = 1:21
        A = angleA(k,f) ;
        C = angleC(k,f)  ;
        for i = 1 : 11
            for j = 1: 21
                v1 = ball_point{i,j} - center_C ;
                v1 = [v1 1]';

                %A������ת
                Ra = [1 0 0 0 ; 0 cos(A) -sin(A) 0 ; 0 sin(A) cos(A) 0 ;0 0 0 1];
                %C������ת
                Rc = [cos(C) -sin(C) 0 0 ; sin(C) cos(C) 0 0 ; 0 0 1 0;0 0 0 1]; 

                T = center_C - center_A;
                T1 = [eye(3) T' ; zeros(1,3) 1]; 
                T2 = [eye(3) center_A'; zeros(1,3) 1];
                new_ball_point(:,kkk) = T2 * Ra * T1 *  Rc  * v1; 
                new_x(i,j) = new_ball_point(1,kkk);
                new_y(i,j) = new_ball_point(2,kkk);
                new_z(i,j) = new_ball_point(3,kkk);
                
            end   
        end
        vect = [new_x(k,f),new_y(k,f), new_z(k,f)];
        if k >1
            bingo_point = [ball_point{k,f}, A/pi*180 ,C/pi*180]
            vect
        end
        pause(0.1)
        mesh(new_x, new_y , new_z);
        hold on
        plot3(new_x([1,4,7,11],1), new_y([1,4,7,11],1),new_z([1,4,7,11],1), '*r')
        plot3(new_x([1,4,7,11],6), new_y([1,4,7,11],6),new_z([1,4,7,11],6), '*b')
        plot3(new_x([1,4,7,11],11), new_y([1,4,7,11],11),new_z([1,4,7,11],11), '*y')
        plot3(new_x([1,4,7,11],16), new_y([1,4,7,11],16),new_z([1,4,7,11],16), '*g')
        axis([-40,40,-40,40,-30,80]);
        hold on
        new_knife_center = center_knife + vect ;
        draw_cylinder(new_knife_center, cylinder_h, cylinder_r, [0 0 0], 1);  
        hold off
    end
    pause(1)
end
% mesh(r*x1+x0,r*y1+y0,r*z1+z0);
% mesh(new_x, new_y , new_z);
% hold on
% draw_cylinder(new_knife_center, cylinder_h, cylinder_r, [0 0 0], 1);    

% plot3(new_ball_point(1,:),new_ball_point(2,:),new_ball_point(3,:))


