% % Matlab�к����Ĳ������ǲ��ð�ֵ���ݵķ�ʽ��û�а����ô��ݵķ�ʽ������C++����Ա�ܲ�ϰ�ߣ��ܶ�ʱ�����ǿ��ܻ���Ҫ���ں�����ʵ��
% % �޸Ĳ�����ֵ���������ڵ����������һ�����ṹ��ʱ,��ʱֻ���ú����Ĳ���ͬʱ��Ϊͬ������ֵ
function SVelocity = SVelocityPlanning
    SVelocity.GetSpeed = @GetSpeed;
    SVelocity.GetDistance = @GetDistance;
    SVelocity.Get_acc = @Get_acc;
end

function acc = Get_acc(dynamic_info)
    t = dynamic_info.t;
    if(dynamic_info.current_time < t(1))
        relative_time = dynamic_info.current_time;
        acc = dynamic_info.Ja * relative_time;
    elseif(dynamic_info.current_time < t(2))
        acc = dynamic_info.acceleration;
    elseif(dynamic_info.current_time < t(3))
        relative_time = dynamic_info.current_time - t(2);
        acc = dynamic_info.acceleration -  dynamic_info.Ja * relative_time;
    elseif(dynamic_info.current_time < t(4))
        acc = 0;
    elseif(dynamic_info.current_time < t(5))
        relative_time = dynamic_info.current_time - t(4);
        acc = -dynamic_info.Jd * relative_time;
    elseif(dynamic_info.current_time < t(6))
        acc = -dynamic_info.deceleration;
    elseif(dynamic_info.current_time < t(7))
        relative_time = dynamic_info.current_time - t(6);
        acc = -(dynamic_info.deceleration - dynamic_info.Jd * relative_time);
    else
        acc = 0;
    end
end

function dynamic_info_copy = GetDistance(dynamic_info)
    
    dynamic_info_copy = dynamic_info;
    t = dynamic_info.t;    
    l = 0;
    if(dynamic_info.current_time < t(1))
        relative_time = dynamic_info.current_time;      
        l = dynamic_info.ls + dynamic_info.fs * relative_time + dynamic_info.Ja * relative_time^3 /6;   
        dynamic_info_copy.L(1) = l;
    elseif(dynamic_info.current_time < t(2))
        relative_time = dynamic_info.current_time - t(1);
        l = dynamic_info.L(1) + dynamic_info.F(1) * relative_time + 0.5* dynamic_info.acceleration * relative_time^2;
        dynamic_info_copy.L(2) = l;
    elseif(dynamic_info.current_time < t(3))
        relative_time = dynamic_info.current_time - t(2);
        l = dynamic_info.L(2) + dynamic_info.F(2) * relative_time + 0.5 * dynamic_info.acceleration * relative_time^2 - dynamic_info.Ja * relative_time^3 / 6;       
        dynamic_info_copy.L(3) = l;
    elseif(dynamic_info.current_time < t(4))      
        relative_time = dynamic_info.current_time - t(3);
        l = dynamic_info.L(3) + dynamic_info.F(3) * relative_time;
        dynamic_info_copy.L(4) = l;      
    elseif(dynamic_info.current_time < t(5))
        relative_time = dynamic_info.current_time - t(4);
        l = dynamic_info.L(4) + dynamic_info.F(4) * relative_time - dynamic_info.Jd * relative_time^3 / 6;
        dynamic_info_copy.L(5) = l;
    elseif(dynamic_info.current_time < t(6))
        relative_time = dynamic_info.current_time - t(5);
        l = dynamic_info.L(5) + dynamic_info.F(5) * relative_time - 0.5 * dynamic_info.deceleration * relative_time^2; 
        dynamic_info_copy.L(6) = l;
    elseif(dynamic_info.current_time <= t(7))
        relative_time = dynamic_info.current_time - t(6);
        l = dynamic_info.L(6) + dynamic_info.F(6) * relative_time - 0.5 * dynamic_info.deceleration * relative_time^2 + dynamic_info.Jd * relative_time^3 / 6;                
        dynamic_info_copy.L(7) = l;
    else
        l = 0;
    end
    dynamic_info_copy.le = l;
    
end
 
function dynamic_info_copy = GetSpeed(dynamic_info)
   
    dynamic_info_copy = dynamic_info;
    t = dynamic_info.t;
    speed = 0;
    if(dynamic_info.current_time < t(1))
        relative_time = dynamic_info.current_time;
        speed = dynamic_info.fs + 0.5* dynamic_info.Ja * relative_time^2;
        dynamic_info_copy.F(1) = speed;
    elseif(dynamic_info.current_time < t(2))
        relative_time = dynamic_info.current_time - t(1);
        speed = dynamic_info.F(1) + dynamic_info.acceleration * relative_time;
        dynamic_info_copy.F(2) = speed;
    elseif(dynamic_info.current_time < t(3))
        relative_time = dynamic_info.current_time - t(2);
        speed = dynamic_info_copy.F(2) + dynamic_info_copy.acceleration * relative_time - 0.5 * dynamic_info_copy.Ja * relative_time^2;
        dynamic_info_copy.F(3) = speed;
    elseif(dynamic_info.current_time < t(4))
        speed = dynamic_info_copy.F(3);
        dynamic_info_copy.F(4) = speed;      
    elseif(dynamic_info.current_time < t(5))
        relative_time = dynamic_info.current_time - t(4);
        speed = dynamic_info_copy.F(4) -  0.5 * dynamic_info.Jd * relative_time^2;
        dynamic_info_copy.F(5) = speed;
    elseif(dynamic_info.current_time < t(6))
        relative_time = dynamic_info.current_time - t(5);
        speed = dynamic_info_copy.F(5) -  dynamic_info.deceleration * relative_time;
        dynamic_info_copy.F(6) = speed;
    elseif(dynamic_info.current_time <= t(7))
        relative_time = dynamic_info.current_time - t(6);
        speed = dynamic_info_copy.F(6) - dynamic_info.deceleration * relative_time + 0.5 * dynamic_info_copy.Jd * relative_time^2;
        dynamic_info_copy.F(7) = speed;
    else
        speed = 0;
    end
    dynamic_info_copy.speed = speed;
end
