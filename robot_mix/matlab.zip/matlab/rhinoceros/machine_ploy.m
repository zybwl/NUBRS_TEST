
clc;clear all;close all;

center1 = [1000,1000,0];
center2 = [1250, 1000, 35];
center3 = [1270, 1030 , 55];
r = 50;
% ����һ��Բ������
for i = 3:9
    for j = 1: 21
        u = (i - 1) * pi / 20 ;
        v = (j - 1) * pi / 10 ;
        x = r * sin(u) * cos(v);
        y = r * sin(u) * sin(v);
        z = r * cos(u);
        angle_a = u / pi * 180;
        angle_c = 90 - v / pi * 180;
        ball_point = [x,y,z];        
        ra = get_rotation_matrix(1 , angle_a);
        ta = get_translation_matrix(center1);
        rc = get_rotation_matrix(3 , angle_c);
        tc = get_translation_matrix(center2 - center1);
        new_center = ta * ra * tc * rc * [center3 - center2 , 1]';      
        draw_machine_figure(angle_a + 11.537, angle_c - 20);
        draw_knife(new_center , 100, 10);
        pause(0.2);
        hold off
    end
end






