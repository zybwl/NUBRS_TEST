function new_point = C_A_RTCP_POS(angleC ,mcx, mcy ,angleA, may,maz)
    %maz����L�������ĳ���
    C = angleC;
    A = angleA;
    origin_point = [0;may;maz;1];
    
     Ra = [1 0 0 0 ; 0 cos(A) -sin(A) 0 ; 0 sin(A) cos(A) 0 ;0 0 0 1];
     %C����任
     T = [mcx; mcy-may ; 0]; 
     Tc = [eye(3) T ; zeros(1,3) 1]; 
     Rc = [cos(C) -sin(C) 0 0 ; sin(C) cos(C) 0 0 ; 0 0 1 0;0 0 0 1]; 
     temp_point = Rc*Tc*Ra*origin_point;
     new_point = temp_point(1:end-1);
     