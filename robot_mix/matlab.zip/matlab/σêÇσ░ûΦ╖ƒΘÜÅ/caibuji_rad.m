clc;clear;
file_name = '3.NC';
start_line_no = 17;
end_line_no = 5814;
p = 3;
ploy_n = end_line_no - start_line_no;
[line_before, point_struct_array ,line_end] = get_nc_data(file_name,start_line_no,end_line_no);
n = size(point_struct_array,2);

index = 1;
for k = 1:n
    X = point_struct_array(k).X;
    Y = point_struct_array(k).Y;
%     point(:,k) = [X;Y];
     if k == 1
            point(:,index) = [X;Y];
            U(1) = 0;
            index = index + 1;
        else
            vect = [X;Y] - point(:,index-1);
            l = sqrt(vect'* vect);
            l_n = ceil(l/3);
            if l > 0.5
                for i = 1: l_n
                    point(:,index) = point(:,index-1) + 1/l_n * vect;
                    U(index) = U(index -1) + 1/l_n*l;
                    index = index + 1;
                end
            else
                continue;
            end
        end  
end
plot(point(1,:),point(2,:),'b');

n = size(point,2);
U = zeros(1, n);
xx = zeros(1,n);
for k = 2:n
        vect = point(:,k) - point(:,k-1);
        xx(k) = sqrt(vect'* vect);
        U(1,k) = U(1,k -1) + sqrt(xx(k));
end
U  = U / U(1,n);

U_ploy = zeros(1, n+p+1);
for k = 2: n-p
    U_ploy(1,k+p) = sum(U(1, k : k + p - 1))/p;
end
U_ploy(1,n+1:end) = 1;

A = zeros(n,n);
for k = 1:n
    span = findspan(n-1 , p , U(k) ,U_ploy);
    A(k , span - p + 1:span + 1) = basisfun(span, U(k),p,U_ploy) ;
end

P = A\point';
plot(point(1,:),point(2,:),'b');
hold on
%plot(P(:,1),P(:,2),'-ro');  

index = 1;
for u = 0:1/500:1
    span = findspan(n-1 , p , u ,U_ploy );
    N = basisfun(span,u,p,U_ploy);
    new_point(index,:) = N * P(span - p + 1 : span + 1, :);
    index = index + 1;
end
plot(new_point(:,1),new_point(:,2),'-r'); 

%��ȡ���ƫ�ƫ�����Ͳ���ͨ��
% U_n = length(U)
% for i = 1:U_n
%     span = findspan(n-1 , p , u ,U_ploy );
%     N = basisfun(span,u,p,U_ploy);
%     expect_point = N * P(span - p + 1 : span + 1, :);
% %     error = expect_point
% end

point_n = size(new_point,1);
line_middle = '';
for k = 1: point_n
    tline = sprintf('G01X%-6.3fY%-6.3fF8000.000' , ...
                    new_point(k,1),new_point(k,2)); 
    line_middle = sprintf('%s\n%s',line_middle,tline);
end        
    
file_head = strsplit(file_name,'.');
new_file_name =  sprintf('%s%s%s', file_head{1,1}, num2str(randperm(1000,1)), '.nc');
fid=fopen(new_file_name,'a');

fprintf(fid,'%s%s%s',line_before, line_middle ,line_end);
fclose(fid);





     
     











