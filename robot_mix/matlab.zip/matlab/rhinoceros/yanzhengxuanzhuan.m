
rot_a = get_rotation_matrix(1, -15);
rot_c = get_rotation_matrix(3, 30);

point_a = [0,1,1,1]';
point_b = [1,0,0,1]';
new_a = rot_a * rot_c * point_a;
new_b = rot_a * rot_c * point_b;
% plot3([point_a(1) point_b(1)] ,[point_a(2) point_b(2)],[point_a(2) point_b(2)]);
% hold on
% plot3([new_a(1) new_b(1)] ,[new_a(2) new_b(2)],[new_a(2) new_b(2)]);
% axis equal

rev_rot_a = get_rotation_matrix(1, 15);
rev_rot_c = get_rotation_matrix(3, 30);
p1 = point_b(1:3) - point_a(1:3);
x1 = p1(1);  y1 = p1(2); z1 = p1(3);
p2 = new_b(1:3) - new_a(1:3);
x2 = p2(1);  y2 = p2(2); z2 = p2(3);

% t = asin(z2 / sqrt(y2^2 + z2^2));
% at = asin(z1 / sqrt(y2^2 + z2^2));
% anglea = (at - t)*180/pi

rev_rot_a = get_rotation_matrix(1, 15);
rev_rot_c = get_rotation_matrix(3, -30);
replay_a = rev_rot_c * rev_rot_a * new_a


% 
% 
% 
% vc_ab = point_b - point_a;
% vc_new_ab = new_b - new_a;
% 
% sin2 = asin(vc_ab(1) / norm(vc_ab(1:2)));
% sin1 = asin(vc_new_ab(1)/ norm(vc_ab(1:2)));
% anglec = sin2 - sin1;
% c = anglec/pi*180

% cosc = cos(anglec);
% sinc = sin(anglec);
% vc_bc = [vc_ab(1) * sinc + vc_ab(2) * cosc , vc_ab(3)];
% cost4 = acos(vc_new_ab(2)/ norm(vc_bc));
% cost3 = acos(vc_bc(1) / norm(vc_bc));
% anglea = cost3 - cost4;
% a = anglea/pi*180



