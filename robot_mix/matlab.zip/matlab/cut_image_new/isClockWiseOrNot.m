% �ж�ͼԪ��˳ʱ��ü�������ʱ��ü�

function result = isClockWiseOrNot(figure_point_array)

%     x = figure_point_array.x;
%     y = figure_point_array.y;
%     n = length(x);
%     
%     %�����ڽ�������ж�
%     S = 0;
%     for i = 1:n        
%         index_1 = i;
%         index_2 =  1+ mod(i,n);
%         index_3 =  1+ mod(i,n-1);
%         
%         p1_x = x(index_3) - x(index_2) ;
%         p1_y = y(index_3) - y(index_2) ;
%         p2_x = x(index_2) - x(index_1) ;
%         p2_y = y(index_3) - y(index_2) ;       
%         S = S + p1_x * p2_y - p2_x * p1_y;
%     
%     end
    S = countPolygonArea(figure_point_array);
    
    if S > 0
        result = 1;
    else
        result = 0;
    end