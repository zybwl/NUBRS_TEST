clc;clear all
r = 100;
x0=0;y0=0;z0=-r;
n = 20;
%�ο��Ǿ���B������2ҳ
%ֻ��һ����Բ
angleA = zeros(11,21);
angleC = zeros(11,21);
x1 = zeros(11,21);
y1 = zeros(11,21);
z1 = zeros(11,21);
for i = 1 : 11
    for j = 1: 21
        u = (i - 1) * pi / 20;
        v = (j - 1) * pi / 10;
        angleA(i,j) = u;
        angleC(i,j) = v;
        x1(i,j) = sin(u) * cos(v);
        y1(i,j) = sin(u)*sin(v);
        z1(i,j) = cos(u);
    end
end
% mesh(r*x1+x0,r*y1+y0,r*z1+z0);
% hold on
% axis equal

%�����Լ�AC���Ķ���
L = 60;
centerC = [30,10,L+10];
centerA = [0,10,L];
%���嵶�ĳ�ʼ��״
point = [centerA;0,0,L;0,0,0;0,20,L-45;0,20,L;centerA]';

kkk = 1;
for i = 1 : 11
    for j = 1: 21
% for i = 11 : 11
%     for j = 11: 
        A = angleA(i,j) ;
        C = angleC(i,j) + pi/2 ;
        ball_point = [r*x1(i,j)+x0, r*y1(i,j)+y0, r*z1(i,j)+z0];
        mesh(r*x1+x0,r*y1+y0,r*z1+z0);
        axis([-160,160,-160,160,-100,80]);
        xlabel('X��');
        ylabel('Y��');
        zlabel('Z��');
        
        hold on
%         axis equal
        newpoint = zeros(4,6);
        for k = 1:6
            %A������ת
            Ra = [1 0 0 0 ; 0 cos(A) -sin(A) 0 ; 0 sin(A) cos(A) 0 ;0 0 0 1];
            %C������ת
            Rc = [cos(C) -sin(C) 0 0 ; sin(C) cos(C) 0 0 ; 0 0 1 0;0 0 0 1]; 
            %���ڵ��ϵĵ㣬��ֻ����ת���ӵ�Ӱ��
            newpoint(:,k) = Rc * Ra  * [point(:,k);1];   
            %����Cת̨�ϵĵ㣬������ƫ�Ƶ�Ӱ��
            T = centerC - centerA;
            Tc = [eye(3) T' ; zeros(1,3) 1]; 
            new_centerC = Rc * Tc *  Ra  * [centerA';1];  
        end
        %�ѵ����ƶ���������ȥ
        T = ball_point;
        T_ball = [eye(3) T' ; zeros(1,3) 1]; 
%         final_point = [centerC 1;newpoint];
        final_point = T_ball * [newpoint new_centerC] ;
%         k_point = [final_point new_centerC];
        machine_point(:,kkk) = final_point(1:3,end);
        kkk = kkk + 1;
        plot3(final_point(1,:),final_point(2,:),final_point(3,:));       
        axis([-160,160,-160,160,-160,80]);
        hold off
        pause(0.1);
%         break;
    end   
%     break;
    pause(1);
end
        
        
% x0=-3;y0=-3;z0=-3;%����
% r=3;%�뾶
% [x,y,z]=sphere;
% mesh(r*x+x0,r*y+y0,r*z+z0);
% hold on
% axis equal
% 

% point = [0,0,0;0,0,-L;0,2,-L+3;0,2,0];
% all_point = [centerC;centerA;point;centerA];
% plot3(all_point(:,1),all_point(:,2),all_point(:,3));

