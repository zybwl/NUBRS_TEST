
file_name = 'Vpoint.NC';
fid= fopen(file_name);
one_point_temp = zeros(1,2);
all_temp_point = [];
all_point = [];
tline = fgetl(fid);
p = 3;
cut_length = 1;

while tline ~= -1
       
    %expr = '[XYZABCUVF]-?[0-9]+\.?[0-9]*';
    expr = '[0-9]+\.?[0-9]*';
    %expr = '[XYZ]-?[0-9]+.?[0-9]+';  %���ַ�ʽ����ֻҪ1�Σ�֮��ֿ�����
    %G01X0Y349.514Z239.447F10   %�㲻�ӷ�б�ܱ�ʾ����һ���ַ�   +����һ������ *����0������
    %https://blog.csdn.net/zjxiaolu/article/details/45132037
    search_result = regexp(tline,expr,'match');
    if isempty(search_result)
        tline = fgetl(fid);
        continue;
    end
     for k = 1:length(search_result)-1
        one_result = search_result{k};
        one_point_temp(k) = str2double(one_result(1:end));
     end
     all_temp_point = [all_temp_point; one_point_temp];
     tline = fgetl(fid);
end
plot(all_temp_point(:,1), all_temp_point(:,2),'b');
hold on

index = 1;
n = size(all_temp_point,1);
% ploy_n = n ;
for k = 1:n
    if k == 1
            all_point(1,:) = all_temp_point(1,:);
            index = index + 1;
    else
        vect = all_temp_point(k,:) - all_temp_point(k-1,:);
        vect_l = sqrt(vect* vect');
        l_n = ceil(vect_l/cut_length);

        for i = 1: l_n
            all_point(index,:) = all_temp_point(k-1,:) + 1/l_n * vect;
            index = index + 1;
        end

    end  
end


%�õ�u(k)
n = size(all_point,1);
U = zeros(1, n);
for k = 2:n
        vect = all_point(k,:) - all_point(k-1,:);
        U(k) = U(k -1) + sqrt(sqrt(vect* vect'));
end
U  = U / U(1,n);

U_ploy = zeros(1, n+p+1);
for k = 2: n-p
    U_ploy(k+p) = sum(U(k : k + p - 1))/p;
end
U_ploy(n+1:end) = 1;


index = 1;
ploy_n = n ;
for u = 0:1/ploy_n:1
    span = findspan(n-1 , p , u ,U_ploy );
    N = basisfun(span,u,p,U_ploy);
    new_point(index,:) = N * all_point(span - p + 1 : span + 1, 1:2);
    index = index + 1;
end
plot(new_point(:,1),new_point(:,2),'-r'); 
