%main����
%ģ�⵶�ĸ���ü�
clc;clear all;
points = [0    0
490  0
500  20
510  0
1000 0
1000 1000
500  1000
500  995
500 1000
0    1000
0    500
5    500
0    500
0    0];
    
knife_e = 50;
new_points = get_control_points1(knife_e, points);
n = size(new_points,1);
for i = 1: n-1
    p1 = new_points(i,:);
    p2 = new_points(i+1,:);
    L = norm(p2 - p1);
    m = floor(L/10) + 1;
    for j = 0:m
        p = ((m - j)*p1 + j*p2 )/m;
        p_start = [p(1),p(2)];
        t = p(3)*pi/180;
        p_end = p_start + knife_e * [cos(t) sin(t)];
        plot(points(:,1),points(:,2),'-s')
        hold on
        axis equal;
        plot(new_points(:,1),new_points(:,2),'-*')
        plot([p_start(1),p_end(1)],[p_start(2),p_end(2)],'-*');
        text(p_start(1), p_start(2) ,'start')
        text(p_end(1), p_end(2) ,'end')
        hold off
        pause(0.1);
    end
    pause(0.3);
end    




