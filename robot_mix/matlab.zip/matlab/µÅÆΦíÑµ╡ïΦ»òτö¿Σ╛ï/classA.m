
classdef classA
    properties
        a
        b
        c
        d
    end
    
    methods
        function obj = classA(structx)
            if nargin == 0          
            end
            obj.a = structx.a;
            obj.b = structx.b;
            obj.c = structx.c;
            obj.d = structx.d;
        end
    end
end


