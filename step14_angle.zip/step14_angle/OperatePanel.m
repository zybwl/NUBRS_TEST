function varargout = OperatePanel(varargin)
% OPERATEPANEL MATLAB code for OperatePanel.fig
%      OPERATEPANEL, by itself, creates a new OPERATEPANEL or raises the existing
%      singleton*.
%
%      H = OPERATEPANEL returns the handle to a new OPERATEPANEL or the handle to
%      the existing singleton*.
%
%      OPERATEPANEL('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in OPERATEPANEL.M with the given input arguments.
%
%      OPERATEPANEL('Property','Value',...) creates a new OPERATEPANEL or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before OperatePanel_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to OperatePanel_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help OperatePanel

% Last Modified by GUIDE v2.5 22-Oct-2012 19:25:49

% Begin initialization code - DO NOT EDIT
global  radio1 radio2 radio3 radio4 radio5 radio6 radio7 radio8 radio9
radio1=0;
radio2=0;
radio3=0;
radio4=0;
radio5=0;
radio6=0;
radio7=0;
radio8=0;
radio9=0;
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @OperatePanel_OpeningFcn, ...
    'gui_OutputFcn',  @OperatePanel_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before OperatePanel is made visible.
function OperatePanel_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to OperatePanel (see VARARGIN)

% Choose default command line output for OperatePanel
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes OperatePanel wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = OperatePanel_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in radiobutton1.
function radiobutton1_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global  radio1 radio2 radio3 radio4 radio5 radio6 radio7 radio8 radio9
% radiobutton1=get(handles.radiobutton1,'value');
radiobutton1=get(findobj('tag','radiobutton1'),'value');  
radiobutton2=get(findobj('tag','radiobutton2'),'value');  
radiobutton3=get(findobj('tag','radiobutton3'),'value');  
radiobutton4=get(findobj('tag','radiobutton4'),'value');  
radiobutton5=get(findobj('tag','radiobutton5'),'value');  
radiobutton6=get(findobj('tag','radiobutton6'),'value');  
radiobutton7=get(findobj('tag','radiobutton7'),'value');  
radiobutton8=get(findobj('tag','radiobutton8'),'value');  
radiobutton9=get(findobj('tag','radiobutton9'),'value');  

if radiobutton1==1
    set(findobj('tag','radiobutton2'),'value',0);
    set(findobj('tag','radiobutton3'),'value',0);
    set(findobj('tag','radiobutton4'),'value',0);
    set(findobj('tag','radiobutton5'),'value',0);
    set(findobj('tag','radiobutton6'),'value',0);
    set(findobj('tag','radiobutton7'),'value',0);
    set(findobj('tag','radiobutton8'),'value',0);
    set(findobj('tag','radiobutton9'),'value',0);
else
    set(findobj('tag','radiobutton1'),'value',1);

end
radio1=1;
radio2=0;
radio3=0;
radio4=0;
radio5=0;
radio6=0;
radio7=0;
radio8=0;
radio9=0;
% Hint: get(hObject,'Value') returns toggle state of radiobutton1


% --- Executes on button press in radiobutton2.
function radiobutton2_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global  radio1 radio2 radio3 radio4 radio5 radio6 radio7 radio8 radio9
radiobutton1=get(findobj('tag','radiobutton1'),'value');  
radiobutton2=get(findobj('tag','radiobutton2'),'value');  
radiobutton3=get(findobj('tag','radiobutton3'),'value');  
radiobutton4=get(findobj('tag','radiobutton4'),'value');  
radiobutton5=get(findobj('tag','radiobutton5'),'value');  
radiobutton6=get(findobj('tag','radiobutton6'),'value');  
radiobutton7=get(findobj('tag','radiobutton7'),'value');  
radiobutton8=get(findobj('tag','radiobutton8'),'value');  
radiobutton9=get(findobj('tag','radiobutton9'),'value');  
if radiobutton2==1
    set(findobj('tag','radiobutton1'),'value',0);
    set(findobj('tag','radiobutton3'),'value',0);
    set(findobj('tag','radiobutton4'),'value',0);
    set(findobj('tag','radiobutton5'),'value',0);
    set(findobj('tag','radiobutton6'),'value',0);
    set(findobj('tag','radiobutton7'),'value',0);
    set(findobj('tag','radiobutton8'),'value',0);
    set(findobj('tag','radiobutton9'),'value',0);
else
  set(findobj('tag','radiobutton2'),'value',1);

end
radio1=0;
radio2=1;
radio3=0;
radio4=0;
radio5=0;
radio6=0;
radio7=0;
radio8=0;
radio9=0;
% Hint: get(hObject,'Value') returns toggle state of radiobutton2


% --- Executes on button press in radiobutton3.
function radiobutton3_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global  radio1 radio2 radio3 radio4 radio5 radio6 radio7 radio8 radio9
radiobutton1=get(findobj('tag','radiobutton1'),'value');  
radiobutton2=get(findobj('tag','radiobutton2'),'value');  
radiobutton3=get(findobj('tag','radiobutton3'),'value');  
radiobutton4=get(findobj('tag','radiobutton4'),'value');  
radiobutton5=get(findobj('tag','radiobutton5'),'value');  
radiobutton6=get(findobj('tag','radiobutton6'),'value');  
radiobutton7=get(findobj('tag','radiobutton7'),'value');  
radiobutton8=get(findobj('tag','radiobutton8'),'value');  
radiobutton9=get(findobj('tag','radiobutton9'),'value');  
if radiobutton3==1
    set(findobj('tag','radiobutton1'),'value',0);
    set(findobj('tag','radiobutton2'),'value',0);
    set(findobj('tag','radiobutton4'),'value',0);
    set(findobj('tag','radiobutton5'),'value',0);
    set(findobj('tag','radiobutton6'),'value',0);
    set(findobj('tag','radiobutton7'),'value',0);
    set(findobj('tag','radiobutton8'),'value',0);
    set(findobj('tag','radiobutton9'),'value',0);
else
   set(findobj('tag','radiobutton3'),'value',1);

end
radio1=0;
radio2=0;
radio3=1;
radio4=0;
radio5=0;
radio6=0;
radio7=0;
radio8=0;
radio9=0;
% Hint: get(hObject,'Value') returns toggle state of radiobutton3


% --- Executes on button press in radiobutton4.
function radiobutton4_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global  radio1 radio2 radio3 radio4 radio5 radio6 radio7 radio8 radio9
radiobutton1=get(findobj('tag','radiobutton1'),'value');  
radiobutton2=get(findobj('tag','radiobutton2'),'value');  
radiobutton3=get(findobj('tag','radiobutton3'),'value');  
radiobutton4=get(findobj('tag','radiobutton4'),'value');  
radiobutton5=get(findobj('tag','radiobutton5'),'value');  
radiobutton6=get(findobj('tag','radiobutton6'),'value');  
radiobutton7=get(findobj('tag','radiobutton7'),'value');  
radiobutton8=get(findobj('tag','radiobutton8'),'value');  
radiobutton9=get(findobj('tag','radiobutton9'),'value');  
if radiobutton4==1
    set(findobj('tag','radiobutton1'),'value',0);
    set(findobj('tag','radiobutton2'),'value',0);
    set(findobj('tag','radiobutton3'),'value',0);
    set(findobj('tag','radiobutton5'),'value',0);
    set(findobj('tag','radiobutton6'),'value',0);
    set(findobj('tag','radiobutton7'),'value',0);
    set(findobj('tag','radiobutton8'),'value',0);
    set(findobj('tag','radiobutton9'),'value',0);
else
    set(findobj('tag','radiobutton4'),'value',1);

end
radio1=0;
radio2=0;
radio3=0;
radio4=1;
radio5=0;
radio6=0;
radio7=0;
radio8=0;
radio9=0;
% Hint: get(hObject,'Value') returns toggle state of radiobutton4


% --- Executes on button press in radiobutton5.
function radiobutton5_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global  radio1 radio2 radio3 radio4 radio5 radio6 radio7 radio8 radio9
radiobutton1=get(findobj('tag','radiobutton1'),'value');  
radiobutton2=get(findobj('tag','radiobutton2'),'value');  
radiobutton3=get(findobj('tag','radiobutton3'),'value');  
radiobutton4=get(findobj('tag','radiobutton4'),'value');  
radiobutton5=get(findobj('tag','radiobutton5'),'value');  
radiobutton6=get(findobj('tag','radiobutton6'),'value');  
radiobutton7=get(findobj('tag','radiobutton7'),'value');  
radiobutton8=get(findobj('tag','radiobutton8'),'value');  
radiobutton9=get(findobj('tag','radiobutton9'),'value');  
if radiobutton5==1
       set(findobj('tag','radiobutton1'),'value',0);
    set(findobj('tag','radiobutton3'),'value',0);
    set(findobj('tag','radiobutton4'),'value',0);
    set(findobj('tag','radiobutton2'),'value',0);
    set(findobj('tag','radiobutton6'),'value',0);
    set(findobj('tag','radiobutton7'),'value',0);
    set(findobj('tag','radiobutton8'),'value',0);
    set(findobj('tag','radiobutton9'),'value',0);
else
    set(findobj('tag','radiobutton5'),'value',1);

end
radio1=0;
radio2=0;
radio3=0;
radio4=0;
radio5=1;
radio6=0;
radio7=0;
radio8=0;
radio9=0;
% Hint: get(hObject,'Value') returns toggle state of radiobutton5


% --- Executes on button press in radiobutton6.
function radiobutton6_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global  radio1 radio2 radio3 radio4 radio5 radio6 radio7 radio8 radio9
radiobutton1=get(findobj('tag','radiobutton1'),'value');  
radiobutton2=get(findobj('tag','radiobutton2'),'value');  
radiobutton3=get(findobj('tag','radiobutton3'),'value');  
radiobutton4=get(findobj('tag','radiobutton4'),'value');  
radiobutton5=get(findobj('tag','radiobutton5'),'value');  
radiobutton6=get(findobj('tag','radiobutton6'),'value');  
radiobutton7=get(findobj('tag','radiobutton7'),'value');  
radiobutton8=get(findobj('tag','radiobutton8'),'value');  
radiobutton9=get(findobj('tag','radiobutton9'),'value');  
if radiobutton6==1
    set(findobj('tag','radiobutton1'),'value',0);
    set(findobj('tag','radiobutton3'),'value',0);
    set(findobj('tag','radiobutton4'),'value',0);
    set(findobj('tag','radiobutton5'),'value',0);
    set(findobj('tag','radiobutton2'),'value',0);
    set(findobj('tag','radiobutton7'),'value',0);
    set(findobj('tag','radiobutton8'),'value',0);
    set(findobj('tag','radiobutton9'),'value',0);
else
    set(findobj('tag','radiobutton6'),'value',1);

end
radio1=0;
radio2=0;
radio3=0;
radio4=0;
radio5=0;
radio6=1;
radio7=0;
radio8=0;
radio9=0;
% Hint: get(hObject,'Value') returns toggle state of radiobutton6


% --- Executes on button press in radiobutton7.
function radiobutton7_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global  radio1 radio2 radio3 radio4 radio5 radio6 radio7 radio8 radio9
radiobutton1=get(findobj('tag','radiobutton1'),'value');  
radiobutton2=get(findobj('tag','radiobutton2'),'value');  
radiobutton3=get(findobj('tag','radiobutton3'),'value');  
radiobutton4=get(findobj('tag','radiobutton4'),'value');  
radiobutton5=get(findobj('tag','radiobutton5'),'value');  
radiobutton6=get(findobj('tag','radiobutton6'),'value');  
radiobutton7=get(findobj('tag','radiobutton7'),'value');  
radiobutton8=get(findobj('tag','radiobutton8'),'value');  
radiobutton9=get(findobj('tag','radiobutton9'),'value');  
if radiobutton7==1
    set(findobj('tag','radiobutton1'),'value',0);
    set(findobj('tag','radiobutton3'),'value',0);
    set(findobj('tag','radiobutton4'),'value',0);
    set(findobj('tag','radiobutton5'),'value',0);
    set(findobj('tag','radiobutton6'),'value',0);
    set(findobj('tag','radiobutton2'),'value',0);
    set(findobj('tag','radiobutton8'),'value',0);
    set(findobj('tag','radiobutton9'),'value',0);
else
    set(findobj('tag','radiobutton7'),'value',1);

end
radio1=0;
radio2=0;
radio3=0;
radio4=0;
radio5=0;
radio6=0;
radio7=1;
radio8=0;
radio9=0;
% Hint: get(hObject,'Value') returns toggle state of radiobutton7


% --- Executes on button press in radiobutton8.
function radiobutton8_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global  radio1 radio2 radio3 radio4 radio5 radio6 radio7 radio8 radio9
radiobutton1=get(findobj('tag','radiobutton1'),'value');  
radiobutton2=get(findobj('tag','radiobutton2'),'value');  
radiobutton3=get(findobj('tag','radiobutton3'),'value');  
radiobutton4=get(findobj('tag','radiobutton4'),'value');  
radiobutton5=get(findobj('tag','radiobutton5'),'value');  
radiobutton6=get(findobj('tag','radiobutton6'),'value');  
radiobutton7=get(findobj('tag','radiobutton7'),'value');  
radiobutton8=get(findobj('tag','radiobutton8'),'value');  
radiobutton9=get(findobj('tag','radiobutton9'),'value');  
if radiobutton8==1
    set(findobj('tag','radiobutton1'),'value',0);
    set(findobj('tag','radiobutton3'),'value',0);
    set(findobj('tag','radiobutton4'),'value',0);
    set(findobj('tag','radiobutton5'),'value',0);
    set(findobj('tag','radiobutton6'),'value',0);
    set(findobj('tag','radiobutton7'),'value',0);
    set(findobj('tag','radiobutton2'),'value',0);
    set(findobj('tag','radiobutton9'),'value',0);
else
    set(findobj('tag','radiobutton8'),'value',1);
end
radio1=0;
radio2=0;
radio3=0;
radio4=0;
radio5=0;
radio6=0;
radio7=0;
radio8=1;
radio9=0;
% Hint: get(hObject,'Value') returns toggle state of radiobutton8


% --- Executes on button press in radiobutton9.
function radiobutton9_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global  radio1 radio2 radio3 radio4 radio5 radio6 radio7 radio8 radio9
radiobutton1=get(findobj('tag','radiobutton1'),'value');  
radiobutton2=get(findobj('tag','radiobutton2'),'value');  
radiobutton3=get(findobj('tag','radiobutton3'),'value');  
radiobutton4=get(findobj('tag','radiobutton4'),'value');  
radiobutton5=get(findobj('tag','radiobutton5'),'value');  
radiobutton6=get(findobj('tag','radiobutton6'),'value');  
radiobutton7=get(findobj('tag','radiobutton7'),'value');  
radiobutton8=get(findobj('tag','radiobutton8'),'value');  
radiobutton9=get(findobj('tag','radiobutton9'),'value');  
if radiobutton9==1
    set(findobj('tag','radiobutton1'),'value',0);
    set(findobj('tag','radiobutton3'),'value',0);
    set(findobj('tag','radiobutton4'),'value',0);
    set(findobj('tag','radiobutton5'),'value',0);
    set(findobj('tag','radiobutton6'),'value',0);
    set(findobj('tag','radiobutton7'),'value',0);
    set(findobj('tag','radiobutton8'),'value',0);
    set(findobj('tag','radiobutton2'),'value',0);
else
    set(findobj('tag','radiobutton1'),'value',0);
    set(findobj('tag','radiobutton2'),'value',0);
    set(findobj('tag','radiobutton3'),'value',0);
    set(findobj('tag','radiobutton4'),'value',0);
    set(findobj('tag','radiobutton5'),'value',0);
    set(findobj('tag','radiobutton6'),'value',0);
    set(findobj('tag','radiobutton7'),'value',0);
    set(findobj('tag','radiobutton8'),'value',0);
    set(findobj('tag','radiobutton9'),'value',1);
end
radio1=0;
radio2=0;
radio3=0;
radio4=0;
radio5=0;
radio6=0;
radio7=0;
radio8=0;
radio9=1;
% Hint: get(hObject,'Value') returns toggle state of radiobutton9
