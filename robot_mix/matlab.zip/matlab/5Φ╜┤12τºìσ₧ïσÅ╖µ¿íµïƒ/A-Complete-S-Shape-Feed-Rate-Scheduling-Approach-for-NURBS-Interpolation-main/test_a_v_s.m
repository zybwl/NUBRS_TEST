clc;clear;close all;
J = 2;
a_max = 10;

v_begin = 30;
a_array = zeros(1,1000);
v_array = zeros(1,1000);
s_array = zeros(1,1000);
v_start = v_begin;
s_start = 0;

direct = 1;
for i = 1:1000
    t = i/100;
    if t<= 5
        a_array(i) = J* t;
    else
        a_array(i) = a_max - (t - 5)*2;
    end
    v_array(i) = v_start + a_array(i) / 100;
    s_array(i) = s_start + v_array(i) / 100;
    v_start = v_array(i);
    s_start = s_array(i); 
end

figure(1)
plot(1:1000, a_array,'LineWidth',4);
set(gca,'FontSize',30,'FontWeight','bold','FontName','Times New Roman')
xlabel('Time(s)','FontSize',30,'FontWeight','bold','FontName','Times New Roman')
ylabel('ACC(mm^2/s)','FontSize',30,'FontWeight','bold','FontName','Times New Roman')

figure(2)
plot(1:1000, v_array,'LineWidth',4);
set(gca,'FontSize',30,'FontWeight','bold','FontName','Times New Roman')
xlabel('Time(s)','FontSize',30,'FontWeight','bold','FontName','Times New Roman')
ylabel('VEC(mm^2/s)','FontSize',30,'FontWeight','bold','FontName','Times New Roman')

figure(3)
plot(1:1000, s_array,'LineWidth',4);
set(gca,'FontSize',30,'FontWeight','bold','FontName','Times New Roman')
xlabel('Time(s)','FontSize',30,'FontWeight','bold','FontName','Times New Roman')
ylabel('Length(mm)','FontSize',30,'FontWeight','bold','FontName','Times New Roman')


vi1 = v_begin;
vi = v_array(end);
k = (vi^3 + vi1*vi^2 - vi1^2*vi - vi1^3)/J;%
si = s_array(end)^2;
xishu = k/ si;

p = -4/9 *v_begin^2;
q = -8/27*v_begin^3 - s_array(end)^2;
c = v_begin /3;
delta = sqrt(q^2 + p^3);
v_end = (-q+delta)^(1/3) + (-q-delta)^(1/3)-c


% for i = 1:999
%     
%     vi1 = v_array(i);
%     vi = v_array(i+1);
%     k = (vi^3 + vi1*vi^2 - vi1^2*vi - vi^3)/J;
%     si = (s_array(i+1) - s_array(i))^2;
%     xishu = k/ si
%     
% end

