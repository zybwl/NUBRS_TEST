function [sys,x0,str,ts] = jiaodu(t,x,u,flag)
switch flag,
    case 0,
        [sys,x0,str,ts]=mdlInitializeSizes;
    case 2,
        sys=mdlUpdate(t,x,u);
    case 3,
        sys=mdlOutputs(t,x,u);
    case {1,4,9},
        sys=[];
    otherwise
        error(['Unhandled flag = ',num2str(flag)]);
end

function [sys,x0,str,ts]=mdlInitializeSizes
global GUIStopFlag Stop_flag Slider1_Value Slider2_Value a Left_Flag Right_Flag Up_Flag Down_Flag XPendTop6 YPendTop6 r l dl R
Slider1_Value=0;
Slider2_Value=0;
a=zeros(1,7);
Left_Flag=0;
Right_Flag=0;
Up_Flag=0;
Down_Flag=0;
l=0;
dl=0.1;
sizes = simsizes;
sizes.NumContStates  = 0;
sizes.NumDiscStates  = 7;
sizes.NumOutputs     = 7;
sizes.NumInputs      = 13;
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 1;   % at least one sample time is needed
sys = simsizes(sizes);
x0  = [zeros(1,7)];
str = [];
ts  = [0.1 0];

function sys=mdlUpdate(t,x,u)
global GUIStopFlag Stop_flag Slider1_Value Slider2_Value a Left_Flag Right_Flag Up_Flag Down_Flag XPendTop6 YPendTop6 r l dl R L SS
ArmParaInit;
L1=11.5623;
L2=9.34547;
L3=9.33026;
L4=10.06517;
L5=10.6135;
L6=4.57025;

angle1=(69.058-u(1))*pi/180;
angle2=(175.9865-u(2))*pi/180;
angle3=(149.6604-u(3))*pi/180;
angle4=(141.1757+u(4))*pi/180;
angle5=(160.1881+u(5))*pi/180;
angle6=(149.2637+u(6))*pi/180;

xx(1)=angle1;
x12=L1*cos(xx(1));
y12=L1*sin(xx(1));
xx(2)=xx(1)+angle2-pi;
x23=x12+L2*cos(xx(2));
y23=y12+L2*sin(xx(2));
xx(3)=xx(2)+angle3-pi;
x34=x23+L3*cos(xx(3));
y34=y23+L3*sin(xx(3));
xx(4)=xx(3)+angle4-pi;
x45=x34+L4*cos(xx(4));
y45=y34+L4*sin(xx(4));
xx(5)=xx(4)+angle5-pi;
x56=x45+L5*cos(xx(5));
y56=y45+L5*sin(xx(5));
xx(6)=xx(5)+angle6-pi;
x66=x56+L6*cos(xx(6));
y66=y56+L6*sin(xx(6));
L_Distance=sqrt(x66^2+y66^2);
K_Ramp=y66/x66;

if ((angle1>pi/2) &&(a(1,1)>0)) ||  (angle1<0) &&( a(1,1)<0)
    Q(1)=10000;
else
    Q(1)=4;
end

if ((angle2>pi) &&(a(1,2)>0))  ||   ( (angle2<0) &&(a(1,2)<0))
    Q(2)=10000;
else
    Q(2)=3;
end

if ((angle3>pi) &&(a(1,3)>0) )  ||    ( (angle3<0) &&(a(1,3)<0 ) )
    Q(3)=10000;
else
    Q(3)=3;
end

if ((angle4>pi) &&(a(1,4)>0) )  ||    ( (angle4<0) &&(a(1,4)<0 ) )
    Q(4)=10000;
else
    Q(4)=2;
end

if ((angle5>pi) &&(a(1,5)>0)) || ( (angle5<0) &&(a(1,5)<0 ) )
    Q(5)=10000;
else
    Q(5)=2;
end

if ((angle6>pi) &&(a(1,6)>0)) || ( (angle6<0) &&(a(1,6)<0 ) )
    Q(6)=10000;
else
    Q(6)=1;
end

Total_Q=Q(1)+Q(2)+Q(3)+Q(4)+Q(5)+Q(6);

% if Slider1_Value>30 && abs(Slider2_Value)<30
%     b=2;
%     %     XSpeed=Slider1_Value;  %������
% elseif (Slider1_Value<-30) && (abs(Slider2_Value)<30)
%     b=3;
%     %     XSpeed=Slider1_Value;  %������
% elseif Slider2_Value>30 && abs(Slider1_Value)<30
%     b=4;
%     %     YSpeed=Slider2_Value;  %������
% elseif Slider2_Value<-30 && abs(Slider1_Value)<30
%     b=5;
%     %     YSpeed=Slider2_Value;  %������
% else b=1;
% end

if u(8)>30 && u(9)<30 && u(10)<30 && u(11)<30
    b=2; %������
elseif u(8)<30 && u(9)>30 && u(10)<30 && u(11)<30
    b=3; %������
elseif u(8)<30 && u(9)<30 && u(10)>30 && u(11)<30
    b=4; %������
elseif u(8)<30 && u(9)<30 && u(10)<30 && u(11)>30
    b=5;  %������
else b=1;
end

   b=7;
switch b,
    case 1,
        a=[0 0 0 0 0 0 0];
        
    case 2,
        if Right_Flag==0  %��
            Left_Flag=0;
            Right_Flag=1;
            Up_Flag=0;
            Down_Flag=0;
            YPendTop6=y66;     %����ʼ�߶����ˮƽ���ߵĸ߶�
        end
        
        %         if x66<sqrt(55^2-YPendTop6^2)
        if x66<49
            XSpeed=0.5;
            YSpeed =y66-YPendTop6;
        else
            XSpeed=0;
            YSpeed =0;
        end
        Q26=Para(L1,L2,L3,L4,L5,L6,angle1,angle2,angle3,angle4,angle5,angle6);
        
        Y21=[XSpeed;YSpeed];
        X=New_Min_Warp(Q26,Y21,Q);
        
        delta_angle1=X(1);delta_angle2=X(2);delta_angle3=X(3);
        delta_angle4=X(4);delta_angle5=X(5);delta_angle6=X(6);
        
        a(1,1)=Sort0(angle1,L1_INI_ANGLE,L1_A1A2,L1_A1A3,delta_angle1);
        a(1,2)=Sort2(angle2,L2_INI_ANGLE,L2_ANGLE123,L2_C1C2,L2_C2C3,L2_C3C4,L2_C4C5,L2_C5C6,L2_C2C5,L2_C2C6,delta_angle2);
        a(1,3)=Sort2(angle3,L3_INI_ANGLE,L3_ANGLE123,L3_C1C2,L3_C2C3,L3_C3C4,L3_C4C5,L3_C5C6,L3_C2C5,L3_C2C6,delta_angle3);
        a(1,4)=Sort2(angle4,L4_INI_ANGLE,L4_ANGLE123,L4_C1C2,L4_C2C3,L4_C3C4,L4_C4C5,L4_C5C6,L4_C2C5,L4_C2C6,delta_angle4) ;
        a(1,5)=Sort2(angle5,L5_INI_ANGLE,L5_ANGLE123,L5_C1C2,L5_C2C3,L5_C3C4,L5_C4C5,L5_C5C6,L5_C2C5,L5_C2C6,delta_angle5);
        a(1,6)=Sort3(angle6,L6_INI_ANGLE,L6_ANGLE123,L6_D1D2,L6_D2D3,L6_D3D4,L6_D4D5,L6_D5D6,L6_D2D5,delta_angle6);
        
    case 3,
        
        if Left_Flag==0
            Left_Flag=1;
            Right_Flag=0;
            Up_Flag=0;
            Down_Flag=0;
            YPendTop6=y66;   %����ʼ�߶����ˮƽ���ߵĸ߶�
        end
        
        %         if L_Distance<52
        if x66>15
            XSpeed=-0.5;
            YSpeed =y66-YPendTop6;
        else
            XSpeed=0;
            YSpeed =0;
        end
        
        Q26=Para(L1,L2,L3,L4,L5,L6,angle1,angle2,angle3,angle4,angle5,angle6)
        
        Y21=[XSpeed;YSpeed];
        X=New_Min_Warp(Q26,Y21,Q);
        
        delta_angle1=X(1);delta_angle2=X(2);delta_angle3=X(3);
        delta_angle4=X(4);delta_angle5=X(5);delta_angle6=X(6);
        
        a(1,1)=Sort0(angle1,L1_INI_ANGLE,L1_A1A2,L1_A1A3,delta_angle1);
        a(1,2)=Sort2(angle2,L2_INI_ANGLE,L2_ANGLE123,L2_C1C2,L2_C2C3,L2_C3C4,L2_C4C5,L2_C5C6,L2_C2C5,L2_C2C6,delta_angle2);
        a(1,3)=Sort2(angle3,L3_INI_ANGLE,L3_ANGLE123,L3_C1C2,L3_C2C3,L3_C3C4,L3_C4C5,L3_C5C6,L3_C2C5,L3_C2C6,delta_angle3);
        a(1,4)=Sort2(angle4,L4_INI_ANGLE,L4_ANGLE123,L4_C1C2,L4_C2C3,L4_C3C4,L4_C4C5,L4_C5C6,L4_C2C5,L4_C2C6,delta_angle4) ;
        a(1,5)=Sort2(angle5,L5_INI_ANGLE,L5_ANGLE123,L5_C1C2,L5_C2C3,L5_C3C4,L5_C4C5,L5_C5C6,L5_C2C5,L5_C2C6,delta_angle5);
        a(1,6)=Sort3(angle6,L6_INI_ANGLE,L6_ANGLE123,L6_D1D2,L6_D2D3,L6_D3D4,L6_D4D5,L6_D5D6,L6_D2D5,delta_angle6);
        
    case 4,
        if Down_Flag==0
            Left_Flag=0;
            Right_Flag=0;
            Up_Flag=0;
            Down_Flag=1;
            XPendTop6=x66;
        end
        
        %         if L_Distance<52
        if    y66<27
            YSpeed=-0.5;
            XSpeed =XPendTop6-x66;
        else
            XSpeed=0;
            YSpeed =0;
        end
        
        Q26=Para(L1,L2,L3,L4,L5,L6,angle1,angle2,angle3,angle4,angle5,angle6)
        
        Y21=[XSpeed;YSpeed];
        X=New_Min_Warp(Q26,Y21,Q);
        
        delta_angle1=X(1);delta_angle2=X(2);delta_angle3=X(3);
        delta_angle4=X(4);delta_angle5=X(5);delta_angle6=X(6);
        
        a(1,1)=Sort0(angle1,L1_INI_ANGLE,L1_A1A2,L1_A1A3,delta_angle1);
        a(1,2)=Sort2(angle2,L2_INI_ANGLE,L2_ANGLE123,L2_C1C2,L2_C2C3,L2_C3C4,L2_C4C5,L2_C5C6,L2_C2C5,L2_C2C6,delta_angle2);
        a(1,3)=Sort2(angle3,L3_INI_ANGLE,L3_ANGLE123,L3_C1C2,L3_C2C3,L3_C3C4,L3_C4C5,L3_C5C6,L3_C2C5,L3_C2C6,delta_angle3);
        a(1,4)=Sort2(angle4,L4_INI_ANGLE,L4_ANGLE123,L4_C1C2,L4_C2C3,L4_C3C4,L4_C4C5,L4_C5C6,L4_C2C5,L4_C2C6,delta_angle4) ;
        a(1,5)=Sort2(angle5,L5_INI_ANGLE,L5_ANGLE123,L5_C1C2,L5_C2C3,L5_C3C4,L5_C4C5,L5_C5C6,L5_C2C5,L5_C2C6,delta_angle5);
        a(1,6)=Sort3(angle6,L6_INI_ANGLE,L6_ANGLE123,L6_D1D2,L6_D2D3,L6_D3D4,L6_D4D5,L6_D5D6,L6_D2D5,delta_angle6);
        
    case 5,
        if Up_Flag==0
            Left_Flag=0;
            Right_Flag=0;
            Up_Flag=1;
            Down_Flag=0;
            XPendTop6=x66;     %����ʼˮƽλ����ɴ�ֱ���ߵĲ���ϵ
        end
        
        if y66>-32
            YSpeed=0.5;
            XSpeed =XPendTop6-x66;
        else
            XSpeed=0;
            YSpeed =0;
        end
        Q26=Para(L1,L2,L3,L4,L5,L6,angle1,angle2,angle3,angle4,angle5,angle6)
        
        Y21=[XSpeed;YSpeed];
        X=New_Min_Warp(Q26,Y21,Q);
        
        delta_angle1=X(1);delta_angle2=X(2);delta_angle3=X(3);
        delta_angle4=X(4);delta_angle5=X(5);delta_angle6=X(6);
        
        a(1,1)=Sort0(angle1,L1_INI_ANGLE,L1_A1A2,L1_A1A3,delta_angle1);
        a(1,2)=Sort2(angle2,L2_INI_ANGLE,L2_ANGLE123,L2_C1C2,L2_C2C3,L2_C3C4,L2_C4C5,L2_C5C6,L2_C2C5,L2_C2C6,delta_angle2);
        a(1,3)=Sort2(angle3,L3_INI_ANGLE,L3_ANGLE123,L3_C1C2,L3_C2C3,L3_C3C4,L3_C4C5,L3_C5C6,L3_C2C5,L3_C2C6,delta_angle3);
        a(1,4)=Sort2(angle4,L4_INI_ANGLE,L4_ANGLE123,L4_C1C2,L4_C2C3,L4_C3C4,L4_C4C5,L4_C5C6,L4_C2C5,L4_C2C6,delta_angle4) ;
        a(1,5)=Sort2(angle5,L5_INI_ANGLE,L5_ANGLE123,L5_C1C2,L5_C2C3,L5_C3C4,L5_C4C5,L5_C5C6,L5_C2C5,L5_C2C6,delta_angle5);
        a(1,6)=Sort3(angle6,L6_INI_ANGLE,L6_ANGLE123,L6_D1D2,L6_D2D3,L6_D3D4,L6_D4D5,L6_D5D6,L6_D2D5,delta_angle6);
        
    case 7,
        if Right_Flag==0  %��
            Left_Flag=0;
            Right_Flag=1;
            Up_Flag=0;
            Down_Flag=0;
            YPendTop6=y66;     %����ʼ�߶����ˮƽ���ߵĸ߶�
            r=x66;
            R=r;
            L=0;
            SS=0;
        end
        
        %         if x66<sqrt(55^2-YPendTop6^2)
        if x66<49
            %             XSpeed=0.5;
            YSpeed =y66-YPendTop6;
        else
            XSpeed=0;
            YSpeed =0;
        end
        Q26=Para(L1,L2,L3,L4,L5,L6,angle1,angle2,angle3,angle4,angle5,angle6);
        
          if L<30
               L=L+dl;
              [Next_theta, next_x , next_z]=Route_Plan([r,0],90,L);
           elseif SS<30 
               SS=SS+dl;
               [Next_theta, next_x , next_z]=Route_Plan([r+L*cos(-135/180*pi),L*sin(-135/180*pi)],135,SS);
           else
               [Next_theta, next_x , next_z]=Route_Plan([r,0],0,-10);
           end 
           S=sqrt(next_x^2+next_z^2);
           deta=Next_theta-u(7);
           a(1,7)=deta ;
           XSpeed=S-x66;
           Y21=[XSpeed;YSpeed];
        
        X=New_Min_Warp(Q26,Y21,Q);
        
        delta_angle1=X(1);delta_angle2=X(2);delta_angle3=X(3);
        delta_angle4=X(4);delta_angle5=X(5);delta_angle6=X(6);
        
        a(1,1)=Sort0(angle1,L1_INI_ANGLE,L1_A1A2,L1_A1A3,delta_angle1);
        a(1,2)=Sort2(angle2,L2_INI_ANGLE,L2_ANGLE123,L2_C1C2,L2_C2C3,L2_C3C4,L2_C4C5,L2_C5C6,L2_C2C5,L2_C2C6,delta_angle2);
        a(1,3)=Sort2(angle3,L3_INI_ANGLE,L3_ANGLE123,L3_C1C2,L3_C2C3,L3_C3C4,L3_C4C5,L3_C5C6,L3_C2C5,L3_C2C6,delta_angle3);
        a(1,4)=Sort2(angle4,L4_INI_ANGLE,L4_ANGLE123,L4_C1C2,L4_C2C3,L4_C3C4,L4_C4C5,L4_C5C6,L4_C2C5,L4_C2C6,delta_angle4) ;
        a(1,5)=Sort2(angle5,L5_INI_ANGLE,L5_ANGLE123,L5_C1C2,L5_C2C3,L5_C3C4,L5_C4C5,L5_C5C6,L5_C2C5,L5_C2C6,delta_angle5);
        a(1,6)=Sort3(angle6,L6_INI_ANGLE,L6_ANGLE123,L6_D1D2,L6_D2D3,L6_D3D4,L6_D4D5,L6_D5D6,L6_D2D5,delta_angle6);
end
if Total_Q>50000
    a=[0 0 0 0 0 0];
end
% for i=1:6
%     if a(1,i)<-0.01
%         a(1,i)=-0.01;
%     else if a(1,i)>0.01
%             a(1,i)=0.01;
%         end
%     end
% end
% temp=max(abs(a));
% if temp>0.01
%     a=a/temp*0.01;
% end

x(1)=-a(1,1);
x(2)=a(1,2);
x(3)=a(1,3);
x(4)=a(1,4);
x(5)=-a(1,5);
x(6)=a(1,6);
x(7)=a(1,7);

% x( 8 )=u(2);
% x( 9 )=u(3);
% x(10)=u(4);
% x(11)=u(5);
% x(12)=Q(4);
% x(13)=Q(5);
sys =x;

function sys=mdlOutputs(t,x,u)
for i=1:7
    sys(i) = x(i);
end

function  Q26=Para(L1,L2,L3,L4,L5,L6,angle1,angle2,angle3,angle4,angle5,angle6)
Q26=[-L1*sin(angle1)+L2*sin(angle1+angle2)-L3*sin(angle1+angle2+angle3)+L4*sin(angle1+angle2+angle3+angle4)-L5*sin(angle1+angle2+angle3+angle4+angle5)+L6*sin(angle1+angle2+angle3+angle4+angle5+angle6) ...
    L2*sin(angle1+angle2)-L3*sin(angle1+angle2+angle3)+L4*sin(angle1+angle2+angle3+angle4)-L5*sin(angle1+angle2+angle3+angle4+angle5)+L6*sin(angle1+angle2+angle3+angle4+angle5+angle6)...
    -L3*sin(angle1+angle2+angle3)+L4*sin(angle1+angle2+angle3+angle4)-L5*sin(angle1+angle2+angle3+angle4+angle5)+L6*sin(angle1+angle2+angle3+angle4+angle5+angle6) ...
    L4*sin(angle1+angle2+angle3+angle4)-L5*sin(angle1+angle2+angle3+angle4+angle5)+L6*sin(angle1+angle2+angle3+angle4+angle5+angle6) ...
    -L5*sin(angle1+angle2+angle3+angle4+angle5)+L6*sin(angle1+angle2+angle3+angle4+angle5+angle6)...
    L6*sin(angle1+angle2+angle3+angle4+angle5+angle6);
    -L1*cos(angle1)+L2*cos(angle1+angle2)-L3*cos(angle1+angle2+angle3)+L4*cos(angle1+angle2+angle3+angle4)-L5*cos(angle1+angle2+angle3+angle4+angle5)+L6*cos(angle1+angle2+angle3+angle4+angle5+angle6) ...
    L2*cos((angle1+angle2))-L3*cos((angle1+angle2+angle3))+L4*cos(angle1+angle2+angle3+angle4)-L5*cos(angle1+angle2+angle3+angle4+angle5)+L6*cos(angle1+angle2+angle3+angle4+angle5+angle6) ...
    -L3*cos(angle1+angle2+angle3)+L4*cos(angle1+angle2+angle3+angle4)-L5*cos(angle1+angle2+angle3+angle4+angle5)+L6*cos(angle1+angle2+angle3+angle4+angle5+angle6) ...
    L4*cos(angle1+angle2+angle3+angle4)-L5*cos(angle1+angle2+angle3+angle4+angle5)+L6*cos(angle1+angle2+angle3+angle4+angle5+angle6) ...
    -L5*cos(angle1+angle2+angle3+angle4+angle5)+L6*cos(angle1+angle2+angle3+angle4+angle5+angle6)...
    L6*cos(angle1+angle2+angle3+angle4+angle5+angle6)];

function  Oil_Pump_AB_Length=Sort0(Arm_AB_angle,Arm_initial_angle,A1_A2,A1_A3,delta_angle)
Angle_A213 = Arm_initial_angle+Arm_AB_angle;
Length=sqrt(A1_A2^2+A1_A3^2-2*A1_A2*A1_A3*cos(Angle_A213));
Angle_A213 = Arm_initial_angle+Arm_AB_angle+delta_angle;
Length1=sqrt(A1_A2^2+A1_A3^2-2*A1_A2*A1_A3*cos(Angle_A213));
Oil_Pump_AB_Length=(Length1-Length)/1000;  %��λM

function  Oil_Pump_AB_Length=Sort2(Arm_AB_angle,Arm_initial_angle,Angle_C123,C1_C2,C2_C3,C3_C4,C4_C5,C5_C6,C2_C5,C2_C6,delta_angle)
Angle_C234 = Arm_initial_angle+Arm_AB_angle;
C2_C4 = sqrt(C2_C3^2+C3_C4^2-2*C2_C3*C3_C4*cos(Angle_C234));
Angle_C324=acos((C2_C3^2+C2_C4^2-C3_C4^2)/2/C2_C3/C2_C4);

if Angle_C234>pi
    Angle_C324=-Angle_C324;
end
Angle_C425=acos((C2_C4^2+C2_C5^2-C4_C5^2)/2/C2_C4/C2_C5);
Angle_C526=acos((C2_C5^2+C2_C6^2-C5_C6^2)/2/C2_C5/C2_C6);
Angle_C126=Angle_C123-Angle_C324-Angle_C425-Angle_C526;
Length=sqrt(C1_C2^2+C2_C6^2-2*C1_C2*C2_C6*cos(Angle_C126));

Angle_C234 = Arm_initial_angle+Arm_AB_angle+delta_angle;
C2_C4 = sqrt(C2_C3^2+C3_C4^2-2*C2_C3*C3_C4*cos(Angle_C234));
Angle_C324=acos((C2_C3^2+C2_C4^2-C3_C4^2)/2/C2_C3/C2_C4);

if Angle_C234>pi
    Angle_C324=-Angle_C324;
end
Angle_C425=acos((C2_C4^2+C2_C5^2-C4_C5^2)/2/C2_C4/C2_C5);
Angle_C526=acos((C2_C5^2+C2_C6^2-C5_C6^2)/2/C2_C5/C2_C6);
Angle_C126=Angle_C123-Angle_C324-Angle_C425-Angle_C526;
Length1=sqrt(C1_C2^2+C2_C6^2-2*C1_C2*C2_C6*cos(Angle_C126));
Oil_Pump_AB_Length=(Length1-Length)/1000;  %��λM

function  Oil_Pump_AB_Length=Sort3(Arm_AB_angle,Arm_initial_angle,Angle_D123,D1_D2,D2_D3,D3_D4,D4_D5,D5_D6,D2_D5,delta_angle)
Angle_D234 = Arm_initial_angle+Arm_AB_angle;
Angle_D456=199.4445/180*pi;
D2_D4 = sqrt(D2_D3^2+D3_D4^2-2*D2_D3*D3_D4*cos(Angle_D234));
Angle_D324=acos((D2_D3^2+D2_D4^2-D3_D4^2)/2/D2_D3/D2_D4);

if Angle_D234>pi
    Angle_D324=-Angle_D324;
end
Angle_D425=acos((D2_D4^2+D2_D5^2-D4_D5^2)/2/D2_D4/D2_D5);
Angle_D254=acos((D2_D5^2+D4_D5^2-D2_D4^2)/2/D2_D5/D4_D5);
Angle_D256=Angle_D456-Angle_D254;
D2_D6=sqrt(D2_D5^2+D5_D6^2-2*D2_D5*D5_D6*cos(Angle_D256));
Angle_D526=acos((D2_D5^2+D2_D6^2-D5_D6^2)/2/D2_D5/D2_D6);
Angle_D126=Angle_D123-Angle_D526-Angle_D425-Angle_D324;
Length=sqrt(D1_D2^2+D2_D6^2-2*D1_D2*D2_D6*cos(Angle_D126));

Angle_D234 = Arm_initial_angle+Arm_AB_angle+delta_angle;
Angle_D456=199.4445/180*pi;
D2_D4 = sqrt(D2_D3^2+D3_D4^2-2*D2_D3*D3_D4*cos(Angle_D234));
Angle_D324=acos((D2_D3^2+D2_D4^2-D3_D4^2)/2/D2_D3/D2_D4);

if Angle_D234>pi
    Angle_D324=-Angle_D324;
end
Angle_D425=acos((D2_D4^2+D2_D5^2-D4_D5^2)/2/D2_D4/D2_D5);
Angle_D254=acos((D2_D5^2+D4_D5^2-D2_D4^2)/2/D2_D5/D4_D5);
Angle_D256=Angle_D456-Angle_D254;
D2_D6=sqrt(D2_D5^2+D5_D6^2-2*D2_D5*D5_D6*cos(Angle_D256));
Angle_D526=acos((D2_D5^2+D2_D6^2-D5_D6^2)/2/D2_D5/D2_D6);
Angle_D126=Angle_D123-Angle_D526-Angle_D425-Angle_D324;
Length1=sqrt(D1_D2^2+D2_D6^2-2*D1_D2*D2_D6*cos(Angle_D126));
Oil_Pump_AB_Length=(Length1-Length)/1000;  %��λM

function X=New_Min_Warp(Q26,Y21,Q)
Q_Transfer=[sqrt(Q(1)) 0 0 0 0 0;0  sqrt(Q(2)) 0 0 0 0 ;0 0  sqrt(Q(3)) 0 0 0;0 0 0 sqrt(Q(4)) 0 0 ;0 0 0 0 sqrt(Q(5)) 0;0 0 0 0 0 sqrt(Q(6))];
New_Q26=Q26/Q_Transfer;
X=Q_Transfer\pinv(New_Q26)*Y21;

function        [theta, X , Z]=Route_Plan(Point,Angle,L)
% R=L/8;                 %L/length(N);
X=Point(1)+L*cos(Angle/180*pi);
Z=Point(2)+L*sin(Angle/180*pi);
if X>0;
theta=atan(Z/X);
else
theta=atan(Z/X)+pi;   
end
theta=theta*180/pi;
if theta>180
    theta=theta-360;
end