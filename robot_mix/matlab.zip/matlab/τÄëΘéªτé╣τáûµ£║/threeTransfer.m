
%���A��е����
machine_coord_a = [10 10 10]';
%���A�Ĺ�������
work_coord_a = [0 0 2]';

%���A��x����ת45�Ⱥ�����B
rot_x_angle = pi/4;
rot_x_matrix = [1 0 0; 0 cos(rot_x_angle) -sin(rot_x_angle); 0 sin(rot_x_angle) cos(rot_x_angle)];
machine_coord_b = rot_x_matrix * machine_coord_a
% machine_coord_b = machine_coord_a + work_coord_b - work_coord_a;

a = cos(rot_x_angle) - 1;
b = sin(rot_x_angle);
t1 = a/(a^2 + b^2);
t2 = b/(a^2 + b^2);
v_ba = machine_coord_b - machine_coord_a
v_ao = [v_ba(2) * t1 + v_ba(3) * t2 ;v_ba(3) * t1 - v_ba(2) * t2 ];
machine_oy = machine_coord_a(2) - v_ao(1);
machine_oz = machine_coord_a(3) - v_ao(2);

% % %����z����ת45�Ⱥ�����C
rot_z_angle = pi/6;
rot_z_matrix = [cos(rot_z_angle) -sin(rot_z_angle) 0;sin(rot_z_angle) cos(rot_z_angle) 0; 0 0 1];
machine_coord_c = rot_z_matrix * machine_coord_b
% machine_coord_c = machine_coord_a + work_coord_c - work_coord_a;

a = cos(rot_z_angle) - 1;
b = sin(rot_z_angle);
t1 = a/(a^2 + b^2);
t2 = b/(a^2 + b^2);
v_cb = machine_coord_c - machine_coord_b;
v_bo = [v_cb(1) * t1 + v_cb(3) * t2 ; v_cb(3) * t1 - v_cb(1) * t2 ];
machine_ox = machine_coord_b(2) - v_bo(1)
machine_oz = machine_coord_b(3) - v_bo(2)
