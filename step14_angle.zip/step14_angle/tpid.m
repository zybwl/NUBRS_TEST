ts=0.001;
sys=tf(400,[1,50,0]);
dsys=c2d(sys,ts,'z');
[num,den]=tfdata(dsys,'v');
u1=0;u2=0;u3=0;
y1=0;y2=0;y3=0;
x=[0 0 0];
e1=0;e2=0;

for k=1:1:1000
    time(k)=k*ts;
    rin(k)=1;
    kp=5.5;
    ki=0.1;
    kd=9;
    
    du(k)=kp*x(1)+kd*x(2)+ki*x(3);
    u(k)=u1+du(k);
    
    if u(k)>10
        u(k)=10;
    elseif u(k)<-10
            u(k)=-10;
    end
    
    yout(k)=-den(2)*y1-den(3)*y2+num(2)*u1+num(3)*u2;
    
    e=rin(k)-yout(k);
    u3=u2;u2=u1;u1=u(k);
   y3=y2;y2=y1;y1=yout(k);
   
   x(1)=e-e1;
   x(2)=e-2*e1+e2;
   x(3)=e;
   e-2*e1+e2;
   e2=e1;
   e1=e;
end
plot(time,rin,time,yout,'r')