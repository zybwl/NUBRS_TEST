#ifndef __c2_cradle_vr_h__
#define __c2_cradle_vr_h__

/* Include files */
#include "sf_runtime/sfc_sf.h"
#include "sf_runtime/sfc_mex.h"
#include "rtwtypes.h"
#include "multiword_types.h"

/* Type Definitions */
#ifndef typedef_SFc2_cradle_vrInstanceStruct
#define typedef_SFc2_cradle_vrInstanceStruct

typedef struct {
  SimStruct *S;
  ChartInfoStruct chartInfo;
  uint32_T chartNumber;
  uint32_T instanceNumber;
  int32_T c2_sfEvent;
  uint8_T c2_tp_FreeDynamics;
  boolean_T c2_stateChanged;
  real_T c2_lastMajorTime;
  uint8_T c2_is_active_c2_cradle_vr;
  uint8_T c2_is_c2_cradle_vr;
  real_T c2_g;
  real_T c2_l;
  real_T c2_pi;
  int32_T c2_k;
  uint8_T c2_doSetSimStateSideEffects;
  const mxArray *c2_setSimStateSideEffectsInfo;
  boolean_T *c2_input0;
  real_T (*c2_p_out)[7];
  real_T (*c2_v_out)[7];
  real_T (*c2_p)[7];
  real_T (*c2_v)[7];
  boolean_T *c2_input1;
  boolean_T *c2_input2;
  boolean_T *c2_input3;
  boolean_T *c2_input4;
  boolean_T *c2_input5;
  boolean_T *c2_input6;
} SFc2_cradle_vrInstanceStruct;

#endif                                 /*typedef_SFc2_cradle_vrInstanceStruct*/

/* Named Constants */

/* Variable Declarations */
extern struct SfDebugInstanceStruct *sfGlobalDebugInstanceStruct;

/* Variable Definitions */

/* Function Declarations */
extern const mxArray *sf_c2_cradle_vr_get_eml_resolved_functions_info(void);

/* Function Definitions */
extern void sf_c2_cradle_vr_get_check_sum(mxArray *plhs[]);
extern void c2_cradle_vr_method_dispatcher(SimStruct *S, int_T method, void
  *data);

#endif
