clc;clear;close all;
a = -3*pi/2:2*pi/40: pi/2;
points(:,1) = cos(a);
points(:,2) = sin(a);

num_cpts = 6;
ploy_n = 200;
% controls_points = fitting_close_curve(points, num_cpts);
[new_point,controls_points] = fitting(points, num_cpts, ploy_n);

plot(new_point(:,1),new_point(:,2),'-b'); 
hold on
plot(controls_points(:,1), controls_points(:,2), '*--')
axis equal