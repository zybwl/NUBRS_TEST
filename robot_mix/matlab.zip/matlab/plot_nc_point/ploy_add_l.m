% file_name   ��Ҫѡ���nc�����ļ� 
% p = 3       ��֤��ϵĴ���2�׿ɵ�
% start_line_no ��Ҫ��϶ε���ʼ����
% end_line_no   ��Ҫ��϶εĽ�������
% ploy_n        ���������Ҫ���ٸ���
% function ploy_nc(file_name, p ,start_line_no,end_line_no , ploy_n)
% 
clc;clear;
file_name = 'SIJIAO.NC';
start_line_no = 38;
end_line_no = 58;
p = 6;
ploy_n = 30;

[line_before, point_struct_array ,line_end] = get_nc_data(file_name,start_line_no,end_line_no);
n = size(point_struct_array,2);
U = zeros(1,n + p + 1);

for k = 1:n
    X = point_struct_array(k).X;
    Y = point_struct_array(k).Y;
    Z = point_struct_array(k).Z;
    point(:,k) = [X;Y;Z];
end

L = 0;
for k = 1: n - p   
    vect = point(:,k + 1 : k + p) - point(:,k: k + p -1);       
    for i = 1:p
        L = L + sqrt(vect(:,i)'* vect(:,i));
    end   
    U(1,p + k + 1) = L;
end
U  = U / L;
U(n + 2: end) = 1;

index = 1;
for u = 0:1/ploy_n:1    
    span = findspan(n-1 , p , u ,U );
    N = basisfun(span,u,p,U);   
    new_point(:,index) = point(: , span - p + 1 : span + 1) * N';
    index = index + 1;
end
    
plot3(point(1,:),point(2,:),point(3,:),'-bo');
hold on

for k =1: size(new_point,2)
    plot3(new_point(1,1:k),new_point(2,1:k),new_point(3,1:k),'-ro');  
    pause(0.5);
end






     
     











