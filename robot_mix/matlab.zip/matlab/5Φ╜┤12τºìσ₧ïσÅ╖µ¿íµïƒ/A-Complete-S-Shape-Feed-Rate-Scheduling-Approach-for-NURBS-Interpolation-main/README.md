# A-Complete-S-Shape-Feed-Rate-Scheduling-Approach-for-NURBS-Interpolation
This Code Contains a jerk limited NURBS interpolation algorithm which is derived from "A completeS-shape feed rate scheduling approach for NURBS interpolator" by "Xu Du,JieHuang,Li-MinZhu"

To run this code just simply open "CompeletjerklimitednurbsXYZ.m", Change the input parameters (Velocity,ACC,Initial Velocity,...) and wait for the output

Remember that ControlPoints.txt is the coordinate of the control points and the .txt file should be created as the sample uploaded to the repository

for any further information you are welcomed to contact me "mehrdad_sadeghiye@yahoo.com"
 
