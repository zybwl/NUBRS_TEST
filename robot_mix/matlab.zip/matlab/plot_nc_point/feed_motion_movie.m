function varargout = feed_motion_movie(varargin)
% FEED_MOTION_MOVIE MATLAB code for feed_motion_movie.fig
%      FEED_MOTION_MOVIE, by itself, creates a new FEED_MOTION_MOVIE or raises the existing
%      singleton*.
%
%      H = FEED_MOTION_MOVIE returns the handle to a new FEED_MOTION_MOVIE or the handle to
%      the existing singleton*.
%
%      FEED_MOTION_MOVIE('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in FEED_MOTION_MOVIE.M with the given input arguments.
%
%      FEED_MOTION_MOVIE('Property','Value',...) creates a new FEED_MOTION_MOVIE or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before feed_motion_movie_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to feed_motion_movie_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help feed_motion_movie

% Last Modified by GUIDE v2.5 14-Jun-2019 14:13:11

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @feed_motion_movie_OpeningFcn, ...
                   'gui_OutputFcn',  @feed_motion_movie_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before feed_motion_movie is made visible.
function feed_motion_movie_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to feed_motion_movie (see VARARGIN)

% Choose default command line output for feed_motion_movie
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes feed_motion_movie wait for user response (see UIRESUME)
% uiwait(handles.figure1);
global view_x  view_y
select_view_angle_tag = findobj('tag','select_view_angle');
select_view_angle = get(select_view_angle_tag,'Value');  

switch  select_view_angle
    case 1
            view_x = 45;
            view_y = 10;
    case 2
            view_x = 0;
            view_y = 0;
    case 3
            view_x = 90;
            view_y = 0;
    otherwise 
            view_x = 0;
            view_y = 90;
    
end


% --- Outputs from this function are returned to the command line.
function varargout = feed_motion_movie_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function end_number_edit_Callback(hObject, eventdata, handles)
% hObject    handle to end_number_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of end_number_edit as text
%        str2double(get(hObject,'String')) returns contents of end_number_edit as a double


% --- Executes during object creation, after setting all properties.
function end_number_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to end_number_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function start_number_edit_Callback(hObject, eventdata, handles)
% hObject    handle to start_number_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of start_number_edit as text
%        str2double(get(hObject,'String')) returns contents of start_number_edit as a double


% --- Executes during object creation, after setting all properties.
function start_number_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to start_number_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in feed_motion.
function feed_motion_Callback(hObject, eventdata, handles)
% hObject    handle to feed_motion (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    global point_float_array Full_name
    global view_x  view_y

    
    assert(ischar(Full_name), '��ѡ����Ҫ������.NC�ļ�');
    %https://blog.csdn.net/DelSpooner/article/details/50196791
    %��ȡNC�ļ������������Իس�������char(10)���м���
    fid= fopen(Full_name);
    max_line_number = 0;
    while ~feof(fid)
        max_line_number = max_line_number + sum(fread(fid,10000,'*char')==char(10));
    end    
    fclose(fid);
       
    start_number_tag = findobj('tag','start_number_edit');
    start_line_number = str2double(get(start_number_tag,'String'));
   
    start_number_tag = findobj('tag','end_number_edit');
    end_line_number = str2double(get(start_number_tag,'String'));
   
    real_start_number = max(1, start_line_number - 10);  %��ֹѡ�е�����XYZ��������ȱʡֵ������ȡ�õ�ֵ����ȷ
      
    %fid��Ҫ���¸�ֵ����Ϊ֮ǰ�õ�ʱ���Ѿ���ѯ�����һ����
    fid= fopen(Full_name);
    line_number = 0;
    point = struct('X', 0.0, 'Y', 0.0,'Z',0.0);
    point_struct_array = [];
    tline = fgetl(fid);
    h=waitbar(0,'wait for a moment...');
    
    while ischar(tline)
        line_number = line_number + 1  ;
        
        if line_number < real_start_number || line_number > end_line_number
            tline = fgetl(fid);
            continue;
        elseif line_number > end_line_number
             break;
        end
        
        % ��ʾ���ȵ���ʾ��,��10��Ϊһ����ʾ���ڣ���ֹ��ʾ�ٶ�̫�쿴����
        process_percent = (line_number - real_start_number) / (end_line_number - real_start_number);
        if mod(line_number ,10) == 0
            waitbar(process_percent , h ,['Simulation in process:' num2str(process_percent*100) '%']);
        end
        
        expr = '[XYZ]-?[0-9]+\.?[0-9]*';
        %expr = '[XYZ]-?[0-9]+.?[0-9]+';  %���ַ�ʽ����ֻҪ1�Σ�֮��ֿ�����
        %G01X0Y349.514Z239.447F10   %�㲻�ӷ�б�ܱ�ʾ����һ���ַ�   +����һ������ *����0������
        %https://blog.csdn.net/zjxiaolu/article/details/45132037
        search_result = regexp(tline,expr,'match');
        if isempty(search_result)
            tline = fgetl(fid);
            continue;
        end
        
        for k = 1:length(search_result)
            one_result = search_result{k};
            point.(one_result(1)) = str2double(one_result(2:end)); %��һ����ĸΪhash����key�������Ϊֵ
        end
        
        if line_number >= start_line_number && line_number <=end_line_number
            point_struct_array = [point_struct_array point];
        end           
        tline = fgetl(fid);
    end
    close(h);
    fclose(fid);
    
    point_len = length(point_struct_array);
    %point_float_array = zeros(3,point_len);
    
    j = 1;
    for k = 2:point_len
        x_l = point_struct_array(k).X - point_struct_array(k-1).X;
        y_l = point_struct_array(k).Y - point_struct_array(k-1).Y;
        z_l = point_struct_array(k).Z - point_struct_array(k-1).Z;
        L = sqrt(x_l^2 + y_l^2 + z_l^2);
        if L == 0;
            continue
        end
        l_n = ceil(L/10);
        if x_l == 0
            x_array = point_struct_array(k-1).X * ones(1,l_n);
        else
            x_array = point_struct_array(k-1).X : x_l/l_n: point_struct_array(k).X;
            x_array = x_array(1: end -1);
        end
        if y_l == 0
            y_array = point_struct_array(k-1).Y * ones(1,l_n);
        else
            y_array = point_struct_array(k-1).Y : y_l/l_n: point_struct_array(k).Y;
            y_array = y_array(1: end -1);
        end
        if z_l == 0
            z_array = point_struct_array(k-1).Z * ones(1,l_n);
        else
            z_array = point_struct_array(k-1).Z : z_l/l_n: point_struct_array(k).Z;
            z_array = z_array(1:end -1);
        end
        point_float_array(:,j: j + l_n - 1) = [x_array;y_array;z_array];   
        j = j + l_n;
    end
    
    assert(~isempty(point_float_array), '��ѡ����ȷ�Ĵ�������');
      
    x_range = [min(point_float_array(1,:)),max(point_float_array(1,:))];
    y_range = [min(point_float_array(2,:)),max(point_float_array(2,:))];
    z_range = [min(point_float_array(3,:)),max(point_float_array(3,:))];
    
    show_movie_tag = findobj('tag','show_movie_flag');
    show_movie_flag = get(show_movie_tag,'Value');  
    
    if show_movie_flag == 0    
        plot3(point_float_array(1,:),point_float_array(2,:),point_float_array(3,:));
        axis([x_range y_range z_range])
        grid on
        view(view_x,view_y)
    else
        nframes = size(point_float_array,2);
        for k = 1:nframes 
            plot3(point_float_array(1,1:k),point_float_array(2,1:k),point_float_array(3,1:k));
            axis([x_range y_range z_range])
            grid on
            view(view_x,view_y)
            pause(0.1)
        end
    end
    
% --- Executes on button press in choose_nc_file.
function choose_nc_file_Callback(hObject, eventdata, handles)
% hObject    handle to choose_nc_file (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    global Full_name
    
    [FileName,PathName] = uigetfile('*.NC','Select the NC-file');
    Full_name = strcat(PathName,FileName);          

% --- Executes on button press in show_movie_flag.
function show_movie_flag_Callback(hObject, eventdata, handles)
% hObject    handle to show_movie_flag (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of show_movie_flag


% --- Executes on selection change in select_view_angle.
function select_view_angle_Callback(hObject, eventdata, handles)
% hObject    handle to select_view_angle (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns select_view_angle contents as cell array
%        contents{get(hObject,'Value')} returns selected item from select_view_angle
global view_x  view_y
select_view_angle_tag = findobj('tag','select_view_angle');
select_view_angle = get(select_view_angle_tag,'Value');  

switch  select_view_angle
    case 1
            view_x = 45;
            view_y = 10;
    case 2
            view_x = 0;
            view_y = 0;
    case 3
            view_x = 90;
            view_y = 0;
    otherwise 
            view_x = 0;
            view_y = 90;
    
end

% --- Executes during object creation, after setting all properties.
function select_view_angle_CreateFcn(hObject, eventdata, handles)
% hObject    handle to select_view_angle (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
