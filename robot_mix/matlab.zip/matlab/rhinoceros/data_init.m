
function data_init

file_name = 'data_input.txt';
fid=fopen(file_name,'a');
r = 5;
for i = 3:9
    for j = 1: 21
        u = (i - 1) * pi / 20 ;
        v = (j - 1) * pi / 10 ;
        x = r * sin(u) * cos(v);
        y = r * sin(u) * sin(v);
        z = r * cos(u);
        angle_a = u / pi * 180;
        angle_c = 90 - v / pi * 180;
        tline = sprintf('%.3f,%.3f,%.3f,%.3f,%.3f', x , y , z, angle_a , angle_c);
        if i == 3 && j == 1
            line_str = tline;
        else
            line_str = sprintf('%s\n%s', line_str, tline);
        end
        
    end
end
fprintf(fid,'%s',line_str);
fclose(fid);