function control_point = get_one_point(point , L, angle)
   
    theta = angle * pi/180;
    knife_vect_x = L * cos(theta);
    knife_vect_y = L * sin(theta);
    control_point(1) = point(1) -  knife_vect_x;
    control_point(2) = point(2) -  knife_vect_y;
    control_point(3) = angle; 