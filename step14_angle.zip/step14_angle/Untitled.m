
FIG=figure('NumberTitle','off','Position',[950,630,300,300],'Color','w');

% close all
% clc
% load CTRV.mat
% CTRV=ans;
% load BJV.MAT
% BJV=ans;
% load YGL.MAT
% YGL=ans;
% % t=BJV.Data;  %(:,1)
% t=BJV.Time(3:400);
% subplot(2,1,1)
% plot(t,BJV.Data(3:400))
% axis([0 40 0 0.6])
% % grid
% title('�ۼ�ĩ���ٶ�')
% ylabel('V (m/s)')
% subplot(2,1,2)
% % figure
% plot(t,CTRV.Data(3:400,1),'r')
% hold on
% plot(t,CTRV.Data(3:400,2),'m')
% plot(t,CTRV.Data(3:400,3),'c')
% plot(t,CTRV.Data(3:400,4),'r-.')
% plot(t,CTRV.Data(3:400,5),'g')
% plot(t,CTRV.Data(3:400,6),'b')
% plot(t,CTRV.Data(3:400,7)/180*pi,'k')
% % legend('1���͸�','2���͸�','3���͸�','4���͸�','5���͸�','6���͸�')%,'ת̨���ٶ�')
% xlabel('T (S)')
% ylabel('V (m/s)')
% axis([0 40 -0.02 0.015])
% title('�͸��ٶ�')

% figure
% subplot(2,1,1)
% plot(t,BJV.Data(437:700))
% axis([42 70 0 0.5])
% % grid
% title('�ۼ�ĩ���ٶ�')
% ylabel('V (m/s)')
% subplot(2,1,2)
% plot(t,YGL.Data(437:700,1),'r')
% hold on
% plot(t,YGL.Data(437:700,2),'m')
% plot(t,YGL.Data(437:700,3),'c')
% plot(t,YGL.Data(437:700,4),'r-.')
% plot(t,YGL.Data(437:700,5),'g')
% plot(t,YGL.Data(437:700,6),'b')
% 
% xlabel('T (S)')
% ylabel('F (N)')
% title('�͸���')
% % legend('1���͸�','2���͸�','3���͸�','4���͸�','5���͸�','6���͸�')
% axis([42 70 0 2200000])

% Max_x=50;
% Max_y=60;
% 
% line([0, Max_x], [0, 0], 'linewidth', 2, 'color', 'k');
% line([0, Max_x], [Max_y, Max_y], 'linewidth', 2, 'color', 'k');
% 
% line([0, 0], [0, Max_y], 'linewidth', 2, 'color', 'k');
% line([Max_x, Max_x], [0, Max_y], 'linewidth', 2, 'color', 'k');
% box on;
% box off;

% k0=3000;
% k1=2000;
% k2=10;
% v=0.67
% tao=k0+k1*v/(k2+v);
% 
% Vp=0.67;
% D=0.26;
% P0=100000;
% F0=pi/4*D^2*P0;
% Lmax=F0/(pi*D*3125.585754);
% M0=2450*3.1416*D^2*Lmax/4;
% deltaE=0.5*M0*Vp^2;
% sum=0;
% m=100;
% for n=1:m;
% A1=pi*D*(k0+k1*Vp*(m-n)/(m*k2+Vp*(m-n)))/m;
% Amax=A1*Lmax*m;
% A1n=A1*n/m;
% sum=sum+A1n;
% end
% A=sum;
% B=Amax-F0;
% C=-deltaE;
% pbs1=(-B+sqrt(B^2-4*A*C))/2/A;
% pbs2=(-B-sqrt(B^2-4*A*C))/2/A;

% clear;clc;
% V=1;H=-2;R=1;
% max(abs([2*V,2*H,R]))
% figure(2)

% FIG=figure('NumberTitle','off','Position',[100,200,480,320],'Color','w');
% % figure(2)
% 
% 
% for t = 0:pi/50:10*pi;
%         plot3(sin(t),cos(t),t,'b.','LineWidth',10);
%         hold on
% end
% xlabel('X');
% ylabel('Y');
% zlabel('Z');
% line([x1-0.5 x1-0.5],[100;101;105],[3;3;3], 'linewidth', 2, 'color', 'r')
% line([x1-0.5 x2+0.5],[y1-0.5 y4+0.5],[sety-0.5 sety-0.5]);
%  line([x1-0.5 x1-0.5],[y1-0.5 y4+0.5],[sety-0.5 sety-0.5]);
%  line([x1-0.5 x1-0.5],[y1-0.5 y4+0.5],[sety-0.5 sety+0.5]);
% axis([38 46 -15 15 0 20]);
% clear;clc;
% Q=[0*1 1*4 1*9 1*16 1*25 1*36];
% j=0;
% k=0;
% Z_Place=0;
% for i=1:6
%     if Q(i)~=0
%         j=j+1;
%         Q1(j)=Q(i);
%     else
%         k=k+1;
%         Z_Place(k)=i;
%     end
% end
% Q_Transfer=diag(sqrt(Q1));
% X1=[1 2 3 4 5 6];
% j=1;
% if Z_Place(1)==0
%     X=X1;
% else
%     for i=1:6
%         if j<=size(Z_Place,2)
%             if i==Z_Place(j)
%                 X(i)=0;
%                 j=j+1;
%             else X(i)=X1(i-j+1);
%             end
%         else X(i)=X1(i-j+1);
%         end
%     end
% end  
% X
        
% m=1;n=0;
% if Z_Place(1)==0
%     X1=X;
% else
%     for i=1:size(Z_Place,2)
%         for j=m:Z_Place(i)-1
%             X1(j)=X(m);            
%             m=m+1;
%         end
%         X1(Z_Place(i))=0;
%         m=m+1;
%     end
%     j=0;
%     for n=m:6
%         X1(n)=X(m-size(Z_Place,2)+j);
%         j=j+1;
%     end
% end
% X1

% theta0=0;w0=0.5/38.1293;r0=38.1293;dr=0;
% theta=theta0+w0;


% for i=1:6
%     if a(1,i)<-0.01
%         a(1,i)=-0.01;
%     else if a(1,i)>0.01
%             a(1,i)=0.01;
%         end
%     end
% end


% global  Slider1_Value Slider2_Value
% if Slider1_Value>20 && abs(Slider2_Value)<20
%     b=2
%     XSpeed=Slider1_Value;  %������
% elseif (Slider1_Value<-20) && (abs(Slider2_Value)<20)
%     b=3
%     XSpeed=Slider1_Value;  %������
% elseif Slider2_Value>20 && abs(Slider1_Value)<20
%     b=4
%     YSpeed=Slider2_Value;  %������
% elseif Slider2_Value<-20 && abs(Slider1_Value)<20
%     b=5
%     YSpeed=Slider2_Value;  %������
% else b=1
% end
% 
% Arm_AB_angle=69.058/180*pi;
% Arm_initial_angle = 49.404/180*pi;
% A1_A2 = 3580.11;
% A1_A3 = 1169.47;
% Sort0(Arm_AB_angle,Arm_initial_angle,A1_A2,A1_A3)
% % 
% function  Oil_Pump_AB_Length=Sort0(Arm_AB_angle,Arm_initial_angle,A1_A2,A1_A3)
% Angle_A213 = Arm_initial_angle+Arm_AB_angle;
% Oil_Pump_AB_Length=sqrt(A1_A2^2+A1_A3^2-2*A1_A2*A1_A3*cos(Angle_A213));
% end
% a=[0.2 0.02 0.03 0.04 -0.05];
% temp=max(abs(a));
% if temp>0.5
%     a=a/temp*0.1;
% end
% a

% function X=New_Min_Warp(Q26,Y21,Q)
% Q_Transfer=[sqrt(Q(1)) 0 0 0 0 0;0  sqrt(Q(2)) 0 0 0 0 ;0 0  sqrt(Q(3)) 0 0 0;0 0 0 sqrt(Q(4)) 0 0 ;0 0 0 0 sqrt(Q(5)) 0;0 0 0 0 0 sqrt(Q(6))];
% New_Q26=Q26/Q_Transfer;
% X=Q_Transfer\pinv(New_Q26)*Y21;

% 
% n=1;
% for i=0:0.01:pi/2
%     x(n)=cos(i);
%     y(n)=sin(i);
%     z(n)=x(n)/cos(i);
%     n=n+1;
% end
% plot(x,y)
% figure
% plot(z,y)
% dr=0;
% n=1;
% for i=0:0.01:pi/2
%     dx(n)=(1-cos(i))/cos(i);
%     XSpeed(n)=dx(n)-dr;
%     dr=dx(n);
%     n=n+1;
% end
% plot(XSpeed(1:150))
 
%  x=2; 
% dr=0;
% n=2 ;
% for i=0:0.01:pi/2
%     dx(n)=x/cos(i(n)-x/cos(i(n-1));
%     y(n)=y(n)+dx(n);
%     dr=dx(n);
%     n=n+1;
% end
% plot(XSpeed(1:150))


