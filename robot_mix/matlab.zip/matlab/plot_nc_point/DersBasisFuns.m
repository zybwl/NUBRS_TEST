
i = 4;
n = 7;
U = [0,0,0,1,2,3,4,4,5,5,5];
p = 2;
u = 2.5; 

% i = i + 1;
% left = zeros(p+1,1); 
% right = zeros(p+1,1); 
% ndu(1,1) = 1;
% for j = 1 : p
%     left(j+1) = u - U(i+1-j);
%     right(j+1) = U(i+j) - u;
%     saved = 0.0;
%     for r = 0:j-1
%         ndu(j+1,r+1) = right(r+2) + left(j-r+1);
%         temp = ndu(r + 1 ,j)/ndu(j + 1, r+1);
%         ndu(r+1,j+1) = saved + right(r+2)*temp;
%         saved = left(j - r + 1)*temp;
%     end
%     ndu(j+1,j+1) = saved;
% end

i = i + 1;
left = zeros(p+1,1); 
right = zeros(p+1,1); 
ndu(1,1) = 1;
for j = 1 : p
    left(j) = u - U(i+1-j);
    right(j) = U(i+j) - u;
    saved = 0.0;
    for r = 0:j-1
        ndu(j+1,r+1) = right(r+1) + left(j-r);
        temp = ndu(r + 1 ,j)/ndu(j + 1, r+1);
        ndu(r+1,j+1) = saved + right(r+1)*temp;
        saved = left(j - r)*temp;
    end
    ndu(j+1,j+1) = saved;
end
ndu
ders = ndu(:,p+1)';

p = p + 1;
n = 3;

for r = 1 : p
    s1 = 1; s2 = 2;
    a(1,1) = 1;
    for k = 2:n
        d = 0;
        rk = r - k + 1; pk = p - k + 1;
        if (r >= k)
            a(s2,1) = a(s1,1)/ndu(pk+1,rk);
            d = a(s2,1) * ndu(rk,pk);
        end

        if (rk >= 0)
            j1 = 2;
        else
            j1 = -rk+2;
        end
        if (r-1 <= pk)
            j2 = k-1;
        else
            j2 = p-r+1;
        end
        for j = j1:j2
            a(s2,j) = (a(s1,j) - a(s1,j-1))/ndu(pk+1,rk+j-1);
            d = d + a(s2,j)*ndu(rk+j-1,pk);
        end
        if (r <= pk)
            a(s2,k) = -a(s1,k-1)/ndu(pk+1,r);
            d = d + a(s2,k)*ndu(r,pk);
        end
        ders(k,r) = d;
        j = s1;
        s1 = s2;
        s2 = j;
    end
end

r = p - 1;
for k = 2:n
    ders(k,:) = ders(k,:) * r;
    r = r * (p - k);
end
ders

% i = i + 1;
% left = zeros(1,p);
% right = zeros(i,p);
% ndu(1,1) = 1;
% for j = 1:p
%     left(j) = u - U(i + 1 -j);
%     right(j) = U(i+j) - u;
%     save = 0.0;
%     for r = 0:j-1
%        ndu(j+1 ,r+1) = right(r+1) + left(j-r); 
%        temp = ndu(r+1 ,j)/ndu(j+1 ,r+1);
%        ndu(r+1 ,j+1) = save + right(r+1)*temp;
%        save = left(j-r)*temp;
%     end
%     ndu(j+1,j+1)=save;
% end
