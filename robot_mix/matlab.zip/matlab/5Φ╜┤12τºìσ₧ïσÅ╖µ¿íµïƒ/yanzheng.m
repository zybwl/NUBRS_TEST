
function output = yanzheng(input_str)

    point = struct('X', 0.0, 'Y', 0.0,'Z',0.0,'A',0.0,'B',0.0,'C',0.0);
    expr = '[XYZAC]-?[0-9]+\.?[0-9]*';
    search_result = regexp(input_str,expr,'match');
    if isempty(search_result)
        return;
    end

    for k = 1:length(search_result)
        one_result = search_result{k};
        point.(one_result(1)) = str2double(one_result(2:end)); %��һ����ĸΪhash����key�������Ϊֵ
    end

    angle_rate = pi / 180;
    A = point.A * angle_rate;
    C = (point.C + 90) * angle_rate;
    R1 = [1 0 0 0 ; 0 cos(A) -sin(A) 0 ; 0 sin(A) cos(A) 0 ;0 0 0 1];
    R2 = [cos(C) -sin(C) 0 0 ; sin(C) cos(C) 0 0 ; 0 0 1 0;0 0 0 1]; 

    center_pos = [0;0.01;0.06;1];
    T1 = [1 0 0 0.03;0 1 0 0.01;0 0 1 0;0 0 0 1];
    T2 = [1 0 0 point.X/1000;0 1 0 point.Y/1000;0 0 1 point.Z/1000;0 0 0 1];
    transfer_pos = 1000 * T2*R2*T1*R1*center_pos;
    output.x = roundn(transfer_pos(1),-3);
    output.y = roundn(transfer_pos(2),-3);
    output.z = roundn(transfer_pos(3),-3);
    output.a = point.A;
    output.c = point.C;