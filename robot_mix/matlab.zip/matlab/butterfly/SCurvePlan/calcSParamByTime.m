function sp = calcSParamByTime(Sparam,t)
% ���ݹ滮������S���߼��㵱ǰʱ�̵�S������j,a,v,s
tau = Sparam.t;
vknot = Sparam.vknot;
sknot = Sparam.sknot;
F = Sparam.Vmax;
vs = Sparam.vs;
ve = Sparam.ve;
Amax = Sparam.Amax;
Dec = Sparam.Dec;
Jamax = Sparam.Jamax;
Jdmax = Sparam.Jdmax;
% Jamax = 1;
% Jdmax = 1;
half_Jamax = 0.5*Jamax;
half_Jdmax = 0.5*Jdmax;
half_Amax = 0.5*Amax;
half_Dec = 0.5*Dec;
six_d_Jamax = (1/6)*Jamax;
six_d_Jdmax = (1/6)*Jdmax;

% S�滮ʱ�Ѿ������˸��ڵ�ֵ�����ڱ��ļ������У��õ���δ��������ֵ������ٽ�����֮���ֵ�Ļص���ǰ
% ��֤λ�Ƶļ�����ȷ
if Sparam.Vmax < vs && Sparam.Vmax >= ve
    vknot(1:2) = 2*Sparam.Vmax - vknot(1:2);
    vs = 2*F - vs;
elseif Sparam.Vmax<ve && Sparam.Vmax>=vs
    vknot(5:7)  =2*Sparam.Vmax - vknot(5:7);
    ve = 2*Sparam.Vmax - ve;
elseif Sparam.Vmax<ve && Sparam.Vmax<vs
    vknot(1:2) = 2*Sparam.Vmax - vknot(1:2);
    vknot(5:7)  =2*Sparam.Vmax - vknot(5:7);
    vs = 2*Sparam.Vmax - vs;
    ve = 2*Sparam.Vmax - ve;
end

if (0 <= t && t < tau(1) || tau(1) == tau(end))
    j = Jamax;
    if Sparam.Vmax<vs 
        a = -Jamax*t;
        v = vs - half_Jamax*t^2;
    else
        a = Jamax*t;
        v = vs + half_Jamax*t^2;
    end
    s = vs*t + six_d_Jamax*t^3;
elseif (tau(1) <= t && t < tau(2))
    tt = t-tau(1);
    j = 0;
    if Sparam.Vmax<vs 
        a = -Amax;
        v = vknot(1) - Amax*tt;
    else
        a = Amax;
        v = vknot(1) + Amax*tt;
    end
    s = sknot(1) + vknot(1)*tt + half_Amax*tt^2;
elseif (tau(2) <= t && t < tau(3) || tau(3) == tau(end))
    tt = t-tau(2);
    j = -Jamax;
    if Sparam.Vmax<vs 
        a = -Amax + Jamax*tt;
        v = vknot(2) - Amax*tt + half_Jamax*tt^2;
    else
        a = Amax - Jamax*tt;
        v = vknot(2) + Amax*tt - half_Jamax*tt^2;
    end
    s = sknot(2) + vknot(2)*tt + half_Amax*tt^2 - six_d_Jamax*tt^3;
elseif (tau(3) <= t && t < tau(4) || tau(4) == tau(end))
    tt = t-tau(3);
    j = 0;
    a = 0;
    v = vknot(3);
    s = sknot(3) + vknot(3)*tt;
elseif (tau(4) <= t && t < tau(5))
    tt = t-tau(4);
    j = Jdmax;
    if Sparam.Vmax<ve 
        a = Jdmax*tt;
        v = vknot(4) + half_Jdmax*tt^2;
    else
        a = -Jdmax*tt;
        v = vknot(4) - half_Jdmax*tt^2;
    end
    s = sknot(4) + vknot(4)*tt - six_d_Jdmax*tt^3;
elseif (tau(5) <= t && t < tau(6))
    tt = t-tau(5);
    j = 0;
    if Sparam.Vmax<ve 
        a = Dec;
        v = vknot(5) + Dec*tt;
    else
        a = -Dec;
        v = vknot(5) - Dec*tt;
    end
    s = sknot(5) + vknot(5)*tt - half_Dec*tt^2;
elseif (tau(6) <= t && t <= tau(7))
    tt = t-tau(6);
    j = -Jdmax;
    if Sparam.Vmax<ve 
        a = Dec - Jdmax*tt;
        v = vknot(6) + Dec*tt - half_Jdmax*tt^2;
    else
        a = -Dec + Jdmax*tt;
        v = vknot(6) - Dec*tt + half_Jdmax*tt^2;
    end
    s = sknot(6) + vknot(6)*tt - half_Dec*tt^2 + six_d_Jdmax*tt^3;
end

sp = [j a v s]';

