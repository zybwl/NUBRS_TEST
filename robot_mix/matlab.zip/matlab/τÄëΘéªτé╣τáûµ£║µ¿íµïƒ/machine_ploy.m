
clc;clear all;close all;

center1 = [100,100,0];
center2 = [125, 100, 3.5];
center3 = [127, 103 , 4.5];
r = 5;
% ����һ��Բ������
for i = 3:9
    for j = 1: 21
        u = (i - 1) * pi / 20 ;
        v = (j - 1) * pi / 10 ;
        x = r * sin(u) * cos(v);
        y = r * sin(u) * sin(v);
        z = r * cos(u);
        angle_a = u / pi * 180;
        angle_c = 90 - v / pi * 180;
        ball_point = [x,y,z];        
        ra = get_rotation_matrix(1 , angle_a);
        ta = get_translation_matrix(center1);
        rc = get_rotation_matrix(3 , angle_c);
        tc = get_translation_matrix(center2 - center1);
        knife_point = ta * ra * tc * rc * [ball_point + center3 - center2 , 1]';      
        draw_machine_figure(angle_a, angle_c);
        draw_knife(knife_point , 10, 1);
        pause(0.2);
        hold off
    end
end



