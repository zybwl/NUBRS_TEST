%main����
%ģ�⵶�ĸ���ü�
clc;clear all;
[FileName,PathName] = uigetfile('*.NC','Select the file');
file_name = strcat(PathName,FileName);
start_line_no = 5;
end_line_no = 100000;
   
point_struct_array = get_nc_data(file_name,start_line_no,end_line_no);
n = size(point_struct_array,2);

for i = 1:n  
    x(i) = point_struct_array(i).X;
    y(i) = point_struct_array(i).Y;
    z(i) = point_struct_array(i).Z;
    k(i) = point_struct_array(i).A;
end
plot(x,y,'-r');
hold on;
% figure(1);

knife_point = zeros(n,2);
knife_e = 5;
n = length(x);
for i = 1: n-1
    p1 = [x(i),y(i),z(i)];
    p2 = [x(i+1),y(i+1),z(i+1)];
%     L = norm(p2 - p1);
%     m = floor(L/30) + 1;
%     
% %     p_end = zeros(m + 1,2);
%     for j = 0:m
%         p = ((m - j)*p1 + j*p2 )/m;
%         p_start = [p(1),p(2)];
%         t = p(3)*pi/180;
% %         p_end(j+1,:) = p_start + knife_e * [cos(t) sin(t)];
%         p_end = p_start + knife_e * [cos(t) sin(t)];
%         plot([p_start(1) p_end(1)], [p_start(2) p_end(2)],'-b');
%         hold on;
% %         pause(0.1);
%     end
% %     plot(p_end(:,1),p_end(:,2),'-r');
% %     hold on;
%     pause(0.05);


    p_start = [x(i),y(i)];
    t = z(i)*pi/180;
    p_end = p_start + knife_e * [cos(t) sin(t)];
    knife_point(i,1) = p_end(1);
    knife_point(i,2) = p_end(2);
end    
plot(knife_point(:,1),knife_point(:,2),'-b');




