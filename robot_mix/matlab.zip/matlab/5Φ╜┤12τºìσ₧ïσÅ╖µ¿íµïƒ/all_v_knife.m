clc;clear all;
points1 = ...
[134.622   33.508
135.298   63.248
133.344   93.006
127.853   122.211
117.765   150.202
103.729   176.433
101.775   179.923]; 

points2 = ...
[101.775   179.923
77.005    208.831
42.778    233.156
3.745     248.794
1.230     254.005];

% points2 = ...
% [101.775   179.923
% 77.005    208.831
% 42.778    233.156
% 3.745     248.794];

vect_orgin = points2(2,:) - points1(end-1,:);
vect_chuizhi = [vect_orgin(2),-vect_orgin(1)];
unit_vect = 4 * vect_chuizhi/ norm(vect_chuizhi);
v_point = points1(end,:) +  unit_vect ;
points = [points1;v_point;points2];
knife_e = 8;
n = size(points,1);
% new_points = [];

% is_v_flag =0;
% for i = 1:n
%     if i == 1
%         temp_points = get_control_points(knife_e,points(1,:),points(1,:), points(i+1,:),0);
%     elseif i == n
%         temp_points = get_control_points(knife_e,points(i-1,:),points(i,:), points(i,:),0);
%     else
%         if i == 9
%             temp_points = get_control_points(knife_e,points(i-1,:),points(i,:), points(i+1,:),1);
%         else
%             temp_points = get_control_points(knife_e,points(i-1,:),points(i,:), points(i+1,:),0);
%         end
%     end
%     new_points = [new_points;temp_points];
% end

new_points = get_control_points1(knife_e, points);

% plot(points(:,1),points(:,2),'-s')
% hold on
% plot(new_points(:,1),new_points(:,2),'-*')
n = size(new_points,1);
% for i = 1:n
%      text(new_points(i,1), new_points(i,2) ,num2str(i));
% end

for i = 1: n-1
    p1 = new_points(i,:);
    p2 = new_points(i+1,:);
    L = norm(p2 - p1);
    m = floor(L/2) + 1;
%     m =1;
    for j = 0:m
        p = ((m - j)*p1 + j*p2 )/m;
        p_start = [p(1),p(2)];
        t = p(3)*pi/180;
        p_end = p_start + knife_e * [cos(t) sin(t)];
        plot(points(:,1),points(:,2),'-s')
        hold on
        plot(new_points(:,1),new_points(:,2),'-*')
%         for index = 1:n
%              text(new_points(index,1), new_points(index,2) ,num2str(index));
%         end
        plot([p_start(1),p_end(1)],[p_start(2),p_end(2)],'-*');
        text(p_start(1), p_start(2) ,'start')
        text(p_end(1), p_end(2) ,'end')
        hold off
        pause(0.1);
    end
    pause(0.3);
end    




