function  y = forward_substitution(matrix_l, b)

    q = length(b);
    y = zeros(1,q);
    y(1) = b(1)/ matrix_l(1,1); 
    for i = 2:q
        s = 0;
        for j = 1:i       
            s =  s + matrix_l(i,j) * y(j) ;               
        end
        y(i) = b(i) - s;
        y(i) = y(i)/matrix_l(i,i);
    end