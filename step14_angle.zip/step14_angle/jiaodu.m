function [sys,x0,str,ts] = jiaodu(t,x,u,flag)
switch flag,
    case 0,
        [sys,x0,str,ts]=mdlInitializeSizes;
    case 2,
        sys=mdlUpdate(t,x,u);
    case 3,
        sys=mdlOutputs(t,x,u);
    case {1,4,9},
        sys=[];
    otherwise
        error(['Unhandled flag = ',num2str(flag)]);
end

function [sys,x0,str,ts]=mdlInitializeSizes
global a Left_Flag Right_Flag Up_Flag Down_Flag RoundUp_Flag RoundDown_Flag Automatic_Flag AutomaticBuild_Flag dl...
    dl1 step1_flag step2_flag step3_flag step4_flag step5_flag step2 step3 step4 step5 n work_state XSpeedTemp direction directionTemp nn...
    radio1 radio2 radio3 radio4 radio5 radio6 radio7 radio8 ANGLE1 ANGLE2 ANGLE3 ANGLE4 ANGLE5 ANGLE6 JJ JPre
radio1=0;radio2=0;radio3=0;radio4=0;radio5=0;radio6=0;radio7=0;radio8=0;
a=zeros(1,7);JJ=zeros(1,4); JPre=zeros(1,4);
Left_Flag=0;Right_Flag=0;Up_Flag=0;Down_Flag=0;RoundUp_Flag=0;RoundDown_Flag=0;Automatic_Flag=0;AutomaticBuild_Flag=0;step1_flag=0;step2_flag=0;step3_flag=0;step4_flag=0;step5_flag=0;
dl=0.04;dl1=0.05;step2=0; step3=0; step4=0; step5=0;n=0;work_state=1;XSpeedTemp=0;direction=1;directionTemp=1;nn=0;
ANGLE1=zeros(10,1); ANGLE2=zeros(10,1); ANGLE3=zeros(10,1); ANGLE4=zeros(10,1); ANGLE5=zeros(10,1); ANGLE6=zeros(10,1);
sizes = simsizes;
sizes.NumContStates  = 0;
sizes.NumDiscStates  = 18;
sizes.NumOutputs     = 18;
sizes.NumInputs      = 23;
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 1;   % at least one sample time is needed
sys = simsizes(sizes);
x0  = zeros(1,18);
str = [];
ts  = [0.1 0];

function sys=mdlUpdate(t,x,u)
global a Left_Flag Right_Flag Up_Flag Down_Flag RoundUp_Flag RoundDown_Flag Automatic_Flag AutomaticBuild_Flag XPendTop6 YPendTop6...
    r r1 r2 Angle dl dl1 R dr1 dr2 dr3 dr4 area V V1 H H1 A1 A2 A3 A4 sety MaxD x1 y1 x2 y2 x3 y3 x4 y4 y5 y6 step1_flag AngleInit XPendTop6_1 YPendTop6_1...
    NextRx NextRy  step2_flag step3_flag step4_flag step5_flag TotalD step2 step3 step4 step5 n work_state XSpeedTemp direction directionTemp nn...
    radio1 radio2 radio3 radio4 radio5 radio6 radio7 radio8 rx ry  ANGLE1 ANGLE2 ANGLE3 ANGLE4 ANGLE5 ANGLE6 JJ JPre
ArmParaInit;
L1=11.5623;L2=9.34547;L3=9.33026;L4=10.6517;L5=10.6135;L6=4.57025;   %�ۼܳ���(m)

% angle1=(69.058-u(1))*pi/180;   %�ۼܶ���֮��н�(����)�������������
% angle2=(175.9865-u(2))*pi/180;
% angle3=(149.6604-u(3))*pi/180;
% angle4=(141.1757+u(4))*pi/180;
% angle5=(160.1881+u(5))*pi/180;
% angle6=(149.2637+u(6))*pi/180;

for i=1:9
    ANGLE1(i+1)=ANGLE1(i);
    ANGLE2(i+1)=ANGLE2(i);
    ANGLE3(i+1)=ANGLE3(i);
    ANGLE4(i+1)=ANGLE4(i);
    ANGLE5(i+1)=ANGLE5(i);
    ANGLE6(i+1)=ANGLE6(i);
end
ANGLE1(1)=(69.058-u(1))*pi/180;   %�ۼܶ���֮��н�(����)�������������
ANGLE2(1)=(175.9865-u(2))*pi/180;
ANGLE3(1)=(149.6604-u(3))*pi/180;
ANGLE4(1)=(141.1757+u(4))*pi/180;
ANGLE5(1)=(160.1881+u(5))*pi/180;
ANGLE6(1)=(149.2637+u(6))*pi/180;

angle1=sum(ANGLE1)/10;
angle2=sum(ANGLE2)/10;
angle3=sum(ANGLE3)/10;
angle4=sum(ANGLE4)/10;
angle5=sum(ANGLE5)/10;
angle6=sum(ANGLE6)/10;

angle11=(65.9703-u(1))*pi/180;  %�ۼܽµ�֮��нǣ�������ۼ�ĩ��׼ȷ����
angle22=(181.9308-u(2))*pi/180;
angle33=(145.9397-u(3))*pi/180;
angle44=(144.2819+u(4))*pi/180;
angle55=(158.9742+u(5))*pi/180;
angle66=(151.9432+u(6))*pi/180;

xx(1)=angle11;         x12=L1*cos(xx(1));    y12=L1*sin(xx(1));
xx(2)=xx(1)+angle22-pi;x23=x12+L2*cos(xx(2));y23=y12+L2*sin(xx(2));
xx(3)=xx(2)+angle33-pi;x34=x23+L3*cos(xx(3));y34=y23+L3*sin(xx(3));
xx(4)=xx(3)+angle44-pi;x45=x34+L4*cos(xx(4));y45=y34+L4*sin(xx(4));
xx(5)=xx(4)+angle55-pi;x56=x45+L5*cos(xx(5));y56=y45+L5*sin(xx(5));
xx(6)=xx(5)+angle66-pi;x66=x56+L6*cos(xx(6));y66=y56+L6*sin(xx(6));
L_Distance=56-1;

xx66=x56+(L6+2)*cos(xx(6));yy66=y56+(L6+2)*sin(xx(6));  %������
JJ(1)=(xx66-x12)*yy66-(yy66-y12)*xx66;
JJ(2)=(xx66-x23)*(yy66-y12)-(yy66-y23)*(xx66-x12);
JJ(3)=(xx66-x34)*(yy66-y23)-(yy66-y34)*(xx66-x23);
JJ(4)=(xx66-x45)*(yy66-y34)-(yy66-y45)*(xx66-x34);

if JJ(1)>0 && JJ(2)>0 && JJ(3)>0 && JJ(4)>0
    Disturb_BooL=0;
elseif JJ(1)<0 &&  JJ(1)-JPre(1)>0.0001
    Disturb_BooL=0;
elseif JJ(2)<0 &&  JJ(2)-JPre(2)>0.0001
    Disturb_BooL=0;
elseif JJ(3)<0 &&  JJ(3)-JPre(3)>0.0001
    Disturb_BooL=0;
elseif JJ(4)<0 &&  JJ(4)-JPre(4)>0.0001
    Disturb_BooL=0;
else
    Disturb_BooL=1;
end

JPre(1)=JJ(1);
JPre(2)=JJ(2);
JPre(3)=JJ(3);
JPre(4)=JJ(4);

x(8)=x66;
x(9)=y66;
x(10)=x(8)*cos(u(7)/180*pi);
x(11)=x(8)*sin(u(7)/180*pi);

% if u(8)>30 && u(9)<30 && u(10)<30 && u(11)<30  && u(12)<30  && u(13)<30  && u(14)<30
%     b=2; %������
% elseif u(8)<30 && u(9)>30 && u(10)<30 && u(11)<30 && u(12)<30  && u(13)<30  && u(14)<30
%     b=3; %������
% elseif u(8)<30 && u(9)<30 && u(10)>30 && u(11)<30 && u(12)<30  && u(13)<30  && u(14)<30
%     b=4; %������
% elseif u(8)<30 && u(9)<30 && u(10)<30 && u(11)>30 && u(12)<30  && u(13)<30  && u(14)<30
%     b=5;  %������
% elseif u(8)<30 && u(9)<30 && u(10)<30 && u(11)<30 && u(12)>30  && u(13)<30  && u(14)<30
%     b=6;  %��ת����
% elseif u(8)<30 && u(9)<30 && u(10)<30 && u(11)<30 && u(12)<30  && u(13)>30  && u(14)<30
%     b=7;  %�Զ������ξ���Բ��
% elseif u(8)<30 && u(9)<30 && u(10)<30 && u(11)<30 && u(12)<30  && u(13)<30  && u(14)>30
%     b=8;  %�Զ����β���
% else b=1;
% end

if radio1==1
    b=2; %������
elseif radio2==1
    b=3; %������
elseif radio3==1
    b=4; %������
elseif radio4==1
    b=5;  %������
elseif radio5==1
    b=6;  %��ת����
elseif radio6==1
    b=7;  %�Զ������ξ���Բ��
elseif radio7==1
    b=8;  %�Զ����β���
elseif radio8==1
    b=9;  %�Զ����β���
else b=1;
end

% % if (((angle1>1.527) &&(a(1)>=0)) || ((angle1<0.025) &&( a(1)<=0))) && work_state==b && direction==directionTemp
% %     P(1)=0;Q(1)=0;
% % elseif angle1>83/180*pi && a(1)>=0
% %     P(1)=1;Q(1)=5.178+3.4*(angle1/pi*180-83);
% % elseif angle1<5/180*pi && a(1)<=0
% %     P(1)=1;Q(1)=6.576+3.4*(5-angle1/pi*180);
% % elseif a(1)>=0
% %     P(1)=1;Q(1)=5.178;
% % else
% %     P(1)=1;Q(1)=6.576;
% % end
% % % ccc=[direction directionTemp]
% %
% % if (((angle2>pi) &&(a(2)>=0)) || ((angle2<0.025) &&(a(2)<=0))) && work_state==b && direction==directionTemp
% %     P(2)=0;Q(2)=0;
% % elseif angle2>175/180*pi && a(2)>=0
% %     P(2)=1;Q(2)=5.178+3.4*(angle2/pi*180-175);
% % elseif angle2<5/180*pi && a(2)<=0
% %     P(2)=1;Q(2)=6.576+3.4*(5-angle2/pi*180);
% % elseif a(2)>=0
% %     P(2)=1;Q(2)=5.178;
% % else
% %     P(2)=1;Q(2)=6.576;
% % end
% %
% % if (((angle3>3.054) &&(a(3)>=0) ) || ((angle3<0.025) &&(a(3)<=0))) && work_state==b && direction==directionTemp
% %     P(3)=0;Q(3)=0;
% % elseif angle3>170/180*pi && a(3)>=0
% %     P(3)=1;Q(3)=2.642+3.4*(angle3/pi*180-170);
% % elseif angle3<5/180*pi && a(3)<=0
% %     P(3)=1;Q(3)=4.101+3.4*(5-angle3/pi*180);
% % elseif a(3)>=0
% %     P(3)=1;Q(3)=2.642;
% % else
% %     P(3)=1;Q(3)=4.101;
% % end
% %
% % if (((angle4>3.054) &&(a(4)>=0) ) || ((angle4<0.025) &&(a(4)<=0))) && work_state==b && direction==directionTemp
% %     P(4)=0;Q(4)=0;
% % elseif angle4>170/180*pi && a(4)>=0
% %     P(4)=1;Q(4)=4.627+3.4*(angle4/pi*180-170);
% % elseif angle4<5/180*pi && a(4)<=0
% %     P(4)=1;Q(4)=9.155+3.4*(5-angle4/pi*180);
% % elseif a(4)>=0
% %     P(4)=1;Q(4)=4.627;
% % else
% %     P(4)=1;Q(4)=9.155;
% % end
% %
% % if (((angle5>3.054) &&(a(5)>=0)) || ((angle5<0.025) &&(a(5)<=0))) && work_state==b && direction==directionTemp
% %     P(5)=0;Q(5)=0;
% % elseif angle5>170/180*pi && a(5)>=0
% %     P(5)=1;Q(5)=1.94+3.4*(angle5/pi*180-170);
% % elseif angle5<5/180*pi && a(5)<=0
% %     P(5)=1;Q(5)=3.186+3.4*(5-angle5/pi*180);
% % elseif a(5)>=0
% %     P(5)=1;Q(5)=1.94;
% % else
% %     P(5)=1;Q(5)=3.186;
% % end
% %
% % if (((angle6>3.054) &&(a(6)>=0)) || ((angle6<0.025) &&(a(6)<=0))) && work_state==b && direction==directionTemp
% %     P(6)=0;Q(6)=0;
% % elseif angle6>170/180*pi && a(6)>=0
% %     P(6)=1;Q(6)=1+3.4*(angle6/pi*180-170);
% % elseif angle6<5/180*pi && a(6)<=0
% %     P(6)=1;Q(6)=1+3.4*(5-angle6/pi*180);
% % elseif a(6)>=0
% %     P(6)=1;Q(6)=1;
% % else
% %     P(6)=1;Q(6)=1;
% % end
% if (((angle1>1.57) &&(a(1)>=0)) || ((angle1<0.025) &&( a(1)<=0))) && work_state==b && direction==directionTemp
%     P(1)=0;Q(1)=0;
% elseif angle1>83/180*pi %&& a(1)>=0
%     P(1)=1;Q(1)=5+3.4*(angle1/pi*180-83);
%     %     elseif angle1>83/180*pi && a(1)<=0
%     %     P(1)=1;Q(1)=6.576+3.4*(angle1/pi*180-83);
% elseif angle1<5/180*pi %&& a(1)<=0
%     P(1)=1;Q(1)=5+3.4*(5-angle1/pi*180);
%     %     elseif angle1<5/180*pi && a(1)>=0
%     %     P(1)=1;Q(1)=5.178+3.4*(5-angle1/pi*180);
%     % elseif a(1)>=0
%     %     P(1)=1;Q(1)=5.178;
% else
%     P(1)=1;Q(1)=5;
% end
% % ccc=[direction directionTemp]
%
% if (((angle2>pi) &&(a(2)>=0)) || ((angle2<0.025) &&(a(2)<=0))) && work_state==b && direction==directionTemp
%     P(2)=0;Q(2)=0;
% elseif angle2>174/180*pi% && a(2)>=0
%     P(2)=1;Q(2)=5+3.4*(angle2/pi*180-174);
%     %     elseif angle2>175/180*pi && a(2)<=0
%     %     P(2)=1;Q(2)=6.576+3.4*(angle2/pi*180-175);
% elseif angle2<5/180*pi% && a(2)<=0
%     P(2)=1;Q(2)=5+3.4*(5-angle2/pi*180);
%     %     elseif angle2<5/180*pi && a(2)>=0
%     %     P(2)=1;Q(2)=5.178+3.4*(5-angle2/pi*180);
%     % elseif a(2)>=0
%     %     P(2)=1;Q(2)=5.178;
% else
%     P(2)=1;Q(2)=5;
% end
%
% if (((angle3>3.07) &&(a(3)>=0) ) || ((angle3<0.025) &&(a(3)<=0))) && work_state==b && direction==directionTemp
%     P(3)=0;Q(3)=0;
% elseif angle3>168/180*pi% && a(3)>=0
%     P(3)=1;Q(3)=3+3.4*(angle3/pi*180-168);
% elseif angle3<5/180*pi %&& a(3)<=0
%     P(3)=1;Q(3)=3+3.4*(5-angle3/pi*180);
%     % elseif a(3)>=0
%     %     P(3)=1;Q(3)=2.642;
% else
%     P(3)=1;Q(3)=3;
% end
%
% if (((angle4>3.07) &&(a(4)>=0) ) || ((angle4<0.025) &&(a(4)<=0))) && work_state==b && direction==directionTemp
%     P(4)=0;Q(4)=0;
% elseif angle4>168/180*pi %&& a(4)>=0
%     P(4)=1;Q(4)=5+3.4*(angle4/pi*180-168);
% elseif angle4<5/180*pi %&& a(4)<=0
%     P(4)=1;Q(4)=5+3.4*(5-angle4/pi*180);
%     % elseif a(4)>=0
%     %     P(4)=1;Q(4)=4.627;
% else
%     P(4)=1;Q(4)=5;
% end
%
% if (((angle5>3.07) &&(a(5)>=0)) || ((angle5<0.025) &&(a(5)<=0))) && work_state==b && direction==directionTemp
%     P(5)=0;Q(5)=0;
% elseif angle5>168/180*pi% && a(5)>=0
%     P(5)=1;Q(5)=2.5+3.4*(angle5/pi*180-168);
% elseif angle5<5/180*pi% && a(5)<=0
%     P(5)=1;Q(5)=2.5+3.4*(5-angle5/pi*180);
%     % elseif a(5)>=0
%     %     P(5)=1;Q(5)=1.94;
% else
%     P(5)=1;Q(5)=2.5;
% end
%
% if (((angle6>3.07) &&(a(6)>=0)) || ((angle6<0.025) &&(a(6)<=0))) && work_state==b && direction==directionTemp
%     P(6)=0;Q(6)=0;
% elseif angle6>168/180*pi && a(6)>=0
%     P(6)=1;Q(6)=2.5+3.4*(angle6/pi*180-168);
% elseif angle6<5/180*pi && a(6)<=0
%     P(6)=1;Q(6)=2.5+3.4*(5-angle6/pi*180);
%     % elseif a(6)>=0
%     %     P(6)=1;Q(6)=1.94;
% else
%     P(6)=1;Q(6)=2.5;
% end

if work_state==b && Disturb_BooL==1
    P=zeros(1,6);
    Q=zeros(1,6);
else
%     HeightLimit=24.5;
    HeightLimit=u(15);
    LimitBand=2;
    if (((angle1>1.57) &&(a(1)>=0)) || ((angle1<0.025) &&( a(1)<=0))|| ((y12>HeightLimit) &&( a(1)>=0))) && work_state==b && direction==directionTemp
        P(1)=0;Q(1)=0;
    elseif angle1>83/180*pi && a(1)>=0
        P(1)=1;Q(1)=5+3.4*(angle1/pi*180-83);
        %     elseif angle1>83/180*pi && a(1)<=0
        %     P(1)=1;Q(1)=6.576+3.4*(angle1/pi*180-83);
    elseif angle1<5/180*pi %&& a(1)<=0
        P(1)=1;Q(1)=5+3.4*(5-angle1/pi*180);
        %     elseif angle1<5/180*pi && a(1)>=0
        %     P(1)=1;Q(1)=5.178+3.4*(5-angle1/pi*180);
        % elseif a(1)>=0
        %     P(1)=1;Q(1)=5.178;
    else
        P(1)=1;Q(1)=5;
        if y12>HeightLimit-LimitBand
            Q(1)=Q(1)*(2-0.5*(HeightLimit-y12));
        end
    end
    % ccc=[direction directionTemp]
    
    if (((angle2>pi) &&(a(2)>=0)) || ((angle2<0.025) &&(a(2)<=0))|| ((y23>HeightLimit) &&( a(2)>=0))) && work_state==b && direction==directionTemp
        P(2)=0;Q(2)=0;
    elseif angle2>174/180*pi && a(2)>=0
        P(2)=1;Q(2)=5+3.4*(angle2/pi*180-174);
        %     elseif angle2>175/180*pi && a(2)<=0
        %     P(2)=1;Q(2)=6.576+3.4*(angle2/pi*180-175);
    elseif angle2<5/180*pi% && a(2)<=0
        P(2)=1;Q(2)=5+3.4*(5-angle2/pi*180);
        %     elseif angle2<5/180*pi && a(2)>=0
        %     P(2)=1;Q(2)=5.178+3.4*(5-angle2/pi*180);
        % elseif a(2)>=0
        %     P(2)=1;Q(2)=5.178;
    else
        P(2)=1;Q(2)=5;
        if y23>HeightLimit-LimitBand
            Q(2)=Q(2)*(2-0.5*(HeightLimit-y23));
        end
    end
    
    if (((angle3>3.07) &&(a(3)>=0) ) || ((angle3<0.025) &&(a(3)<=0))|| ((y34>HeightLimit) &&( a(3)>=0))) && work_state==b && direction==directionTemp
        P(3)=0;Q(3)=0;
    elseif angle3>168/180*pi && a(3)>=0
        P(3)=1;Q(3)=3+3.4*(angle3/pi*180-168);
    elseif angle3<5/180*pi %&& a(3)<=0
        P(3)=1;Q(3)=3+3.4*(5-angle3/pi*180);
        % elseif a(3)>=0
        %     P(3)=1;Q(3)=2.642;
    else
        P(3)=1;Q(3)=3;
        if y34>HeightLimit-LimitBand
            Q(3)=Q(3)*(2-0.5*(HeightLimit-y34));
        end
    end
    
    if (((angle4>3.07) &&(a(4)>=0) ) || ((angle4<0.025) &&(a(4)<=0))|| ((y45>HeightLimit) &&( a(4)>=0))) && work_state==b && direction==directionTemp
        P(4)=0;Q(4)=0;
    elseif angle4>168/180*pi && a(4)>=0
        P(4)=1;Q(4)=5+3.4*(angle4/pi*180-168);
    elseif angle4<5/180*pi %&& a(4)<=0
        P(4)=1;Q(4)=5+3.4*(5-angle4/pi*180);
        % elseif a(4)>=0
        %     P(4)=1;Q(4)=4.627;
    else
        P(4)=1;Q(4)=5;
        if y45>HeightLimit-LimitBand
            Q(4)=Q(4)*(2-0.5*(HeightLimit-y45));
        end
    end
    
    if (((angle5>3.07) &&(a(5)>=0)) || ((angle5<0.1) &&(a(5)<=0))|| ((y56>HeightLimit) &&( a(5)>=0))) && work_state==b && direction==directionTemp
        P(5)=0;Q(5)=0;
    elseif angle5>168/180*pi && a(5)>=0
        P(5)=1;Q(5)=2.5+3.4*(angle5/pi*180-168);
    elseif angle5<10/180*pi% && a(5)<=0
        P(5)=1;Q(5)=2.5+3.4*(10-angle5/pi*180);
        % elseif a(5)>=0
        %     P(5)=1;Q(5)=1.94;
    else
        P(5)=1;Q(5)=2.5;
        if y56>HeightLimit-LimitBand
            Q(5)=Q(5)*(2-0.5*(HeightLimit-y56));
        end
    end
    
    if (((angle6>3.07) &&(a(6)>=0)) || ((angle6<0.087) &&(a(6)<=0))|| ((y66>HeightLimit) &&( a(6)>=0))) && work_state==b && direction==directionTemp
        P(6)=0;Q(6)=0;
    elseif angle6>168/180*pi && a(6)>=0
        P(6)=1;Q(6)=2.5+3.4*(angle6/pi*180-168);
    elseif angle6<10/180*pi && a(6)<=0
        P(6)=1;Q(6)=2.5+3.4*(10-angle6/pi*180);
        % elseif a(6)>=0
        %     P(6)=1;Q(6)=1.94;
    else
        P(6)=1;Q(6)=2.5;
        if y66>HeightLimit-LimitBand
            Q(6)=Q(6)*(2-0.5*(HeightLimit-y66));
        end
    end
    
    if xx(6)<-pi           %6���Ϲ�����1��2��
        P(1)=0;Q(1)=0;
        P(2)=0;Q(2)=0;
    end
    
    if y23>HeightLimit && work_state==b && direction==directionTemp
        if a(1)>=0
            P(1)=0;Q(1)=0;
        end
    end
    if y34>HeightLimit && work_state==b && direction==directionTemp
        if a(1)>=0
            P(1)=0;Q(1)=0;
        end
        if a(2)>=0
            P(2)=0;Q(2)=0;
        end
    end
    if y45>HeightLimit && work_state==b && direction==directionTemp
        if a(1)>=0
            P(1)=0;Q(1)=0;
        end
        if a(2)>=0
            P(2)=0;Q(2)=0;
        end
        if a(3)>=0
            P(3)=0;Q(3)=0;
        end
    end
    if y56>HeightLimit && work_state==b && direction==directionTemp
        if a(1)>=0
            P(1)=0;Q(1)=0;
        end
        if a(2)>=0
            P(2)=0;Q(2)=0;
        end
        if a(3)>=0
            P(3)=0;Q(3)=0;
        end
        if a(4)<=0
            P(4)=0;Q(4)=0;
        end
    end
    if y66>HeightLimit && work_state==b && direction==directionTemp && b~=5
        P=zeros(1,6);Q=zeros(1,6);
    end
end

work_state=b;

% b=9;
switch b,
    case 1,
        XSpeed=0;YSpeed =0;
        
    case 2,
        if Right_Flag==0  %��
            Left_Flag=0;Right_Flag=1;Up_Flag=0;Down_Flag=0;RoundUp_Flag=0;RoundDown_Flag=0;Automatic_Flag=0;AutomaticBuild_Flag=0;
            YPendTop6=y66;     %����ʼ�߶����ˮƽ���ߵĸ߶�
            a(7)=0;
            dr1=0;
        end
        if x66<sqrt(L_Distance^2-YPendTop6^2)
            if dr1<0.5
                dr1=dr1+0.025;
            else dr1=0.5;
            end
            %             XSpeed=0.5;
            XSpeed=dr1;
            YSpeed =YPendTop6-y66;
            if YSpeed>0.1
                YSpeed=0.1;
            elseif YSpeed<-0.1
                YSpeed=-0.1;
            end
        else
            XSpeed=0;YSpeed =0;
        end
        
    case 3,
        if Left_Flag==0   %��
            Left_Flag=1;Right_Flag=0;Up_Flag=0;Down_Flag=0;RoundUp_Flag=0;RoundDown_Flag=0;Automatic_Flag=0;AutomaticBuild_Flag=0;
            YPendTop6=y66;   %����ʼ�߶����ˮƽ���ߵĸ߶�
            a(7)=0;
            dr1=0;
        end
        if x66>1
            if dr1>-0.5
                dr1=dr1-0.025;
            else dr1=-0.5;
            end
            XSpeed=dr1;
            %             XSpeed=-0.5;
            YSpeed =YPendTop6-y66;
            if YSpeed>0.05
                YSpeed=0.05;
            elseif YSpeed<-0.05
                YSpeed=-0.05;
            end
        else
            XSpeed=0;YSpeed =0;
        end
        
    case 4,
        if Up_Flag==0   %��
            Left_Flag=0;Right_Flag=0;Up_Flag=1;Down_Flag=0;RoundUp_Flag=0;RoundDown_Flag=0;Automatic_Flag=0;AutomaticBuild_Flag=0;
            XPendTop6=x66;
            a(7)=0;
        end
        if y66<sqrt(L_Distance^2-XPendTop6^2)
            YSpeed=0.5;
            XSpeed =XPendTop6-x66;
        else
            XSpeed=0;YSpeed =0;
        end
        
    case 5,
        if Down_Flag==0
            Left_Flag=0;Right_Flag=0;Up_Flag=0;Down_Flag=1;RoundUp_Flag=0;RoundDown_Flag=0;Automatic_Flag=0;AutomaticBuild_Flag=0;
            XPendTop6=x66;     %����ʼˮƽλ����ɴ�ֱ���ߵĲ���ϵ
            a(7)=0;
        end
        if y66>-32
            YSpeed=-0.5;
            XSpeed =XPendTop6-x66;
        else
            XSpeed=0;YSpeed =0;
        end
        
    case 6,
        if RoundUp_Flag==0  %��ת����
            Left_Flag=0;Right_Flag=0;Up_Flag=0;Down_Flag=0;RoundUp_Flag=1;RoundDown_Flag=0;Automatic_Flag=0;AutomaticBuild_Flag=0;
            YPendTop6=y66;     %����ʼ�߶����ˮƽ���ߵĸ߶�
            r=x66;R=sqrt(L_Distance^2-YPendTop6^2);
            dr1=0;
            rx=r*cos(u(7)/180*pi);ry=r*sin(u(7)/180*pi);  %��ʼ����
        end
        if x66<R
            dr1=dr1+dl1;
            [Next_theta, next_x , next_z]=Route_Plan([rx,ry],pi/2,dr1);
        else [Next_theta, next_x , next_z]=Route_Plan([R*cos(u(7)/180*pi),R*sin(u(7)/180*pi)],0,0);
        end
        S=sqrt(next_x^2+next_z^2);
        deta=Next_theta-u(7);
        a(7)=deta;
        XSpeed=S-x66;
        YSpeed =YPendTop6-y66;
        
    case 7,
        if RoundDown_Flag==0  %��ת�������Ρ����Ρ�Բ��
            Left_Flag=0;Right_Flag=0;Up_Flag=0;Down_Flag=0;RoundUp_Flag=0;RoundDown_Flag=1;Automatic_Flag=0;AutomaticBuild_Flag=0;
            YPendTop6=y66;     %����ʼ�߶����ˮƽ���ߵĸ߶�
            r=x66;dr1=0;dr2=0;dr3=0;dr4=0;Angle=0;area=4;r1=r*cos(u(7)/180*pi);r2=r*sin(u(7)/180*pi);
            rx=r*cos(u(7)/180*pi);
            ry=r*sin(u(7)/180*pi);
        end
        if x66<sqrt(L_Distance^2-YPendTop6^2)
            YSpeed =YPendTop6-y66;
        else
            XSpeed=0;YSpeed =0;
        end
        
        A1=135/180*pi;L1=10;A2=-90/180*pi;L2=14.1421;A3=45/180*pi;L3=10;  %��������
        AA1=180/180*pi;LL1=20;AA2=90/180*pi;LL2=20;AA3=0/180*pi;LL3=20;AA4=-90/180*pi;LL4=20;   %�߾���
        
        if area==3
            if dr1<L1
                dr1=dr1+dl1;
                [Next_theta, next_x , next_z]=Route_Plan([rx,ry],A1,dr1);
            elseif dr2<L2
                dr2=dr2+dl1;
                [Next_theta, next_x , next_z]=Route_Plan([rx+L1*cos(A1),ry+L1*sin(A1)],A2,dr2);
            elseif dr3<L3
                dr3=dr3+dl1;
                [Next_theta, next_x , next_z]=Route_Plan([rx+L1*cos(A1)+L2*cos(A2),ry+L1*sin(A1)+L2*sin(A2)],A3,dr3);
            else
                [Next_theta, next_x , next_z]=Route_Plan([rx,ry],0,0);
                area=4;dr1=0;dr2=0;dr3=0;
            end
        elseif area==4
            if dr1<LL1
                dr1=dr1+dl1;
                [Next_theta, next_x , next_z]=Route_Plan([rx,ry],AA1,dr1);
            elseif dr2<LL2
                dr2=dr2+dl1;
                [Next_theta, next_x , next_z]=Route_Plan([rx+LL1*cos(AA1),ry+LL1*sin(AA1)],AA2,dr2);
            elseif dr3<LL3
                dr3=dr3+dl1;
                [Next_theta, next_x , next_z]=Route_Plan([rx+LL1*cos(AA1)+LL2*cos(AA2),ry+LL1*sin(AA1)+LL2*sin(AA2)],AA3,dr3);
            elseif dr4<LL4
                dr4=dr4+dl1;
                [Next_theta, next_x , next_z]=Route_Plan([rx+LL1*cos(AA1)+LL2*cos(AA2)+LL3*cos(AA3),ry+LL1*sin(AA1)+LL2*sin(AA2)+LL3*sin(AA3)],AA4,dr4);
            else
                [Next_theta, next_x , next_z]=Route_Plan([rx,ry],0,0);
                area=5;dr1=0;dr2=0;dr3=0;dr4=0;
            end
        elseif area==5
            radius=5;
            theta=acos((2*radius^2-dl^2)/(2*radius^2))/pi*180;
            if Angle<360
                Angle=Angle+theta;
                A1=90+Angle+theta/2;
                [Next_theta, next_x , next_z]=Route_Plan([r1,r2],A1,dl);
                r1=r1+dl1*cos(A1/180*pi);
                r2=r2+dl1*sin(A1/180*pi);
            else
                [Next_theta, next_x , next_z]=Route_Plan([rx,ry],0,0);
                area=3;Angle=0;r1=r;r2=0;
            end
        end
        S=sqrt(next_x^2+next_z^2);
        deta=Next_theta-u(7);
        a(7)=deta;
        XSpeed=S-x66;
        direction=directionTemp;
        if sign(XSpeed)~=sign(XSpeedTemp)   %�ж�ˮƽ���߷���
            directionTemp=-directionTemp;
        end
        XSpeedTemp=XSpeed;
        
    case 8,
        if Automatic_Flag==0  %��
            Left_Flag=0;Right_Flag=0;Up_Flag=0;Down_Flag=0;RoundUp_Flag=0;RoundDown_Flag=0;Automatic_Flag=1;AutomaticBuild_Flag=0;
            XPendTop6=x66;
            YPendTop6=y66;
            AngleInit=u(7);
            step1_flag=0;step2_flag=0;step3_flag=0;step4_flag=0;step5_flag=0;
            sety=u(15);
            x1=u(16);y1=u(17);x2=u(18);y2=u(19);x3=u(20);y3=u(21);x4=u(22);y4=u(23);
            A1=atan((y2-y1)/(x2-x1));
            if x2==x3
                A2=pi/2;
            else A2=atan((y3-y2)/(x3-x2));
            end
            A3=atan((y4-y3)/(x4-x3))+pi;
            if x1==x4
                A4=-pi/2;
            else A4=atan((y4-y3)/(x4-x3));
            end
            V=sety-YPendTop6;  %Ŀ������ʼ�㴹ֱ����
            V1=0;
            H=sqrt(x1^2+y1^2)-XPendTop6;    %Ŀ������ʼ��ˮƽ����
            H1=0;
            R=atan(y1/x1)*180/pi-u(7);
            MaxD=max(abs([2*V,2*H,R]));
            r1=x1;dr1=0;dr2=0;dr3=0;dr4=0;TotalD=0;
            close all
            FIG=figure('NumberTitle','off','Position',[770,450,500,500],'Color','w');
        end
        
        if step1_flag==0
            if (abs(x66-XPendTop6)<abs(H))&&(abs(y66-YPendTop6)<abs(V)) &&(abs(u(7)-AngleInit)<abs(R))&& step3_flag==0 && step4_flag==0 && step5_flag==0
                XSpeed=H/MaxD;
                YSpeed=V/MaxD;
                a(7)=R/MaxD;
                XPendTop6_1=x66;
                YPendTop6_1=y66;
                if step2_flag==0
                    step2_flag=1;
                end
            elseif (abs(u(7)-AngleInit)<abs(R)) && step4_flag==0 && step5_flag==0  % && step2_flag==1
                XSpeed=0;
                YSpeed =0;
                a(7)=R/MaxD;
                if step3_flag==0
                    step3_flag=1;
                end
            elseif abs(x66-XPendTop6)<abs(H) && step5_flag==0    % && step2_flag==1 &&  step3_flag==1
                XSpeed=H/MaxD;
                YSpeed =YPendTop6_1-y66;
                a(7)=0;
                if step4_flag==0
                    step4_flag=1;
                end
                XPendTop6_1=x66;
            elseif abs(y66-YPendTop6)<abs(V) % && step2_flag==1 && step3_flag==1 && step4_flag==1
                XSpeed=XPendTop6_1-x66;
                YSpeed =V/MaxD;
                a(7)=0;
                if step5_flag==0
                    step5_flag=1;
                end
            else XSpeed=0;
                YSpeed=0;
                a(7)=0;
                step1_flag=1;   %�Ѵӳ�ʼ���Զ��ߵ����εױ��е�
                YPendTop6=sety;
                step2=x66;
                step2_flag=0;step3_flag=0;step4_flag=0;step5_flag=0;
            end
        else if step1_flag==1
                width=0.4;
                if TotalD<y3-y2
                    if step2*cos(u(7)/180*pi)<x2 && step3_flag==0 && step4_flag==0 && step5_flag==0
                        dr1=dr1+dl;
                        if step2_flag==0
                            step2_flag=1;
                            NextRx=x1;
                            NextRy=y1+TotalD;
                        end
                        [Next_theta, next_x , next_z]=Route_Plan([NextRx,NextRy],A1,dr1);
                        step2=x66;
                        step3=x66;
                        dr4=0;
                    elseif (step3*sin(u(7)/180*pi)-NextRy)<width && step2_flag==1 && step4_flag==0 && step5_flag==0
                        dr2=dr2+dl;
                        if step3_flag==0
                            step3_flag=1;
                            NextRx=x2;
                            NextRy=y2+TotalD;
                            TotalD=TotalD+width;
                        end
                        [Next_theta, next_x , next_z]=Route_Plan([NextRx,NextRy],A2,dr2);
                        step3=x66;
                        step4=x66;
                    elseif step4*cos(u(7)/180*pi)>x1 && step2_flag==1 && step3_flag==1 && step5_flag==0
                        dr3=dr3+dl;
                        if step4_flag==0
                            step4_flag=1;
                            NextRx=x2;
                            NextRy=y2+TotalD;
                        end
                        [Next_theta, next_x , next_z]=Route_Plan([NextRx,NextRy],A3,dr3);
                        step4=x66;
                        step5=x66;
                    elseif (step5*sin(u(7)/180*pi)-NextRy)<width && step2_flag==1 && step3_flag==1 && step4_flag==1
                        dr4=dr4+dl;
                        if step5_flag==0
                            step5_flag=1;
                            NextRx=x1;
                            NextRy=y1+TotalD;
                            TotalD=TotalD+width;
                        end
                        [Next_theta, next_x , next_z]=Route_Plan([NextRx,NextRy],A2,dr4);
                        step5=x66;
                        step2=x66;
                    else
                        dr1=0;dr2=0;dr3=0;step2_flag=0;step3_flag=0;step4_flag=0;step5_flag=0;
                        [Next_theta, next_x , next_z]=Route_Plan([NextRx,NextRy],0,0);
                    end
                else [Next_theta, next_x , next_z]=Route_Plan([NextRx,NextRy],0,0);
                end
                S=sqrt(next_x^2+next_z^2);
                deta=Next_theta-u(7);
                a(7)=deta;
                XSpeed=S-x66;
                YSpeed =YPendTop6-y66;
            end
        end
        
    case 9,
        if AutomaticBuild_Flag==0  %��
            Left_Flag=0;Right_Flag=0;Up_Flag=0;Down_Flag=0;RoundUp_Flag=0;RoundDown_Flag=0;Automatic_Flag=0;AutomaticBuild_Flag=1;
            XPendTop6=x66;
            YPendTop6=y66;
            AngleInit=u(7);
            step1_flag=0;step2_flag=0;step3_flag=0;step4_flag=0;step5_flag=0;
            sety=10;
            x1=30;x2=33;x3=34;y1=-12;y2=-9;y3=-6;y4=6;y5=9;y6=12;
            A1=0;A2=pi/2;A3=pi;A4=-pi/2;
            
            V=sety-YPendTop6;  %Ŀ������ʼ�㴹ֱ����
            V1=0;
            H=sqrt(x1^2+y1^2)-XPendTop6;    %Ŀ������ʼ��ˮƽ����
            H1=0;
            R=atan(y1/x1)*180/pi-u(7);
            MaxD=max(abs([2*V,2*H,R]));
            r1=x1;dr1=0;dr2=0;dr3=0;dr4=0;TotalD=0;
            close all
            FIG=figure('NumberTitle','off','Position',[770,320,350,630],'Color','w');
        end
        
        if step1_flag==0
            if (abs(x66-XPendTop6)<abs(H))&&(abs(y66-YPendTop6)<abs(V)) &&(abs(u(7)-AngleInit)<abs(R))&& step3_flag==0 && step4_flag==0 && step5_flag==0
                XSpeed=H/MaxD;
                YSpeed=V/MaxD;
                a(7)=R/MaxD;
                XPendTop6_1=x66;
                YPendTop6_1=y66;
                if step2_flag==0
                    step2_flag=1;
                end
            elseif (abs(u(7)-AngleInit)<abs(R)) && step4_flag==0 && step5_flag==0  % && step2_flag==1
                XSpeed=0;
                YSpeed =0;
                a(7)=R/MaxD;
                if step3_flag==0
                    step3_flag=1;
                end
            elseif abs(x66-XPendTop6)<abs(H) && step5_flag==0    % && step2_flag==1 &&  step3_flag==1
                XSpeed=H/MaxD;
                YSpeed =YPendTop6_1-y66;
                a(7)=0;
                if step4_flag==0
                    step4_flag=1;
                end
                XPendTop6_1=x66;
            elseif abs(y66-YPendTop6)<abs(V) % && step2_flag==1 && step3_flag==1 && step4_flag==1
                XSpeed=XPendTop6_1-x66;
                YSpeed =V/MaxD;
                a(7)=0;
                if step5_flag==0
                    step5_flag=1;
                end
            else XSpeed=0;
                YSpeed=0;
                a(7)=0;
                step1_flag=1;   %�Ѵӳ�ʼ���Զ��ߵ����εױ��е�
                YPendTop6=sety;
                step2=x66;
                step2_flag=0;step3_flag=0;step4_flag=0;step5_flag=0;
            end
        else if step1_flag==1
                width=0.2;
                COS=cos(u(7)/180*pi);
                SIN=sin(u(7)/180*pi);
                if TotalD<y6-y1
                    if ((step2*COS<x2) || ((step2*COS<x3)&&((step2*SIN>y2 && step2*SIN<y3) ||(step2*SIN>y4 && step2*SIN<y5)))) && step3_flag==0 && step4_flag==0 && step5_flag==0
                        dr1=dr1+dl;
                        if step2_flag==0
                            step2_flag=1;
                            NextRx=x1;
                            NextRy=y1+TotalD;
                            nn=nn+1;
                            if nn>1
                                nn=0;
                            end
                        end
                        [Next_theta, next_x , next_z]=Route_Plan([NextRx,NextRy],A1,dr1);
                        step2=x66;
                        step3=x66;
                        dr4=0;
                    elseif (step3*SIN-NextRy)<width && step2_flag==1 && step4_flag==0 && step5_flag==0
                        dr2=dr2+dl;
                        if step3_flag==0
                            step3_flag=1;
                            if step3*COS>x2+0.5
                                NextRx=x3;
                            else NextRx=x2;
                            end
                            NextRy=y1+TotalD;
                            TotalD=TotalD+width;
                        end
                        [Next_theta, next_x , next_z]=Route_Plan([NextRx,NextRy],A2,dr2);
                        step3=x66;
                        step4=x66;
                    elseif step4*COS>x1 && step2_flag==1 && step3_flag==1 && step5_flag==0
                        dr3=dr3+dl;
                        if step4_flag==0
                            step4_flag=1;
                            if step4*COS>x2+0.5
                                NextRx=x3;
                            else NextRx=x2;
                            end
                            NextRy=y1+TotalD;
                        end
                        [Next_theta, next_x , next_z]=Route_Plan([NextRx,NextRy],A3,dr3);
                        step4=x66;
                        step5=x66;
                    elseif (step5*SIN-NextRy)<width && step2_flag==1 && step3_flag==1 && step4_flag==1
                        dr4=dr4+dl;
                        if step5_flag==0
                            step5_flag=1;
                            NextRx=x1;
                            NextRy=y1+TotalD;
                            TotalD=TotalD+width;
                        end
                        [Next_theta, next_x , next_z]=Route_Plan([NextRx,NextRy],A2,dr4);
                        step5=x66;
                        step2=x66;
                    else
                        dr1=0;dr2=0;dr3=0;step2_flag=0;step3_flag=0;step4_flag=0;step5_flag=0;
                        [Next_theta, next_x , next_z]=Route_Plan([NextRx,NextRy],0,0);
                    end
                else [Next_theta, next_x , next_z]=Route_Plan([NextRx,NextRy],0,0);
                end
                S=sqrt(next_x^2+next_z^2);
                deta=Next_theta-u(7);
                a(7)=deta;
                XSpeed=S-x66;
                YSpeed =YPendTop6-y66;
            end
        end
end

Q26=Para(P,L1,L2,L3,L4,L5,L6,angle1,angle2,angle3,angle4,angle5,angle6);
j=0;
for i=1:6
    if Q(i)==0
        j=j+1;
    end
end
if j<=4
    Y21=[XSpeed;YSpeed];
    X=New_Min_Warp(Q26,Y21,Q);
    a(1)=Sort0(angle1,L1_INI_ANGLE,L1_A1A2,L1_A1A3,X(1));
    a(2)=Sort2(angle2,L2_INI_ANGLE,L2_ANGLE123,L2_C1C2,L2_C2C3,L2_C3C4,L2_C4C5,L2_C5C6,L2_C2C5,L2_C2C6,X(2));
    a(3)=Sort2(angle3,L3_INI_ANGLE,L3_ANGLE123,L3_C1C2,L3_C2C3,L3_C3C4,L3_C4C5,L3_C5C6,L3_C2C5,L3_C2C6,X(3));
    a(4)=Sort2(angle4,L4_INI_ANGLE,L4_ANGLE123,L4_C1C2,L4_C2C3,L4_C3C4,L4_C4C5,L4_C5C6,L4_C2C5,L4_C2C6,X(4)) ;
    a(5)=Sort2(angle5,L5_INI_ANGLE,L5_ANGLE123,L5_C1C2,L5_C2C3,L5_C3C4,L5_C4C5,L5_C5C6,L5_C2C5,L5_C2C6,X(5));
    a(6)=Sort3(angle6,L6_INI_ANGLE,L6_ANGLE123,L6_D1D2,L6_D2D3,L6_D3D4,L6_D4D5,L6_D5D6,L6_D2D5,X(6));
else a=zeros(1,7);
end
if a(1)>0
    if a(1)>0.01659
        a=a*0.01659/a(1);
    end
elseif a(1)<0
    if a(1)<-0.01911
        a=-a*0.01911/a(1);
    end
end
if a(2)>0
    if a(2)>0.01659
        a=a*0.01659/a(2);
    end
elseif a(2)<0
    if a(2)<-0.01911
        a=-a*0.01911/a(2);
    end
end
if a(3)>0
    if a(3)>0.02322
        a=a*0.02322/a(3);
    end
elseif a(3)<0
    if a(3)<-0.02419
        a=-a*0.02419/a(3);
    end
end
if a(4)>0
    if a(4)>0.01755
        a=a*0.01755/a(4);
    end
elseif a(4)<0
    if a(4)<-0.01619
        a=-a*0.01619/a(4);
    end
end
if a(5)>0
    if a(5)>0.02708
        a=a*0.02708/a(5);
    end
elseif a(5)<0
    if a(5)<-0.02745
        a=-a*0.02745/a(5);
    end
end
if a(6)>0
    if a(6)>0.03774
        a=a*0.03774/a(6);
    end
elseif a(6)<0
    if a(6)<-0.049
        a=-a*0.049/a(6);
    end
end
x(1)=-a(1);
x(2)=a(2);x(3)=a(3);x(4)=a(4);
x(5)=-a(5);
x(6)=a(6);x(7)=a(7);
x(12)=69.058-u(1);   %�ۼܶ���֮��н�(����)�������������
x(13)=175.9865-u(2);
x(14)=149.6604-u(3);
x(15)=141.1757+u(4);
x(16)=160.1881+u(5);
x(17)=149.2637+u(6);
x(18)=u(7);
sys =x;
if n==5;
    n=0;
    if b==2 || b==3
        plot(x(8)*cos(u(7)/180*pi),x(9),'b.');
        axis([5 55 YPendTop6-0.2 YPendTop6+0.2]);
        xlabel('X');ylabel('Y');
        hold on
    end
    if b==4 || b==5
        plot(x(8)*cos(u(7)/180*pi),x(9),'b.');
        axis([XPendTop6-0.2 XPendTop6+0.2 -20 50]);
        xlabel('X');ylabel('Y');
        hold on
    end
    if b==7
        subplot(2,1,1)
        if area==3
            plot(x(8)*cos(u(7)/180*pi),x(8)*sin(u(7)/180*pi),'b.','MarkerSize',20);
        elseif area==4
            plot(x(8)*cos(u(7)/180*pi),x(8)*sin(u(7)/180*pi),'r.','MarkerSize',20);
        else plot(x(8)*cos(u(7)/180*pi),x(8)*sin(u(7)/180*pi),'k.','MarkerSize',20);
        end
        xlabel('X');ylabel('Y');
        %         axis([26 40 -10 10]);
        axis equal;
        hold on
        subplot(2,1,2)
        plot(x(8)*cos(u(7)/180*pi),x(9),'b.','MarkerSize',5);
        %         axis([26 40 16 17]);
        xlabel('X');ylabel('Z');
        hold on
    end
    if b==8
        if abs(x(9)-sety)<0.015
            subplot('position',[0.15 0.55 0.8 0.4])
            plot3(x(8)*cos(u(7)/180*pi),x(8)*sin(u(7)/180*pi),x(9),'b.','MarkerSize',20);
            hold on
            xlabel('X');ylabel('Y');zlabel('Z');
            axis([x1-0.5 x2+0.5 y1-0.5 y4+0.5 sety-0.5 sety+0.5]);
            view(80,14);
            subplot(2,2,3)
            plot(x(8)*cos(u(7)/180*pi),x(8)*sin(u(7)/180*pi),'b.','MarkerSize',20);
            xlabel('X');ylabel('Y');
            axis([x1-0.5 x2+0.5 y1-0.5 y4+0.5]);
            hold on
            subplot(2,2,4)
            if nn==0
                plot(x(8)*cos(u(7)/180*pi),x(9),'b','MarkerSize',6);
            else plot(x(8)*cos(u(7)/180*pi),x(9),'r','MarkerSize',6);
            end
            axis([x1-0.5 x2+0.5 sety-0.5 sety+0.5]);
            xlabel('X');ylabel('Z');
            hold on
        end
    end
    if b==9
        if abs(x(9)-sety)<0.015
            subplot('position',[0.15 0.55 0.8 0.4])
            plot3(x(8)*cos(u(7)/180*pi),x(8)*sin(u(7)/180*pi),x(9),'b.','MarkerSize',20);
            hold on
            xlabel('X');ylabel('Y');zlabel('Z');
            axis([x1-0.5 x3+0.5 y1-0.5 y6+0.5 sety-0.5 sety+0.5]);
            view(80,14);
            subplot(2,2,3)
            plot(x(8)*cos(u(7)/180*pi),x(8)*sin(u(7)/180*pi),'b.','MarkerSize',20);
            xlabel('X');ylabel('Y');
            axis([x1-0.5 x3+0.5 y1-0.5 y6+0.5]);
            hold on
            subplot(2,2,4)
            if nn==0
                plot(x(8)*cos(u(7)/180*pi),x(9),'b','MarkerSize',6);
            else plot(x(8)*cos(u(7)/180*pi),x(9),'r','MarkerSize',6);
            end
            axis([x1-0.5 x3+0.5 sety-0.5 sety+0.5]);
            xlabel('X');ylabel('Z');
            hold on
        end
    end
else n=n+1;
end

function sys=mdlOutputs(t,x,u)
sys=x;

function  Q26=Para(P,L1,L2,L3,L4,L5,L6,angle1,angle2,angle3,angle4,angle5,angle6)
Q26=[P(1)*(-L1*sin(angle1)+L2*sin(angle1+angle2)-L3*sin(angle1+angle2+angle3)+L4*sin(angle1+angle2+angle3+angle4)-L5*sin(angle1+angle2+angle3+angle4+angle5)+L6*sin(angle1+angle2+angle3+angle4+angle5+angle6)) ...
    P(2)*(L2*sin(angle1+angle2)-L3*sin(angle1+angle2+angle3)+L4*sin(angle1+angle2+angle3+angle4)-L5*sin(angle1+angle2+angle3+angle4+angle5)+L6*sin(angle1+angle2+angle3+angle4+angle5+angle6))...
    P(3)*(-L3*sin(angle1+angle2+angle3)+L4*sin(angle1+angle2+angle3+angle4)-L5*sin(angle1+angle2+angle3+angle4+angle5)+L6*sin(angle1+angle2+angle3+angle4+angle5+angle6)) ...
    P(4)*(L4*sin(angle1+angle2+angle3+angle4)-L5*sin(angle1+angle2+angle3+angle4+angle5)+L6*sin(angle1+angle2+angle3+angle4+angle5+angle6)) ...
    P(5)*(-L5*sin(angle1+angle2+angle3+angle4+angle5)+L6*sin(angle1+angle2+angle3+angle4+angle5+angle6))...
    P(6)*(L6*sin(angle1+angle2+angle3+angle4+angle5+angle6));
    -P(1)*(-L1*cos(angle1)+L2*cos(angle1+angle2)-L3*cos(angle1+angle2+angle3)+L4*cos(angle1+angle2+angle3+angle4)-L5*cos(angle1+angle2+angle3+angle4+angle5)+L6*cos(angle1+angle2+angle3+angle4+angle5+angle6)) ...
    -P(2)*(L2*cos((angle1+angle2))-L3*cos((angle1+angle2+angle3))+L4*cos(angle1+angle2+angle3+angle4)-L5*cos(angle1+angle2+angle3+angle4+angle5)+L6*cos(angle1+angle2+angle3+angle4+angle5+angle6)) ...
    -P(3)*(-L3*cos(angle1+angle2+angle3)+L4*cos(angle1+angle2+angle3+angle4)-L5*cos(angle1+angle2+angle3+angle4+angle5)+L6*cos(angle1+angle2+angle3+angle4+angle5+angle6)) ...
    -P(4)*(L4*cos(angle1+angle2+angle3+angle4)-L5*cos(angle1+angle2+angle3+angle4+angle5)+L6*cos(angle1+angle2+angle3+angle4+angle5+angle6)) ...
    -P(5)*(-L5*cos(angle1+angle2+angle3+angle4+angle5)+L6*cos(angle1+angle2+angle3+angle4+angle5+angle6))...
    -P(6)*(L6*cos(angle1+angle2+angle3+angle4+angle5+angle6))];

function  Oil_Pump_AB_Length=Sort0(Arm_AB_angle,Arm_initial_angle,A1_A2,A1_A3,delta_angle)
Angle_A213 = Arm_initial_angle+Arm_AB_angle;
Length=sqrt(A1_A2^2+A1_A3^2-2*A1_A2*A1_A3*cos(Angle_A213));
Angle_A213 = Angle_A213+delta_angle;
Length1=sqrt(A1_A2^2+A1_A3^2-2*A1_A2*A1_A3*cos(Angle_A213));
Oil_Pump_AB_Length=(Length1-Length)/1000;  %��λM

function  Oil_Pump_AB_Length=Sort2(Arm_AB_angle,Arm_initial_angle,Angle_C123,C1_C2,C2_C3,C3_C4,C4_C5,C5_C6,C2_C5,C2_C6,delta_angle)
Angle_C234 = Arm_initial_angle+Arm_AB_angle;
C2_C4 = sqrt(C2_C3^2+C3_C4^2-2*C2_C3*C3_C4*cos(Angle_C234));
Angle_C324=acos((C2_C3^2+C2_C4^2-C3_C4^2)/2/C2_C3/C2_C4);

if Angle_C234>pi
    Angle_C324=-Angle_C324;
end
Angle_C425=acos((C2_C4^2+C2_C5^2-C4_C5^2)/2/C2_C4/C2_C5);
Angle_C526=acos((C2_C5^2+C2_C6^2-C5_C6^2)/2/C2_C5/C2_C6);
Angle_C126=Angle_C123-Angle_C324-Angle_C425-Angle_C526;
Length=sqrt(C1_C2^2+C2_C6^2-2*C1_C2*C2_C6*cos(Angle_C126));

Angle_C234 =Angle_C234+delta_angle;
C2_C4 = sqrt(C2_C3^2+C3_C4^2-2*C2_C3*C3_C4*cos(Angle_C234));
Angle_C324=acos((C2_C3^2+C2_C4^2-C3_C4^2)/2/C2_C3/C2_C4);

if Angle_C234>pi
    Angle_C324=-Angle_C324;
end
Angle_C425=acos((C2_C4^2+C2_C5^2-C4_C5^2)/2/C2_C4/C2_C5);
Angle_C526=acos((C2_C5^2+C2_C6^2-C5_C6^2)/2/C2_C5/C2_C6);
Angle_C126=Angle_C123-Angle_C324-Angle_C425-Angle_C526;
Length1=sqrt(C1_C2^2+C2_C6^2-2*C1_C2*C2_C6*cos(Angle_C126));
Oil_Pump_AB_Length=(Length1-Length)/1000;  %��λM

function  Oil_Pump_AB_Length=Sort3(Arm_AB_angle,Arm_initial_angle,Angle_D123,D1_D2,D2_D3,D3_D4,D4_D5,D5_D6,D2_D5,delta_angle)
Angle_D234 = Arm_initial_angle+Arm_AB_angle;
Angle_D456=199.4445/180*pi;
D2_D4 = sqrt(D2_D3^2+D3_D4^2-2*D2_D3*D3_D4*cos(Angle_D234));
Angle_D324=acos((D2_D3^2+D2_D4^2-D3_D4^2)/2/D2_D3/D2_D4);

if Angle_D234>pi
    Angle_D324=-Angle_D324;
end
Angle_D425=acos((D2_D4^2+D2_D5^2-D4_D5^2)/2/D2_D4/D2_D5);
Angle_D254=acos((D2_D5^2+D4_D5^2-D2_D4^2)/2/D2_D5/D4_D5);
Angle_D256=Angle_D456-Angle_D254;
D2_D6=sqrt(D2_D5^2+D5_D6^2-2*D2_D5*D5_D6*cos(Angle_D256));
Angle_D526=acos((D2_D5^2+D2_D6^2-D5_D6^2)/2/D2_D5/D2_D6);
Angle_D126=Angle_D123-Angle_D526-Angle_D425-Angle_D324;
Length=sqrt(D1_D2^2+D2_D6^2-2*D1_D2*D2_D6*cos(Angle_D126));

Angle_D234 =Angle_D234+delta_angle;
Angle_D456=199.4445/180*pi;
D2_D4 = sqrt(D2_D3^2+D3_D4^2-2*D2_D3*D3_D4*cos(Angle_D234));
Angle_D324=acos((D2_D3^2+D2_D4^2-D3_D4^2)/2/D2_D3/D2_D4);

if Angle_D234>pi
    Angle_D324=-Angle_D324;
end
Angle_D425=acos((D2_D4^2+D2_D5^2-D4_D5^2)/2/D2_D4/D2_D5);
Angle_D254=acos((D2_D5^2+D4_D5^2-D2_D4^2)/2/D2_D5/D4_D5);
Angle_D256=Angle_D456-Angle_D254;
D2_D6=sqrt(D2_D5^2+D5_D6^2-2*D2_D5*D5_D6*cos(Angle_D256));
Angle_D526=acos((D2_D5^2+D2_D6^2-D5_D6^2)/2/D2_D5/D2_D6);
Angle_D126=Angle_D123-Angle_D526-Angle_D425-Angle_D324;
Length1=sqrt(D1_D2^2+D2_D6^2-2*D1_D2*D2_D6*cos(Angle_D126));
Oil_Pump_AB_Length=(Length1-Length)/1000;  %��λM

function X=New_Min_Warp(Q26,Y21,Q)
j=0;k=0;Z_Place=0;
for i=1:6
    if Q(i)~=0
        j=j+1;
        Q1(j)=Q(i);
    else
        k=k+1;
        Z_Place(k)=i;
    end
end
j=0;
for i=1:6
    if Q26(:,i)~=0
        j=j+1;
        QQ26(:,j)=Q26(:,i);
    end
end
Q;   %Q�п��ܵ���0
Q_Transfer=diag(sqrt(Q1));
New_Q26=QQ26/Q_Transfer;
X1=Q_Transfer\pinv(New_Q26)*Y21;
j=1;
if Z_Place(1)==0
    X=X1;
else for i=1:6
        if j<=size(Z_Place,2)
            if i==Z_Place(j)
                X(i)=0;
                j=j+1;
            else X(i)=X1(i-j+1);
            end
        else X(i)=X1(i-j+1);
        end
    end
end

function [theta,X,Z]=Route_Plan(Point,Angle,L)
X=Point(1)+L*cos(Angle);
Z=Point(2)+L*sin(Angle);
if X>0;
    theta=atan(Z/X);
else
    theta=atan(Z/X)+pi;
end
theta=theta*180/pi;
if theta>180
    theta=theta-360;
end