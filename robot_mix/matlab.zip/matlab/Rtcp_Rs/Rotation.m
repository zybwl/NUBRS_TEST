clc;
clear;
close all;

point_a.x = 4;
point_a.y = 2;
point_b.x = 10;
point_b.y = 2;
rotation = 270/180*pi;

for theta = 0:1/180*pi:rotation
    rot_param = [cos(theta)  -sin(theta); 
                 sin(theta) cos(theta)];
    vect_param = [point_b.x - point_a.x ; 
                  point_b.y - point_a.y];
    new_point = [point_a.x ;point_a.y] + rot_param * vect_param ;
    
    plot( [0 point_a.x point_b.x] , [0 point_a.y point_b.y] ,'*r');
    hold on
    plot([0 point_a.x  new_point(1)] , [0 point_b.y  new_point(2)])
    pause(0.1)
end





