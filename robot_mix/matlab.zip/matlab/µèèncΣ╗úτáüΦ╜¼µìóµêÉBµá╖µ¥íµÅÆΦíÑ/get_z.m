
function result = get_z(x,y,z)

c = [0.001  -0.0216   0.023   0.0139   0.1169   -0.1618   0.0065];
% x = 1.9699;
% y = 1.3342;
%z = -0.3689;

a = 0.001;
b = -0.0216;
c = 0.023;
d = 0.0139;
e = 0.1169;
f = -0.1618;
g = 0.0065;

a1 = c;
b1 = e*x + f*y;
c1 = a*x^2 + b*y^2 + d*x*y + g;

s = b1^2 - 4* a1*c1;
if s<= 0
    result = -b1 /2/c;
else
    dd = -b1/2/c;
    if dd - c < 0
       r1 = (-b1 + sqrt(s))/2/c ;
       r2 = (-b1 - sqrt(s))/2/c ;
       if abs(r1 - z) < abs(r2 -z)
           result = r1;
       else
           result = r2;
       end
    end
end

