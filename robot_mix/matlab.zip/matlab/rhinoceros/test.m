clc;clear all;
index = 1;
for angle_a = 1:0.1 : 90
    for angle_c = 1:0.1:90
        rot_a = get_rotation_matrix(1, angle_a);
        rot_c = get_rotation_matrix(3, angle_c);
        index = index + 1
        point_a = [0,1,1,1]';
        point_b = [1,0,0,1]';
        new_a = rot_a * rot_c * point_a;
        new_b = rot_a * rot_c * point_b;
        v1 = point_b - point_a;
        v2 = new_b - new_a;

        p1 = v1(1:3);
        x1 = p1(1);  y1 = p1(2); z1 = p1(3);
        p2 = v2(1:3);
        x2 = p2(1);  y2 = p2(2); z2 = p2(3);

        if y2 < 0
            t =  asin(-z2 / sqrt(y2^2 + z2^2));
            at = asin(-z1 / sqrt(y2^2 + z2^2));
        else
            t = asin(z2 / sqrt(y2^2 + z2^2));
            at = asin(z1 / sqrt(y2^2 + z2^2));
        end
        rev_a_angle = (at - t)*180/pi;
        if abs(rev_a_angle + angle_a) > 1
            angle_a
            break;
        end

        rev_rot_a = get_rotation_matrix(1, rev_a_angle);
        rev_v2 = rev_rot_a * v2;
        x3 = rev_v2(1); y3 = rev_v2(2); z3 = rev_v2(3);

        if x3 < 0
            t =  asin(-y3 / sqrt(x3^2 + y3^2));
            at = asin(-y1 / sqrt(x3^2 + y3^2));
        else
            t = asin(y3 / sqrt(x3^2 + y3^2));
            at = asin(y1 / sqrt(x3^2 + y3^2));
        end
        rev_c_angle = (at - t)*180/pi;
        if abs(rev_c_angle + angle_c) > 1
            angle_c
            break;       
        end
        k1 = get_rotation_matrix(1, rev_a_angle);
        k2 = get_rotation_matrix(3, rev_c_angle);
        new_v1 = k2 * k1 * v2;
        if norm(new_v1 - v1) > 1e-3
            rev_a_angle
            break;
        end
    end
end

% rev_rot_a = get_rotation_matrix(1, -15);
% rev_rot_c = get_rotation_matrix(3, -30);
% replay_a = rev_rot_a * v2


% 
% 
% 
% vc_ab = point_b - point_a;
% vc_new_ab = new_b - new_a;
% 
% sin2 = asin(vc_ab(1) / norm(vc_ab(1:2)));
% sin1 = asin(vc_new_ab(1)/ norm(vc_ab(1:2)));
% anglec = sin2 - sin1;
% c = anglec/pi*180

% cosc = cos(anglec);
% sinc = sin(anglec);
% vc_bc = [vc_ab(1) * sinc + vc_ab(2) * cosc , vc_ab(3)];
% cost4 = acos(vc_new_ab(2)/ norm(vc_bc));
% cost3 = acos(vc_bc(1) / norm(vc_bc));
% anglea = cost3 - cost4;
% a = anglea/pi*180



