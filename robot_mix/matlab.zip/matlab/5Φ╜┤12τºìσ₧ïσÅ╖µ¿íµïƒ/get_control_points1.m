function new_points = get_control_points1(L, points)

new_points = [];
n = size(points,1);
v_inter_step = 0;
for i = 1:n  
    pre_i = max(1,i-1);
    next_i = min(n,i+1);
    point1 = points(pre_i,:);
    point2 = points(i,:);
    point3 = points(next_i,:);
    if norm(point3 - point1)<eps || v_inter_step == 1
        v_inter_step = v_inter_step + 1;
    else
        v_inter_step = 0;
    end
    if i == 1
        line_angle = get_line_angle(point2,point3); 
        inter_angle = 0;
    elseif i==n
        line_angle = new_points(end,3);
        inter_angle = 0;
    else
        v1_x = point2(1) - point1(1);
        v1_y = point2(2) - point1(2); 
        v2_x = point3(1) - point2(1);
        v2_y = point3(2) - point2(2);
        line_angle = new_points(end,3);
        if v_inter_step == 2       
            inter_angle = get_inter_angle(-v1_x,-v1_y,v2_x,v2_y);
        else         
            inter_angle = get_inter_angle(v1_x,v1_y,v2_x,v2_y);
        end        
    end       
    max_inter_angle = 2;
    if abs(inter_angle)<20
         arc_angle = line_angle +  inter_angle;
         control_point = get_one_point(point2, L , arc_angle);
         %��i�ӽ�ȥ
         temp_points = [control_point,i];      
    elseif v_inter_step == 1
         arc_angle = line_angle - 180 + inter_angle;
         control_point = get_one_point(point2, L , arc_angle);
         temp_points = [control_point,i];            
    else     
        m = floor(abs(inter_angle)/max_inter_angle)+1;
        temp_points = zeros(m+1,4);
        for j = 0:m
            arc_angle = line_angle + j*inter_angle/m;
            control_point = get_one_point(point2, L , arc_angle);
            temp_points(j+1,:) = [control_point,i];
        end        
    end
    new_points = [new_points;temp_points];     
end    
    