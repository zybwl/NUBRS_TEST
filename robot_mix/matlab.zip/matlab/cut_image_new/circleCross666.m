function cross_point = circleCross(figure_point_array , circle)  
% load figure_array
% circle.r = 100;
% circle.x = 300;
% circle.y = 300;
% circle.ang1 = 100;
% circle.ang2 = 200;
% figure_point_array = figure_array(4);
% plot(figure_point_array.x ,figure_point_array.y);
% hold on

if circle.ang1 < circle.ang2
    ang = circle.ang1:circle.ang2;
else
    ang = circle.ang2:circle.ang1;
end
circle_x = circle.x + circle.r * cos(pi*ang/180);
circle_y = circle.y + circle.r * sin(pi*ang/180);    
plot(circle_x,circle_y ,'r');
hold on

vect_angle = [circle.ang1,circle.ang2];
ang1_index = floor(circle.ang1/90);
ang2_index = floor(circle.ang2/90);
if ang2_index > ang1_index
    for index = ang1_index + 1:ang2_index
        vect_angle = [vect_angle 90*index];
    end
else
    for index = ang2_index + 1:ang1_index
        vect_angle = [vect_angle 90*index];
    end
end

%������Բ������С���Σ����ټ�����
r1.left = 9999;
r1.right = -9999; 
r1.bottom = 9999;
r1.top = -9999;

for i = 1:length(vect_angle)
    r1.left = min(circle.x + circle.r * cos(pi*vect_angle(i)/180) , r1.left);
    r1.right = max(circle.x + circle.r * cos(pi*vect_angle(i)/180) , r1.right);
    r1.bottom = min(circle.y + circle.r * sin(pi*vect_angle(i)/180) , r1.bottom);
    r1.top = max(circle.y + circle.r * sin(pi*vect_angle(i)/180) , r1.top);
end
% plot([r1.left,r1.left,r1.right,r1.right,r1.left],[r1.bottom,r1.top,r1.top,r1.bottom,r1.bottom],'r')
% hold on

r2.left = figure_point_array.x_range(1);
r2.right = figure_point_array.x_range(2);
r2.bottom = figure_point_array.y_range(1);
r2.top = figure_point_array.y_range(2);

% �ж��������ཻ���ཻ����
% ��4�������ͼһ�ֱ���ͼ�����ϡ��¡�����
% ͼһΪcircle������ͼ������ͼԪ
% �������Ҫȡ��Ŷ
is_cross_or_not = ~((r1.bottom > r2.top) || (r2.bottom > r1.top) || (r1.right < r2.left) || (r2.right < r1.left)) ;
point = [];

%���������ཻ�������п��ܴ��ڽ���

cross_point = [];
if is_cross_or_not
    x = figure_point_array.x;
    y = figure_point_array.y;
    n = length(x);
    for i = 1:n
        next_index =  1+ mod(i,n);
        % ��ֹ2����һģһ�������³���Ϊ�㣬������������
        if (y(i) == y(next_index) && x(i) == x(next_index)) continue ; end;
        vect_x1 = x(i) - circle.x;
        vect_x2 = x(next_index) - circle.x;
        vect_y1 = y(i) - circle.y;
        vect_y2 = y(next_index) - circle.y;
        vect_x0 = x(next_index) - x(i);
        vect_y0 = y(next_index) - y(i);
        L0 = sqrt(vect_y0^2 + vect_x0^2);
        tanx = vect_x0 / L0;
        tany = vect_y0 / L0;
        % �����
        S = vect_x2 * vect_y1 - vect_x1 * vect_y2;            
        h = S/L0;
        %���߳��ȳ����뾶���϶������ཻ
        if h > circle.r
            continue
        elseif h == circle.r
            %ֻ��1������
            cross_point_x = circle.x - tany * h;
            cross_point_y = circle.y + tanx * h;
            if isDotInline([x(i), y(i)],[cross_point_x ,cross_point_y],[x(next_index),y(next_index)])
                cross_point = [cross_point; cross_point_x , cross_point_y];
            end
        else 

            vertical_l = sqrt(circle.r^2 - h^2);
            %����x��y
            vertical_x = circle.x - tany * h;
            vertical_y = circle.y + tanx * h;

            cross_point1_x = vertical_x -  tanx * vertical_l;
            cross_point1_y = vertical_y -  tany * vertical_l;           
            cross_point2_x = vertical_x +  tanx * vertical_l;        
            cross_point2_y = vertical_y +  tany * vertical_l;
            
            %�жϵ��Ƿ�������
                        
            if isDotInline([x(i), y(i)],[cross_point1_x ,cross_point1_y ],[x(next_index),y(next_index)])
               cross_point = [cross_point; cross_point1_x , cross_point1_y];
            end
            if isDotInline([x(i), y(i)],[cross_point2_x ,cross_point2_y ],[x(next_index),y(next_index)])
               cross_point = [cross_point; cross_point2_x , cross_point2_y];
            end   
         end                         
    end
end
plot(cross_point(:,1),cross_point(:,2) ,'*r');








