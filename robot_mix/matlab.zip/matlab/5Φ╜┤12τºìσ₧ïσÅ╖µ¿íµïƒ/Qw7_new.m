clc;clear all;close all;
% [FileName,PathName] = uigetfile('./*.*','Select the file');
% file_name = strcat(PathName,FileName);

file_name = './QW7.NC';
fid= fopen(file_name);

%��ȡ�ļ�
point_struct_array = get_nc_data(file_name, 11,1000);
n = size(point_struct_array,2);

for i= 1:299
    points(i, 1) = point_struct_array(i).X;
    points(i, 2) = point_struct_array(i).Y;
    points(i, 3) = point_struct_array(i).Z;
%     points(i, 4) = point_struct_array(i).A;
%     points(i, 5) = point_struct_array(i).C;
end

new_data = fitting(points , 20 , 500);
figure(1)
plot3(points(:,1),points(:,2),points(:,3), 'b')
hold on
plot3(new_data(:,1) + 10 ,new_data(:,2) + 10 ,new_data(:,3) + 10,'-r'); 
% 
xxx = '';
for j = 1:501
%     xxx = sprintf('%s X%.3f Y%.3f Z%.3f A%.3f C%.3f\n',xxx, new_data(j,1) ,new_data(j,2),new_data(j,3),new_data(j,4),new_data(j,5));
    xxx = sprintf('%s X%.3f Y%.3f Z%.3f\n',xxx, new_data(j,1) ,new_data(j,2),new_data(j,3));
end
xxx