function [x,y,z] = get_halfball_data(center,r , angle)
%�ο��Ǿ���B������2ҳ
%ֻ��һ����Բ
m = 11; n =11;
x1 = zeros(m,n);
y1 = zeros(m,n);
z1 = zeros(m,n);
rot_a = get_rotation_matrix(1, angle(1));
rot_c = get_rotation_matrix(2, angle(2));
for i = 1 : m
    for j = 1: n
        u = (i - 1) * pi / 20 ;
        v = (j - 1) * pi / 10 ;
        x1(i,j) = sin(u) * cos(v);
        y1(i,j) = sin(u) * sin(v);
        z1(i,j) = cos(u);
        point = rot_a * rot_c * [x1(i,j);y1(i,j);z1(i,j);1];
        x1(i,j) = point(1);
        y1(i,j) = point(2);
        z1(i,j) = point(3);
    end
end
x = r * x1 + center(1);
y = r * y1 + center(2);
z = r * z1 + center(3);
% mesh(r*x1+x0,r*y1+y0,r*z1+z0);
% axis equal



