function DynamicInfo_copy = GetDistance(DynamicInfo)
    
    DynamicInfo_copy = DynamicInfo;
    t = DynamicInfo.t;    
    l = 0;
    if(DynamicInfo.current_time < t(1))
        relative_time = DynamicInfo.current_time;      
        l = DynamicInfo.ls + DynamicInfo.fs * relative_time + DynamicInfo.J * relative_time^3 /6;   
        DynamicInfo_copy.L(1) = l;
    elseif(DynamicInfo.current_time < t(2))
        relative_time = DynamicInfo.current_time - t(1);
        l = DynamicInfo.L(1) + DynamicInfo.F(1) * relative_time + 0.5* DynamicInfo.acceleration * relative_time^2;
        DynamicInfo_copy.L(2) = l;
    elseif(DynamicInfo.current_time < t(3))
        relative_time = DynamicInfo.current_time - t(2);
        speed = DynamicInfo_copy.F(2) + DynamicInfo_copy.acceleration * relative_time - 0.5 * DynamicInfo_copy.J * relative_time^2;
        l = DynamicInfo.L(2) + DynamicInfo.F(2) * relative_time + 0.5 * DynamicInfo.acceleration * relative_time^2 - DynamicInfo.J * relative_time^3 / 6;       
        DynamicInfo_copy.L(3) = l;
    elseif(DynamicInfo.current_time < t(4))      
        relative_time = DynamicInfo.current_time - t(3);
        l = DynamicInfo.L(3) + DynamicInfo.F(3) * relative_time;
        DynamicInfo_copy.L(4) = l;      
    elseif(DynamicInfo.current_time < t(5))
        relative_time = DynamicInfo.current_time - t(4);
        l = DynamicInfo.L(4) + DynamicInfo.F(4) * relative_time - DynamicInfo.J * relative_time^3 / 6;
        DynamicInfo_copy.L(5) = l;
    elseif(DynamicInfo.current_time < t(6))
        relative_time = DynamicInfo.current_time - t(5);
        l = DynamicInfo.L(5) + DynamicInfo.F(5) * relative_time - 0.5 * DynamicInfo.deceleration * relative_time^2; 
        DynamicInfo_copy.L(6) = l;
    elseif(DynamicInfo.current_time <= t(7))
        relative_time = DynamicInfo.current_time - t(6);
%         speed = DynamicInfo_copy.F(6) - DynamicInfo.deceleration * relative_time + 0.5 * DynamicInfo_copy.J * relative_time^2;
        l = DynamicInfo.L(6) + DynamicInfo.F(6) * relative_time - 0.5 * DynamicInfo.deceleration * relative_time^2 + DynamicInfo.J * relative_time^3 / 6;                
        DynamicInfo_copy.L(7) = l;
    else
        l = 0;
    end
    DynamicInfo_copy.l = l;
    
 end