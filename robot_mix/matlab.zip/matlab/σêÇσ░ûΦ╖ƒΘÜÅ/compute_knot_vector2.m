function kv = compute_knot_vector2(degree, num_dpts, num_cpts, params)

    kv = zeros(1,num_cpts);
    % Compute "d" value - Eqn 9.68
    d = num_dpts / (num_cpts - degree);
    for j = 1:(num_cpts - degree) - 1
        i = floor(j * d);
        alpha = (j * d) - i;
        temp_kv = ((1.0 - alpha) * params(i) + (alpha * params(i + 1)));
        kv(j + degree + 1) = temp_kv;
    end

    kv = [kv , ones(1,degree + 1)];