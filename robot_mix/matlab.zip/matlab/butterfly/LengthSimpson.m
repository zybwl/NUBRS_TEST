function d= LengthSimpson(startPoint, endPoint, de1, de2, de3) 
%%%��
d=(de1+ 4*de2+ de3) *(endPoint-startPoint)/6;
%%%���� 
% midPoint = (startPoint + endPoint) / 2;
% segmentLength = endPoint - startPoint;
% % ��������ɭ��ʽ�����
% d = ((segmentLength / 6) * (de1 + 4 *ArcLengthDerivative(startPoint + (segmentLength)/2)...
% +2 *ArcLengthDerivative(startPoint + (segmentLength)*2/2)+ 4 *ArcLengthDerivative(startPoint +segmentLength*3/2)+de3));

end

