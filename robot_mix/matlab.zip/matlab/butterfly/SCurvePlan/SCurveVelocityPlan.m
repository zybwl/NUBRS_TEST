function Sparam = SCurveVelocityPlan(plan_param)
% S �滮
% ���룺�����ٶȡ������ٶȡ����jerk�������ٶȡ�·�����ȡ���ʼ�ٶȡ���ֹ�ٶ�
A = plan_param(1);
D = plan_param(2);
Ja = plan_param(3);
Jd = plan_param(4);
F = plan_param(5);
S = plan_param(6);
orivs = plan_param(7);
orive = plan_param(8);

adjustVmax = false;

% �������������������������ͳһΪF����vs��ve������
if F < orivs  && F >=orive
    vs = 2*F - orivs;
    ve = orive;
elseif F < orive && F>=orivs
    vs = orivs;
    ve = 2*F - orive;
elseif F<orive && F<orivs
    vs = 2*F - orivs;
    ve = 2*F - orive;
elseif F>=orivs && F>=orive
    vs = orivs;
    ve = orive;
end

Sparam = displaceOfAccDec(A,D,Ja,Jd,F,vs,ve);
if abs(Sparam.displacementOfAD-S) < 1e-6 % ��С�����ֵ������Ϊ�������
    Sparam.vknot(4) = F;
    Sparam.Vmax = F;
elseif Sparam.displacementOfAD < S
    Sparam.T(4) = (S-Sparam.displacementOfAD)/F;
    Sparam.vknot(4) = F;
    Sparam.Vmax = F; 
elseif Sparam.displacementOfAD > S 
    % �������ٶΣ���ʱ����ٶȲ���F����Ҫ���
    NewSparameter = findVmaxOfSCurve(vs,ve,S,F);
    Sparam = NewSparameter;
    % 9/30�޸�
    if adjustVmax == true
        Sparam.Vmax = max(Sparam.vs,Sparam.ve);
        Sparam = SCurveVelocityPlan([A,D,Ja,Jd,Sparam.Vmax,S,Sparam.vs,Sparam.ve]);
        adjustVmax = false;
    end
    % ��õ�����ٶȿ��ܸ�vs��ve�ر�ӽ�����ʱ����Բ���ᵼ�¼��ٶȻ�Jerk�������䣬��˽��е���
    if (Sparam.Vmax-Sparam.ve)/Sparam.ve<0.05 && (Sparam.Vmax-Sparam.vs)/Sparam.vs>0.05 % �ٶȲ���С��5%�����
        Sparam.Vmax = Sparam.ve;
        fprintf('vmax adjust to ve when S-plan.\n');
        Sparam = SCurveVelocityPlan([Sparam.Amax,Sparam.Dec,Sparam.Jamax,Sparam.Jdmax,Sparam.Vmax,S,Sparam.vs,Sparam.ve]); %��Ҫ�����¹滮һ��
    elseif (Sparam.Vmax-Sparam.vs)/Sparam.vs<0.05 && (Sparam.Vmax-Sparam.ve)/Sparam.ve>0.05
        Sparam.Vmax = Sparam.vs;
        fprintf('vmax adjust to vs when S-plan.\n');
        Sparam = SCurveVelocityPlan([Sparam.Amax,Sparam.Dec,Sparam.Jamax,Sparam.Jdmax,Sparam.Vmax,S,Sparam.vs,Sparam.ve]); %��Ҫ�����¹滮һ��
    elseif (Sparam.Vmax-Sparam.vs)/Sparam.vs<0.05 && (Sparam.Vmax-Sparam.ve)/Sparam.ve<0.05
        Sparam.vs = Sparam.Vmax;
        Sparam.ve = Sparam.Vmax;
        fprintf('ve and vs adjust to vmax when S-plan.\n');
        Sparam = SCurveVelocityPlan([Sparam.Amax,Sparam.Dec,Sparam.Jamax,Sparam.Jdmax,Sparam.Vmax,S,Sparam.vs,Sparam.ve]); %��Ҫ�����¹滮һ��
    end
    Sparam.vknot(4) = Sparam.Vmax;
end

% for j = 1:length(Sparam.T)
%     Sparam.t(j) = sum(Sparam.T(1:j));
% end
Sparam.t = cumsum(Sparam.T);
Sparam.Stol = S;

Sparam.sknot(4) = Sparam.sknot(3) + Sparam.vknot(3)*Sparam.T(4);
Sparam.sknot(5) = Sparam.sknot(4) + Sparam.vknot(4)*Sparam.T(5) - (1/6)*Sparam.Jdmax*Sparam.T(5)^3;
Sparam.sknot(6) = Sparam.sknot(5) + Sparam.vknot(5)*Sparam.T(6) - (1/2)*Sparam.Dec*Sparam.T(6)^2;
Sparam.sknot(7) = Sparam.sknot(6) + Sparam.vknot(6)*Sparam.T(7) - (1/2)*Sparam.Dec*Sparam.T(7)^2 + ...
                  (1/6)*Sparam.Jdmax*Sparam.T(7)^3;

% S�滮��󣬽��ٶ���������
if F < orivs  && F >=orive
    Sparam.vs = 2*F - Sparam.vs;
    Sparam.vknot(1:2) = 2*F - Sparam.vknot(1:2);
elseif F < orive && F>=orivs
    Sparam.ve = 2*F - Sparam.ve;
    Sparam.vknot(5:7)  =2*F - Sparam.vknot(5:7);
elseif F<orive && F<orivs
    Sparam.vs = 2*F - Sparam.vs;
    Sparam.ve = 2*F - Sparam.ve;
    Sparam.vknot(1:2) = 2*F - Sparam.vknot(1:2);
    Sparam.vknot(5:7)  =2*F - Sparam.vknot(5:7);
end

    function Sparameter = findVmaxOfSCurve(vs,ve,S,F)
        eps = 1e-6;
        if F > vs && F > ve
            vlow = max(vs,ve);
            vhigh = F;
            vmax = (vlow+vhigh)/2;
            acc = A;
            dec = D;
            Sparameter = displaceOfAccDec(acc,dec,Ja,Jd,vmax,vs,ve);
            iter = 0;
            while abs(Sparameter.displacementOfAD-S) > eps
                if Sparameter.displacementOfAD<S
                    vlow = vmax;
                    vmax = (vlow+vhigh)/2;
                elseif Sparameter.displacementOfAD>S
                    vhigh = vmax;
                    vmax = (vlow+vhigh)/2;
                end
                Sparameter = displaceOfAccDec(acc,dec,Ja,Jd,vmax,vs,ve);
                iter = iter + 1;
%                 if iter > 20
%                     adjustVmax = true;
%                     break;
%                 end
            end
            Sparameter.iter = iter;
        elseif F == vs && F > ve  % ��ֻ�н��ٶ�ʱ��������S�滮�ﵽ���ٶ�
            vlow = ve;
            vhigh = F;
            vmax = (vlow+vhigh)/2;
            vs = vmax;
            acc = A;
            dec = D;
            Sparameter = displaceOfAccDec(acc,dec,Ja,Jd,vmax,vs,ve);
            iter = 0;
            while abs(Sparameter.displacementOfAD-S) > eps
                if Sparameter.displacementOfAD<S
                    vlow = vmax;
                    vmax = (vlow+vhigh)/2;
                    vs = vmax;
                elseif Sparameter.displacementOfAD>S
                    vhigh = vmax;
                    vmax = (vlow+vhigh)/2;
                    vs = vmax;
                end
                Sparameter = displaceOfAccDec(acc,dec,Ja,Jd,vmax,vs,ve);
                iter = iter + 1;
%                 if iter > 20
%                     adjustVmax = true;
%                     break;
%                 end
            end
            Sparameter.iter = iter;
        elseif F == ve && F > vs % ��ֻ�����ٶ�ʱ��������S�滮�ﵽ���ٶ�
            vlow = vs;
            vhigh = F;
            vmax = (vlow+vhigh)/2;
            ve = vmax;
            acc = A;
            dec = D;
            Sparameter = displaceOfAccDec(acc,dec,Ja,Jd,vmax,vs,ve);
            iter = 0;
            while abs(Sparameter.displacementOfAD-S) > eps
                if Sparameter.displacementOfAD<S
                    vlow = vmax;
                    vmax = (vlow+vhigh)/2;
                    ve = vmax;
                elseif Sparameter.displacementOfAD>S
                    vhigh = vmax;
                    vmax = (vlow+vhigh)/2;
                    ve = vmax;
                end
                Sparameter = displaceOfAccDec(acc,dec,Ja,Jd,vmax,vs,ve);
                iter = iter + 1;
%                 if iter > 20
%                     adjustVmax = true;
%                     break;
%                 end
            end
            Sparameter.iter = iter;
        end
    end
end

