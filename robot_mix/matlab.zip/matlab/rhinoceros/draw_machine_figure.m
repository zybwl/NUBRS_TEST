% function  draw_machine_figure(angleA, angleC)
% clc;clear;close all;
angleA = 0; angleC = 0;
angle = [angleA,0];
cuboid_param = [1000, 300, 50];
center1 = [1000,1000,0];
[x1, y1,z1] = get_cuboid_data(cuboid_param ,center1, angle);
fill3(x1, y1, z1,[1,0,0]);
axis([500 1500 800 1200 -200 200]);
hold on
axis equal
xlabel('x');ylabel('y');zlabel('z');

angle = [angleA, angleC];
center2 = [1250, 1000, 35];
ra = get_rotation_matrix(1 , angle(1));
ta = get_translation_matrix(center1);
new_center = ta * ra * [center2 - center1 , 1]';
new_center2 = new_center(1:3)';
h = 20;
r = 100;
[x2, y2, z2] = get_cylinder_data(new_center2, h , r ,angle);
surf(x2,y2,z2 ,'FaceColor',[0,0,1]);
fill3(x2,y2,z2, [0 1 0]); 
plot3(x2',y2',z2','*');
axis([500 1500 800 1200 -200 200]);

angle = [angleA, angleC];
center3 = [1270, 1030 , 55];
rc = get_rotation_matrix(3 , angle(2));
tc = get_translation_matrix(center2 - center1);
new_center = ta * ra * tc * rc * [center3 - center2 , 1]';
new_center3 = new_center(1:3)';
angle(1) = angle(1) - 11.5370;
angle(2) = angle(2) + 20;
r = 50;
[x3, y3, z3] = get_halfball_data(new_center3,r , angle);
mesh(x3,y3,z3); 
plot3(x3,y3,z3);
axis([500 1500 800 1200 -200 200]);
