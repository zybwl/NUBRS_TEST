function points = get_control_points(L, point1, point2, point3,is_v_flag)

    v1_x = point2(1) - point1(1);
    v1_y = point2(2) - point1(2); 
    v2_x = point3(1) - point2(1);
    v2_y = point3(2) - point2(2);
    L1 = sqrt(v1_x^2 + v1_y^2);
    L2 = sqrt(v2_x^2 + v2_y^2);
    
    if L1< 1e-4
        line_angle = get_line_angle(point2,point3); 
        inter_angle = 0;
    elseif L2 < 1e-4
        line_angle = get_line_angle(point1,point2); 
        inter_angle = 0;
    else
        if is_v_flag
            line_angle = get_line_angle(point2,point1);
            inter_angle = get_inter_angle(-v1_x,-v1_y,v2_x,v2_y);
        else         
            line_angle = get_line_angle(point1,point2);
            inter_angle = get_inter_angle(v1_x,v1_y,v2_x,v2_y);
        end        
    end
        
    arc_angle = (line_angle +  inter_angle)*pi/180;
    knife_vect = L*[cos(arc_angle),sin(arc_angle)];
    max_inter_angle = 10;
    if abs(inter_angle)<20
         points = [point2 - knife_vect,line_angle +  inter_angle];      
    elseif abs(inter_angle)>170
         points = [point2 + knife_vect,line_angle - 180 + inter_angle] ;              
    else     
        n = floor(abs(inter_angle)/max_inter_angle)+1;
        for i = 0:n
            new_angle = (line_angle + i*inter_angle/n)*pi/180;
            new_knife_vect = L*[cos(new_angle),sin(new_angle)];
            points(i+1,:) = [point2 - new_knife_vect, line_angle + i*inter_angle/n];
        end        
    end    
    
    