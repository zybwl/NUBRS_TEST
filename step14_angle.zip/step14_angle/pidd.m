function [sys,x0,str,ts] = pidd(t,x,u,flag)
switch flag,
    case 0,
        [sys,x0,str,ts]=mdlInitializeSizes;
    case 2,
        sys=mdlUpdate(t,x,u);
    case 3,
        sys=mdlOutputs(t,x,u);
    case {1,4,9},
        sys=[];
    otherwise
        error(['Unhandled flag = ',num2str(flag)]);
end

function [sys,x0,str,ts]=mdlInitializeSizes
global  eT P I D e1 e2
eT=0;e1=0;e2=0;
% P=30; I=5; D=3.2;
P=1.5; I=2; D=0.05;
sizes = simsizes;
sizes.NumContStates  = 0;
sizes.NumDiscStates  = 1;
sizes.NumOutputs     = 1;
sizes.NumInputs      = 2;
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 1;    % at least one sample time is needed
sys = simsizes(sizes);
x0  = zeros(1,1);
str = [];
ts  = [0.01 0];

function sys=mdlUpdate(t,x,u)
global eT P I D e1 e2
% Deadband_Allow=0.01;
e=u(1)-u(2);
eT=eT+e*0.01;

dt=(e-e1)*100;
% aa=(e-2*e1+e2);
if e>0.2
    k=1;
else k=1;
end
% if abs(e)>Deadband_Allow
%     OUT_Real=(E-e1)*P+E*I+aa*D;
OUT_Real=e*P+eT*I*k+dt*D;

    e2=e1;
    e1=e;
    
%     if OUT_Real<-2
%         OUT_Real=-2;
%     elseif OUT_Real>2
%         OUT_Real=2;
%     end
    
% else
%     e=0.0;
%     OUT_Real=0;
% end
x(1)=OUT_Real;
% x(1)=u(2)+OUT_Real;
sys =x;


function sys=mdlOutputs(t,x,u)
sys=x;

