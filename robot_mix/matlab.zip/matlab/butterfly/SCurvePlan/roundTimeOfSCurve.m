function SParam = roundTimeOfSCurve(SParam,Ts)

% �Թ滮���S���߽���Բ��
% TsΪ�岹����

method = 2;
T = SParam.T;
tspan = SParam.t(end);
if method == 1;
% ����1����ÿһ���׶�����ȡ��Ϊ�岹���ڵ�������
    for i = 1:length(T)
        if (T(i) ~= 0)
            T(i) = ceil(T(i)/Ts)*Ts;
        end
    end
elseif method == 2
% ����2��������ʱ�䲹��
    round_time = ceil(tspan/Ts)*Ts;
    time_more = round_time - tspan;
    time_rate = time_more/tspan;
    for i = 1:length(T)
        T(i) = T(i)*(1+time_rate);
    end
elseif method == 3
% ����3������ʱ��Ļ����ϼ�ȥ����Ĳ���
end

vmax = (2*SParam.Stol - sum(T(1:3))*SParam.vs - sum(T(5:7))*SParam.ve)/(sum(T) + T(4));
             
if (vmax < SParam.ve && T(5)~=0) || (vmax<SParam.vs && T(1)~=0)
    round_time = floor(tspan/Ts)*Ts;
    time_less = tspan - round_time;
    time_rate = time_less/tspan;
    T = SParam.T;
    for i = 1:length(T)
        T(i) = T(i)*(1-time_rate);
    end
    vmax = (2*SParam.Stol - sum(T(1:3))*SParam.vs - sum(T(5:7))*SParam.ve)/ (sum(T) + T(4));       
end

% if (vmax < SParam.ve || vmax < SParam.vs) && (T(1)~=0 && T(5)~=0)
%     fprintf('round time stop.\n');
%     SParam = SParam;
%     return;
% end

if SParam.T(1) == 0 && SParam.T(5)~=0
    % ��û�м��ٽ׶�
    SParam.Amax = 0;
    SParam.Dec = (vmax - SParam.ve)/(T(5)+T(6));
    SParam.Jdmax = SParam.Dec/T(5);
    SParam.Vmax = vmax;
    SParam.vs = vmax;
    SParam.T = T;
    SParam.vs = vmax;
    SParam = refreshSParam(SParam);
elseif SParam.T(5) == 0 && SParam.T(1)~=0
    % ��û�м��ٽ׶�
    SParam.Dec = 0;
    SParam.Amax = (vmax - SParam.vs)/(T(1)+T(2));
    SParam.Jamax = SParam.Amax/T(1);
    SParam.Vmax = vmax;
    SParam.ve = vmax;
    SParam.T = T;
    SParam = refreshSParam(SParam);
elseif SParam.T(1) ~= 0 && SParam.T(5) ~= 0
    SParam.Amax = (vmax - SParam.vs)/(T(1)+T(2));
    SParam.Dec = (vmax - SParam.ve)/(T(5)+T(6));
    SParam.Jamax = SParam.Amax/T(1);
    SParam.Jdmax = SParam.Dec/T(5);
    SParam.Vmax = vmax;
    SParam.T = T;
    SParam = refreshSParam(SParam);
elseif SParam.T(1) ==0 && SParam.T(5) == 0
    SParam.Vmax = vmax;
    SParam.vs = vmax;
    SParam.ve = vmax;
    SParam.T = T;
    SParam = refreshSParam(SParam);
    return;
end
% plan_param = [SParam.Amax,SParam.Dec,SParam.Jmax,SParam.Vmax,SParam.Stol,SParam.vs,SParam.ve];
% sp = SCurveVelocityPlan(plan_param);   

